"""
Synthetic data generator for Project FORESIGHT (NorthBay Living).

Produces the four extracts exactly as specified in the brief (Section 05 /
Appendix A):
    - sales_daily.csv
    - sku_master.csv
    - calendar.csv
    - inventory_snapshots.csv

The brief says a dataset + generator accompanies it -- we don't have the
original, so this script recreates data with the same grain, columns, and
deliberate imperfections (missing values, occasional duplicates, mixed
category labels) so the pipeline has something real to clean and model.

Run:
    python data/generate_data.py
"""
import numpy as np
import pandas as pd
from pathlib import Path

RNG = np.random.default_rng(42)
OUT_DIR = Path(__file__).parent
START_DATE = "2022-01-01"
END_DATE = "2025-12-31"
N_SKUS = 60

CATEGORIES = {
    "Furnishings": ["Sofas", "Rugs", "Curtains"],
    "Decor": ["Wall Art", "Vases", "Candles"],
    "Small Appliances": ["Kettles", "Toasters", "Blenders"],
}
# a couple of inconsistent labels on purpose (data-quality issue to catch)
DIRTY_CATEGORY_ALIASES = {"Small Appliances": ["small appliances ", "Small Appl."]}


def make_sku_master():
    rows = []
    cats = list(CATEGORIES.keys())
    for i in range(1, N_SKUS + 1):
        sku_id = f"SKU{i:04d}"
        cat = RNG.choice(cats, p=[0.4, 0.35, 0.25])
        subcat = RNG.choice(CATEGORIES[cat])
        launch_date = pd.Timestamp(START_DATE) + pd.Timedelta(
            days=int(RNG.integers(0, 500))
        )
        unit_cost = round(RNG.uniform(150, 3500), 2)
        list_price = round(unit_cost * RNG.uniform(1.4, 2.2), 2)

        # inject a dirty label ~5% of the time
        cat_label = cat
        if cat in DIRTY_CATEGORY_ALIASES and RNG.random() < 0.08:
            cat_label = RNG.choice(DIRTY_CATEGORY_ALIASES[cat])

        rows.append(
            dict(
                sku_id=sku_id,
                category=cat_label,
                subcategory=subcat,
                launch_date=launch_date.date().isoformat(),
                unit_cost=unit_cost,
                list_price=list_price,
            )
        )
    df = pd.DataFrame(rows)
    # duplicate one row on purpose (data-quality issue)
    df = pd.concat([df, df.iloc[[3]]], ignore_index=True)
    return df


def make_calendar(dates):
    df = pd.DataFrame({"date": dates})
    df["week"] = df["date"].dt.isocalendar().week.astype(int)
    df["month"] = df["date"].dt.month
    df["season"] = df["month"] % 12 // 3 + 1
    df["season"] = df["season"].map({1: "Winter", 2: "Spring", 3: "Summer", 4: "Autumn"})
    df["is_holiday"] = df["date"].dt.month.isin([11, 12]) & (df["date"].dt.day.isin([25, 1]))
    df["is_holiday"] = df["is_holiday"].astype(int)
    # a handful of named promo events per year
    promo_dates = []
    for yr in df["date"].dt.year.unique():
        promo_dates += [
            pd.Timestamp(f"{yr}-07-15"),
            pd.Timestamp(f"{yr}-11-25"),  # Black Friday-style
            pd.Timestamp(f"{yr}-12-20"),
        ]
    df["promo_event"] = df["date"].isin(promo_dates)
    df["promo_event"] = np.where(
        df["date"].isin(promo_dates),
        np.select(
            [df["date"].dt.month == 7, df["date"].dt.month == 11, df["date"].dt.month == 12],
            ["Mid-Year Sale", "Black Friday", "Year-End Sale"],
            default=None,
        ),
        None,
    )
    return df


def make_sales_daily(sku_master, calendar):
    dates = calendar["date"].values
    promo_dates = set(calendar.loc[calendar["promo_event"].notna(), "date"])
    holiday_dates = set(calendar.loc[calendar["is_holiday"] == 1, "date"])

    rows = []
    for _, sku in sku_master.drop_duplicates("sku_id").iterrows():
        base_demand = RNG.uniform(3, 40)
        trend = RNG.uniform(-0.02, 0.05) / 365  # slow drift per day
        weekly_amp = RNG.uniform(0.1, 0.4)
        annual_amp = RNG.uniform(0.15, 0.5)
        noise_sigma = base_demand * RNG.uniform(0.15, 0.35)
        launch = pd.Timestamp(sku["launch_date"])
        price = sku["list_price"]

        for d in dates:
            d_ts = pd.Timestamp(d)
            if d_ts < launch:
                continue
            days_since = (d_ts - pd.Timestamp(START_DATE)).days
            dow = d_ts.dayofweek
            doy = d_ts.dayofyear

            seasonal = 1 + annual_amp * np.sin(2 * np.pi * (doy / 365.25) + RNG.uniform(0, 1))
            weekly = 1 + weekly_amp * (1 if dow >= 5 else -0.3)
            promo_flag = int(d_ts in promo_dates)
            holiday_boost = 1.3 if d_ts in holiday_dates else 1.0
            promo_boost = 1.6 if promo_flag else 1.0

            mean_demand = max(
                0,
                (base_demand + trend * days_since) * seasonal * weekly * holiday_boost * promo_boost,
            )
            units = RNG.poisson(mean_demand) if mean_demand > 0 else 0
            # small chance of a missing/zero recorded day (data-quality issue)
            if RNG.random() < 0.01:
                units = np.nan

            day_price = price * (0.8 if promo_flag else 1.0)
            revenue = None if pd.isna(units) else round(units * day_price, 2)

            rows.append(
                dict(
                    date=d_ts.date().isoformat(),
                    sku_id=sku["sku_id"],
                    units_sold=units,
                    revenue=revenue,
                    unit_price=round(day_price, 2),
                    promo_flag=promo_flag,
                )
            )
    df = pd.DataFrame(rows)
    return df


def make_inventory_snapshots(sku_master, sales_daily):
    # weekly snapshots per SKU
    sales_daily = sales_daily.copy()
    sales_daily["date"] = pd.to_datetime(sales_daily["date"])
    snap_dates = pd.date_range(START_DATE, END_DATE, freq="W-MON")

    rows = []
    sku_ids = sku_master.drop_duplicates("sku_id")["sku_id"].tolist()
    # designate ~20% of SKUs as "over-buffered" slow movers (procurement over-ordered
    # relative to actual sell-through) so the risk grid shows overstock cases too,
    # and ~15% as chronically thin-stocked so stockout cases appear clearly.
    overstocked_skus = set(RNG.choice(sku_ids, size=max(1, int(0.2 * len(sku_ids))), replace=False))
    remaining = [s for s in sku_ids if s not in overstocked_skus]
    thin_skus = set(RNG.choice(remaining, size=max(1, int(0.15 * len(sku_ids))), replace=False))

    for _, sku in sku_master.drop_duplicates("sku_id").iterrows():
        sku_sales = sales_daily[sales_daily["sku_id"] == sku["sku_id"]].set_index("date")["units_sold"]
        avg_weekly_demand = max(1, sku_sales.resample("W-MON").sum().mean() if len(sku_sales) else 5)
        is_overstocked = sku["sku_id"] in overstocked_skus
        is_thin = sku["sku_id"] in thin_skus

        buffer_mult = RNG.uniform(4.0, 7.0) if is_overstocked else RNG.uniform(0.5, 3.0)
        on_hand = buffer_mult * avg_weekly_demand
        lead_time = int(RNG.integers(5, 21))
        reorder_point = round(avg_weekly_demand * (lead_time / 7) * RNG.uniform(1.0, 1.4), 1)

        for snap in snap_dates:
            if snap < pd.Timestamp(sku["launch_date"]):
                continue
            # simulate stock drifting down with sales and occasional restock
            week_sales = sku_sales.loc[snap : snap + pd.Timedelta(days=6)].sum()
            on_hand = max(0, on_hand - week_sales)
            restock_prob = 0.10 if is_thin else (0.35 if is_overstocked else 0.25)
            restocked = RNG.random() < restock_prob
            on_order = round(RNG.uniform(0, avg_weekly_demand * (0.5 if is_thin else 2)), 0) if not restocked else 0
            if restocked:
                restock_mult = RNG.uniform(3.0, 6.0) if is_overstocked else RNG.uniform(0.8, 2.0)
                received = avg_weekly_demand * restock_mult
                on_hand += received

            rows.append(
                dict(
                    date=snap.date().isoformat(),
                    sku_id=sku["sku_id"],
                    on_hand_units=round(on_hand, 0),
                    on_order_units=on_order,
                    lead_time_days=lead_time,
                    reorder_point=reorder_point,
                )
            )
    return pd.DataFrame(rows)


def main():
    dates = pd.date_range(START_DATE, END_DATE, freq="D")
    sku_master = make_sku_master()
    calendar = make_calendar(dates)
    sales_daily = make_sales_daily(sku_master, calendar)
    inventory = make_inventory_snapshots(sku_master, sales_daily)

    sku_master.to_csv(OUT_DIR / "sku_master.csv", index=False)
    calendar.assign(date=calendar["date"].dt.date).to_csv(OUT_DIR / "calendar.csv", index=False)
    sales_daily.to_csv(OUT_DIR / "sales_daily.csv", index=False)
    inventory.to_csv(OUT_DIR / "inventory_snapshots.csv", index=False)

    print("Generated:")
    print(f"  sku_master.csv           {len(sku_master):>8,} rows")
    print(f"  calendar.csv             {len(calendar):>8,} rows")
    print(f"  sales_daily.csv          {len(sales_daily):>8,} rows")
    print(f"  inventory_snapshots.csv  {len(inventory):>8,} rows")


if __name__ == "__main__":
    main()
