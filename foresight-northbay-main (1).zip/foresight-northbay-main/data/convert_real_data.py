"""
Converts the client's real Excel export (Products / Stores / Sales_Fact /
Inventory_Fact / Date_Dim sheets) into the brief's four-table schema:
    sales_daily.csv, sku_master.csv, calendar.csv, inventory_snapshots.csv

This REPLACES data/generate_data.py's synthetic output with the real
NorthBay Living data, aggregated across stores to SKU-level (the brief
asks for SKU-level forecasting, not SKU-store level).

Run:
    python data/convert_real_data.py <path_to_excel_file>
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

OUT_DIR = Path(__file__).parent


def convert(xlsx_path: str):
    xls = pd.ExcelFile(xlsx_path)
    products = pd.read_excel(xls, sheet_name="Products")
    stores = pd.read_excel(xls, sheet_name="Stores")
    sales = pd.read_excel(xls, sheet_name="Sales_Fact")
    inventory = pd.read_excel(xls, sheet_name="Inventory_Fact")
    date_dim = pd.read_excel(xls, sheet_name="Date_Dim")

    # ---------- sku_master.csv ----------
    first_sale = sales.groupby("ProductID")["Date"].min().rename("launch_date")
    sku_master = products.rename(columns={
        "ProductID": "sku_id", "Category": "category",
        "Unit Cost": "unit_cost", "Unit Price": "list_price",
        "Reorder Level": "reorder_level_ref", "Lead Time Days": "lead_time_days_ref",
    })
    sku_master = sku_master.merge(first_sale, left_on="sku_id", right_index=True, how="left")
    sku_master["subcategory"] = sku_master["category"]  # no subcategory column in source data
    sku_master["launch_date"] = sku_master["launch_date"].dt.date.astype(str)
    sku_master = sku_master[["sku_id", "category", "subcategory", "launch_date", "unit_cost", "list_price"]]

    # ---------- sales_daily.csv (aggregated across stores -> SKU level, per the brief) ----------
    sales_agg = (
        sales.groupby(["Date", "ProductID"])
        .agg(units_sold=("Units Sold", "sum"), revenue=("Revenue", "sum"))
        .reset_index()
        .rename(columns={"Date": "date", "ProductID": "sku_id"})
    )
    sales_agg["unit_price"] = np.where(
        sales_agg["units_sold"] > 0, sales_agg["revenue"] / sales_agg["units_sold"], np.nan
    )
    sales_agg["unit_price"] = sales_agg["unit_price"].fillna(
        sales_agg["sku_id"].map(sku_master.set_index("sku_id")["list_price"])
    )
    # source data has no promotion flag; conservatively mark 0 (documented assumption)
    sales_agg["promo_flag"] = 0
    sales_agg["date"] = sales_agg["date"].dt.date.astype(str)

    # ---------- calendar.csv ----------
    cal = date_dim.rename(columns={"Date": "date", "Week": "week", "MonthNum": "month"})
    cal["season"] = cal["month"].map({
        12: "Winter", 1: "Winter", 2: "Winter",
        3: "Spring", 4: "Spring", 5: "Spring",
        6: "Summer", 7: "Summer", 8: "Summer",
        9: "Autumn", 10: "Autumn", 11: "Autumn",
    })
    # source has no holiday/promo columns; flag common year-end holidays as a
    # reasonable default (documented assumption -- adjust if NorthBay shares
    # an actual holiday calendar)
    cal["is_holiday"] = ((cal["month"] == 12) & (pd.to_datetime(cal["date"]).dt.day.isin([25, 31]))).astype(int) + \
                         ((cal["month"] == 1) & (pd.to_datetime(cal["date"]).dt.day == 1)).astype(int)
    cal["is_holiday"] = cal["is_holiday"].clip(0, 1)
    cal["promo_event"] = None
    cal["date"] = pd.to_datetime(cal["date"]).dt.date.astype(str)
    cal = cal[["date", "week", "month", "season", "is_holiday", "promo_event"]]

    # ---------- inventory_snapshots.csv (aggregated across stores -> SKU level) ----------
    inv_agg = (
        inventory.groupby(["Date", "ProductID"])
        .agg(on_hand_units=("Stock On Hand (End of Week)", "sum"),
             stock_received=("Stock Received", "sum"))
        .reset_index()
        .rename(columns={"Date": "date", "ProductID": "sku_id"})
    )
    # source has no "on order" column; not knowable from what's provided, so
    # set to 0 (documented assumption -- stockout risk becomes slightly more
    # conservative than if in-transit stock were known)
    inv_agg["on_order_units"] = 0
    inv_agg = inv_agg.merge(
        products.rename(columns={"ProductID": "sku_id", "Lead Time Days": "lead_time_days",
                                  "Reorder Level": "reorder_point"})[["sku_id", "lead_time_days", "reorder_point"]],
        on="sku_id", how="left",
    )
    inv_agg["date"] = inv_agg["date"].dt.date.astype(str)
    inv_agg = inv_agg[["date", "sku_id", "on_hand_units", "on_order_units", "lead_time_days", "reorder_point"]]

    # ---------- write ----------
    sku_master.to_csv(OUT_DIR / "sku_master.csv", index=False)
    cal.to_csv(OUT_DIR / "calendar.csv", index=False)
    sales_agg[["date", "sku_id", "units_sold", "revenue", "unit_price", "promo_flag"]].to_csv(
        OUT_DIR / "sales_daily.csv", index=False
    )
    inv_agg.to_csv(OUT_DIR / "inventory_snapshots.csv", index=False)

    print("Converted real NorthBay Living data:")
    print(f"  sku_master.csv           {len(sku_master):>8,} rows  ({sku_master['sku_id'].nunique()} SKUs)")
    print(f"  calendar.csv             {len(cal):>8,} rows")
    print(f"  sales_daily.csv          {len(sales_agg):>8,} rows")
    print(f"  inventory_snapshots.csv  {len(inv_agg):>8,} rows")
    print()
    print("Documented assumptions made during conversion:")
    print("  - Sales/inventory aggregated across the 10 stores to SKU level (brief asks for SKU-level forecasting).")
    print("  - No promotion flag in source data -> promo_flag set to 0 for all rows.")
    print("  - No on-order/in-transit stock column in source -> on_order_units set to 0.")
    print("  - No holiday calendar in source -> Dec 25/31 and Jan 1 flagged as holidays by default.")

    # ---------- store_summary.csv (for the dashboard's store/region views —
    # not part of the brief's required schema, but keeps the dashboard rich) ----------
    store_sales = (
        sales.merge(stores.rename(columns={"StoreID": "store_id", "Store Name": "store_name",
                                            "Region": "region"}),
                    left_on="StoreID", right_on="store_id", how="left")
        .groupby(["store_id", "store_name", "region"])
        .agg(revenue=("Revenue", "sum"), units_sold=("Units Sold", "sum"))
        .reset_index()
    )
    store_sales.to_csv(OUT_DIR / "store_summary.csv", index=False)
    print(f"  store_summary.csv        {len(store_sales):>8,} rows  (dashboard-only, not part of brief schema)")

    # ---------- region_weekly.csv (dashboard-only — supports a Region filter
    # across the SKU/category views, without changing the brief's required
    # SKU-level schema used for forecasting) ----------
    sales_with_region = sales.merge(
        stores.rename(columns={"StoreID": "store_id", "Region": "region"})[["store_id", "region"]],
        left_on="StoreID", right_on="store_id", how="left",
    )
    sales_with_region["week_start"] = sales_with_region["Date"] - pd.to_timedelta(
        sales_with_region["Date"].dt.weekday, unit="D"
    )
    region_weekly = (
        sales_with_region.groupby(["week_start", "ProductID", "region"])
        .agg(units_sold=("Units Sold", "sum"), revenue=("Revenue", "sum"))
        .reset_index()
        .rename(columns={"ProductID": "sku_id"})
        .merge(sku_master[["sku_id", "category"]], on="sku_id", how="left")
    )
    region_weekly.to_csv(OUT_DIR / "region_weekly.csv", index=False)
    print(f"  region_weekly.csv        {len(region_weekly):>8,} rows  (dashboard-only, adds Region filter support)")

    # ---------- inventory_region_monthly.csv (dashboard-only — supports
    # Year + Region + Category filtering on the Inventory tab) ----------
    inv_reg = inventory.merge(
        stores.rename(columns={"StoreID": "store_id", "Region": "region"})[["store_id", "region"]],
        left_on="StoreID", right_on="store_id", how="left",
    ).merge(sku_master[["sku_id", "category"]], left_on="ProductID", right_on="sku_id", how="left")
    inv_reg["month"] = inv_reg["Date"].dt.to_period("M").dt.to_timestamp()
    inv_reg["is_stockout"] = (inv_reg["Stockout Flag"] == "Yes").astype(int)
    inv_region_monthly = (
        inv_reg.groupby(["month", "sku_id", "category", "region"])
        .agg(stock_received=("Stock Received", "sum"),
             stock_on_hand=("Stock On Hand (End of Week)", "sum"),
             stockout_days=("is_stockout", "sum"))
        .reset_index()
    )
    inv_region_monthly.to_csv(OUT_DIR / "inventory_region_monthly.csv", index=False)
    print(f"  inventory_region_monthly.csv  {len(inv_region_monthly):>8,} rows  (dashboard-only, adds Region filter to Inventory tab)")

    # ---------- inventory_detail.csv (for the dashboard's Inventory tab —
    # monthly stock received vs on-hand, stockout occurrences, top products) ----------
    inv_monthly = inventory.copy()
    inv_monthly["month"] = inv_monthly["Date"].dt.to_period("M").dt.to_timestamp()
    monthly_trend = (
        inv_monthly.groupby("month")
        .agg(stock_received=("Stock Received", "sum"),
             stock_on_hand=("Stock On Hand (End of Week)", "sum"))
        .reset_index()
    )
    stockout_by_month = (
        inv_monthly.assign(is_stockout=(inv_monthly["Stockout Flag"] == "Yes").astype(int))
        .groupby("month")["is_stockout"].sum().rename("stockout_occurrences").reset_index()
    )
    monthly_trend = monthly_trend.merge(stockout_by_month, on="month", how="left")

    stockout_by_sku = (
        inventory.assign(is_stockout=(inventory["Stockout Flag"] == "Yes").astype(int))
        .groupby("ProductID")["is_stockout"].sum()
        .rename("stockout_count").sort_values(ascending=False).reset_index()
        .rename(columns={"ProductID": "sku_id"})
    )
    inv_levels_by_sku = (
        inventory.groupby("ProductID")["Stock On Hand (End of Week)"].mean()
        .rename("avg_stock_on_hand").sort_values(ascending=False).reset_index()
        .rename(columns={"ProductID": "sku_id"})
    )

    monthly_trend.to_csv(OUT_DIR / "inventory_monthly_trend.csv", index=False)
    stockout_by_sku.to_csv(OUT_DIR / "stockout_by_sku.csv", index=False)
    inv_levels_by_sku.to_csv(OUT_DIR / "inventory_levels_by_sku.csv", index=False)
    overall_stockout_rate = (inventory["Stockout Flag"] == "Yes").mean() * 100
    print(f"  inventory_monthly_trend.csv, stockout_by_sku.csv, inventory_levels_by_sku.csv written")
    print(f"  Overall stockout rate: {overall_stockout_rate:.2f}%")


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else None
    if not path:
        print("Usage: python data/convert_real_data.py <path_to_excel_file>")
        sys.exit(1)
    convert(path)
