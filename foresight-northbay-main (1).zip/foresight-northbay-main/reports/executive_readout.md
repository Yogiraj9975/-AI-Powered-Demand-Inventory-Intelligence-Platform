# FORESIGHT — Executive Readout
**For: Head of Operations & Finance, NorthBay Living**
**From: Data Scientist, Project FORESIGHT engagement**

## Bottom line

**6 of your 28 SKUs are about to run out**, putting an estimated
**₹28.3 lakh of sales at risk** over the next 8 weeks if nothing changes.
There is currently **no meaningful overstock problem** — this business is
running lean, not sitting on dead stock. The fix this week is simple:
reorder the 6 flagged SKUs, starting with the two biggest (P018, P025).

## What FORESIGHT found

- **6 SKUs need reordering now**: P018, P025, P001, P014, P026, P002.
  Together they represent ₹28.3 lakh of sales that will be lost if they
  stock out before a fresh order arrives.
- **22 SKUs are healthy** — no action needed on them this week.
- **Zero SKUs are overstocked** under the current criteria — worth
  double-checking against the ops team's own sense of "sitting stock,"
  but the data doesn't show excess inventory anywhere right now.
- **Demand is strongly seasonal**, rising ~50% from the summer low
  (Jun–Jul) into the Q4 peak (Oct–Nov) — flat, gut-feel ordering will
  under-order right when demand is highest.

## How confident is the forecast?

We tested the model the way we'll actually use it: train on the past,
predict the next 8 weeks, check what really happened — repeated 6 times
over the last year and a half ("rolling-origin backtesting," never a
single lucky split).

- A naive "same time last year" forecast is off by **6.1%** on average
  (WAPE — for every ₹100 of demand, it misses by about ₹6).
- Our trained model is off by **3.9%** — a **36% improvement** over the
  naive approach, holding up across all 6 test windows.
- The one fold worth a second look: the most recent test window (Nov–Dec)
  has the highest error for both methods — the holiday ramp is genuinely
  harder to call. We'd recommend a manual check on the top 2 SKUs during
  that window rather than trusting the number blind.

## What we recommend this week

1. **Reorder P018 and P025 first** — they alone account for over
   ₹8 lakh of the sales-at-risk figure, and both have the shortest
   runway before stocking out.
2. **Reorder the remaining 4 flagged SKUs** (P001, P014, P026, P002) in
   the same cycle — see the full list with lead times in the dashboard.
3. **No clearance action needed this cycle** — revisit the overstock view
   after the next few weeks of data in case any SKU tips over from the
   Q4 demand pull-forward.
4. **Refresh weekly** — every SKU is re-scored automatically each time the
   pipeline runs on fresh data.

## How to use this ongoing

- **Planning dashboard**: filter by category, see the reorder list, and
  the forecast for any SKU — no data science background needed.
- **Scoring API**: any SKU's forecast + risk can be pulled programmatically
  (`/score/{sku_id}`) for a future integration with your reordering system.

## Honest limitations

- No on-order/in-transit stock column was present in the extract provided,
  so stockout risk assumes nothing is currently in transit — if orders are
  already placed for any of the 6 flagged SKUs, their real risk is lower
  than shown here. Please confirm.
- No promotion calendar was in the extract, so the forecast does not yet
  account for planned promotions — if a promo is planned in the next
  8 weeks, expect actual demand to run higher than forecast for that SKU.
- Sales and inventory were aggregated across all 10 stores to the SKU
  level, per the brief's scope; a store-level cut is a natural next step
  if the ops team reorders per warehouse rather than centrally.
