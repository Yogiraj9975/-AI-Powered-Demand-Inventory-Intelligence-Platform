# Data-Quality & EDA Insight Memo
**Project FORESIGHT — NorthBay Living**
*(Based on NorthBay Living's actual 5-year extract: 511,280 sales rows, 28 SKUs, 10 stores, 2021–2025)*

## 1. Data-quality assessment

The provided extract (`Products`, `Stores`, `Sales_Fact`, `Inventory_Fact`, `Date_Dim`) was
checked for the issues the brief flags as typical of real client data:

| Check | Result |
|---|---|
| Missing values | None found in any of the 5 sheets. |
| Duplicate rows | None found in `Products` or `Sales_Fact`. |
| Inconsistent category labels | None — categories are already clean (`Apparel`, `Electronics`, `Home & Kitchen`, `Personal Care`). |
| Grain consistency | `Sales_Fact` and `Inventory_Fact` are recorded daily, per SKU per store (511,280 rows each = 28 SKUs × 10 stores × 1,826 days). |

**Columns not present in the source, handled as documented assumptions**
(see `data/convert_real_data.py`): no promotion flag (set to 0), no
on-order/in-transit stock column (set to 0 — makes stockout risk slightly
conservative), no holiday calendar (Dec 25/31 and Jan 1 defaulted as
holidays). These should be confirmed with NorthBay before the numbers here
are used to place real orders.

**One decision worth flagging to the client:** the brief asks for
SKU-level forecasting, so sales and inventory were **aggregated across
NorthBay's 10 stores** to the SKU level. A store-level breakdown is
possible as a follow-on if the ops team wants to reorder per warehouse
rather than for the network as a whole.

## 2. Demand patterns

**Seasonality.** Average weekly units sold climb steadily from a summer
low (~1,608–1,622 units/week in Jun–Jul) to a clear **Q4 peak**
(~2,206–2,423 units/week, Oct–Nov), before easing slightly in December.
This is the single strongest signal the forecast model uses — `week_of_year`
dominates feature importance, consistent with a home & lifestyle brand's
year-end gifting season.

**Category mix.** Revenue splits **Apparel 30.4%**, **Personal Care
24.4%**, **Home & Kitchen 23.3%**, **Electronics 21.9%** — Apparel is the
clear leader but no category is negligible, so risk still needs to be
managed SKU-by-SKU rather than by category alone.

**Top movers.** SKU P018 (₹134.4M) and P025 (₹104.3M) lead revenue by a
wide margin over the rest of the top 5 (P013, P008, P017, each ~₹89–90M) —
these are exactly the SKUs where a stockout is most expensive, and both
currently sit on the **Reorder Now** list (see Section 8 below).

## 3. Business-relevant insights (plain language)

1. **This business runs lean on inventory, not fat.** Unlike a typical
   "too much stock" story, the risk model finds **zero SKUs currently
   overstocked** — on-hand stock is consistently well below a week's
   demand for most SKUs. The real risk here is the opposite: **6 of 28
   SKUs (21%) are flagged Reorder Now**, together representing
   **₹28.3 lakh of sales at risk** if nothing changes before they run out.
2. **The Q4 seasonal ramp is the single biggest planning risk.** Demand
   rises ~50% from its summer trough into Oct–Nov; ordering on a flat
   average would guarantee stockouts right when demand peaks.
3. **Two SKUs (P018, P025) account for disproportionate exposure** — over
   ₹8 lakh of the total sales-at-risk figure comes from just these two.
   They deserve manual review even after the automated reorder list is
   actioned.

## 4. How to read the charts in the dashboard

- **Forecast vs actual** (Streamlit): black line is history, blue line is
  the model's forecast, shaded band is an empirical 80% interval.
- **Decisioning grid**: with this data, every flagged SKU currently sits on
  the stockout (left) side of the grid — the overstock/markdown quadrant is
  empty, which is itself a finding worth reporting, not a bug.
