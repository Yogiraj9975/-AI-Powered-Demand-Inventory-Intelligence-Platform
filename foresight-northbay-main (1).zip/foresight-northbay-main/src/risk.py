"""
D4 — Risk scoring & decisioning

For every SKU, over the forecast horizon:
  - Stockout risk: compare forecast demand over the lead time against
    on-hand + on-order stock. If projected stock falls below a safety
    level, the SKU is at risk of stocking out.
  - Overstock risk: compare on-hand stock against forecast demand over a
    forward window. If holding far more than will sell, it's overstocked.
  - Combine both into the four-quadrant decisioning grid from the brief
    (Section 08): Reorder Now / Markdown-Clear / Watch-Volatile / Healthy.
  - Attach the rupee value at stake so the ops team can prioritise.

Logic is intentionally simple and explainable (no black box), per
acceptance criterion D4.3.

Run:
    python src/risk.py
Produces:
    data/risk_output.parquet
"""
from pathlib import Path

import numpy as np
import pandas as pd

DATA_DIR = Path(__file__).parent.parent / "data"
HORIZON_WEEKS = 8


def load_inputs():
    forecast = pd.read_parquet(DATA_DIR / "forecast_output.parquet")
    inv = pd.read_csv(DATA_DIR / "inventory_snapshots.csv", parse_dates=["date"])
    sku = pd.read_csv(DATA_DIR / "sku_master.csv")
    return forecast, inv, sku


def score_risk(forecast: pd.DataFrame, inv: pd.DataFrame, sku: pd.DataFrame) -> pd.DataFrame:
    # latest known inventory position per SKU
    latest_inv = (
        inv.sort_values("date")
        .groupby("sku_id")
        .last()
        .reset_index()[["sku_id", "on_hand_units", "on_order_units", "lead_time_days", "reorder_point"]]
    )

    # total forecast demand over the full horizon, and over each SKU's own lead time
    horizon_demand = forecast.groupby("sku_id")["forecast_units"].sum().rename("horizon_demand")
    weekly_demand = forecast.groupby("sku_id")["forecast_units"].mean().rename("avg_weekly_demand")
    price = forecast.groupby("sku_id")["list_price"].first().rename("price")
    category = forecast.groupby("sku_id")["category"].first()

    df = latest_inv.merge(horizon_demand, on="sku_id").merge(weekly_demand, on="sku_id")
    df = df.merge(price, on="sku_id").merge(category, on="sku_id")

    # demand expected to arrive before a fresh order could (i.e. over lead time)
    df["lead_time_weeks"] = df["lead_time_days"] / 7.0
    df["demand_over_lead_time"] = df["avg_weekly_demand"] * df["lead_time_weeks"]
    df["available_stock"] = df["on_hand_units"] + df["on_order_units"]

    # --- Stockout risk: how much of lead-time demand is NOT covered by available stock ---
    df["stockout_gap"] = df["demand_over_lead_time"] - df["available_stock"]
    df["stockout_risk"] = (df["stockout_gap"] / df["demand_over_lead_time"].replace(0, np.nan)).clip(0, 1).fillna(0)

    # --- Overstock risk: weeks of on-hand cover relative to the SKU's own
    # typical replenishment cycle (lead time + a review buffer), not the full
    # forecast horizon -- a SKU reordered every ~2 weeks doesn't need 8 weeks
    # of cover to be "healthy". 0 risk at <= 1x cycle, ramps to 1 at 3x cycle.
    df["reorder_cycle_weeks"] = (df["lead_time_weeks"] + 1).clip(lower=2)
    df["weeks_of_cover"] = df["on_hand_units"] / df["avg_weekly_demand"].replace(0, np.nan)
    df["overstock_risk"] = (
        (df["weeks_of_cover"] - df["reorder_cycle_weeks"]) / (2 * df["reorder_cycle_weeks"])
    ).clip(0, 1).fillna(0)

    # --- Rupee value at stake ---
    df["sales_at_risk_rs"] = (df["stockout_gap"].clip(lower=0) * df["price"] * 0.9).round(2)
    excess_units = (df["on_hand_units"] - df["avg_weekly_demand"] * HORIZON_WEEKS).clip(lower=0)
    df["capital_locked_rs"] = (excess_units * df["price"] * 0.55).round(2)  # ~cost proxy

    # --- Decisioning grid: 4 quadrants on a 0.5/0.5 threshold, as in the brief ---
    def quadrant(row):
        so, ov = row["stockout_risk"], row["overstock_risk"]
        if so >= 0.5 and ov >= 0.5:
            return "Watch / Volatile"
        if so >= 0.5:
            return "Reorder Now"
        if ov >= 0.5:
            return "Markdown / Clear"
        return "Healthy"

    df["quadrant"] = df.apply(quadrant, axis=1)

    action_map = {
        "Reorder Now": "Raise a replenishment order before stock runs out.",
        "Markdown / Clear": "Promote or discount to free up capital.",
        "Watch / Volatile": "Investigate — demand is erratic; review manually.",
        "Healthy": "No action needed; leave as is.",
    }
    df["recommended_action"] = df["quadrant"].map(action_map)

    df["rupee_value_at_stake"] = np.where(
        df["quadrant"] == "Reorder Now", df["sales_at_risk_rs"],
        np.where(df["quadrant"] == "Markdown / Clear", df["capital_locked_rs"],
                 df[["sales_at_risk_rs", "capital_locked_rs"]].max(axis=1)),
    )

    cols = [
        "sku_id", "category", "on_hand_units", "on_order_units", "lead_time_days",
        "avg_weekly_demand", "horizon_demand", "stockout_risk", "overstock_risk",
        "quadrant", "recommended_action", "sales_at_risk_rs", "capital_locked_rs",
        "rupee_value_at_stake",
    ]
    return df[cols].sort_values("rupee_value_at_stake", ascending=False).reset_index(drop=True)


def run():
    forecast, inv, sku = load_inputs()
    risk_df = score_risk(forecast, inv, sku)
    risk_df.to_parquet(DATA_DIR / "risk_output.parquet", index=False)

    print(risk_df["quadrant"].value_counts().to_string())
    print()
    print("Top 10 by rupee value at stake:")
    print(risk_df.head(10)[["sku_id", "quadrant", "rupee_value_at_stake", "recommended_action"]].to_string(index=False))
    print(f"\nTotal sales at risk (stockout):     Rs {risk_df['sales_at_risk_rs'].sum():,.0f}")
    print(f"Total capital locked (overstock):   Rs {risk_df['capital_locked_rs'].sum():,.0f}")
    return risk_df


if __name__ == "__main__":
    run()
