"""
D1 — Data pipeline
Ingests the four raw extracts, cleans them, and produces one analysis-ready,
weekly SKU-level dataset with engineered features.

Cleaning decisions (documented, per acceptance criterion D1.4):
  1. sales_daily.units_sold nulls -> treated as 0 sold (no sale recorded that
     day), NOT dropped, because dropping would silently understate demand.
  2. sales_daily.revenue nulls (follow from units_sold nulls) -> recomputed
     as units_sold * unit_price after (1).
  3. sku_master.category has inconsistent labels (e.g. "small appliances ",
     "Small Appl.") -> normalised via a mapping to the canonical 3
     categories from the brief.
  4. sku_master has exact-duplicate rows -> dropped, keeping first.
  5. All dates parsed to pandas Timestamp; joins are left joins from
     sales_daily so we never invent sales history.

Run:
    python src/pipeline.py
Produces:
    data/processed_weekly.parquet
"""
import re
from pathlib import Path

import numpy as np
import pandas as pd

DATA_DIR = Path(__file__).parent.parent / "data"

CATEGORY_MAP = {
    "furnishings": "Furnishings",
    "decor": "Decor",
    "small appliances": "Small Appliances",
    "small appl.": "Small Appliances",
}


def _normalise_category(raw: str) -> str:
    key = re.sub(r"\s+", " ", str(raw).strip().lower()).rstrip(".")
    key = key.replace("small appl", "small appliances") if key.startswith("small appl") else key
    return CATEGORY_MAP.get(key, str(raw).strip())


def load_raw():
    sales = pd.read_csv(DATA_DIR / "sales_daily.csv", parse_dates=["date"])
    sku = pd.read_csv(DATA_DIR / "sku_master.csv", parse_dates=["launch_date"])
    cal = pd.read_csv(DATA_DIR / "calendar.csv", parse_dates=["date"])
    inv = pd.read_csv(DATA_DIR / "inventory_snapshots.csv", parse_dates=["date"])
    return sales, sku, cal, inv


def clean_sku_master(sku: pd.DataFrame) -> pd.DataFrame:
    sku = sku.drop_duplicates(subset="sku_id", keep="first").copy()
    sku["category"] = sku["category"].map(_normalise_category)
    return sku


def clean_sales(sales: pd.DataFrame) -> pd.DataFrame:
    sales = sales.copy()
    missing_units = sales["units_sold"].isna().sum()
    sales["units_sold"] = sales["units_sold"].fillna(0)
    sales["revenue"] = sales["units_sold"] * sales["unit_price"]
    sales["promo_flag"] = sales["promo_flag"].fillna(0).astype(int)
    print(f"  cleaned sales_daily: filled {missing_units} missing units_sold values with 0")
    return sales


def build_weekly_panel(sales, sku, cal, inv) -> pd.DataFrame:
    sales = sales.copy()
    sales["week_start"] = sales["date"].dt.to_period("W-MON").dt.start_time

    weekly_sales = (
        sales.groupby(["sku_id", "week_start"])
        .agg(units_sold=("units_sold", "sum"), revenue=("revenue", "sum"),
             avg_price=("unit_price", "mean"), promo_days=("promo_flag", "sum"))
        .reset_index()
    )

    # calendar features at week grain
    cal_weekly = cal.copy()
    cal_weekly["week_start"] = cal_weekly["date"].dt.to_period("W-MON").dt.start_time
    cal_week_feats = (
        cal_weekly.groupby("week_start")
        .agg(is_holiday_week=("is_holiday", "max"),
             has_promo_event=("promo_event", lambda s: int(s.notna().any())),
             month=("month", "first"),
             season=("season", "first"))
        .reset_index()
    )

    panel = weekly_sales.merge(cal_week_feats, on="week_start", how="left")
    panel = panel.merge(sku[["sku_id", "category", "subcategory", "unit_cost", "list_price"]],
                         on="sku_id", how="left")

    # nearest inventory snapshot on/before each week for on_hand / reorder context
    # merge_asof with `by=` requires the frame to be sorted by the `on` key
    # (not just within each group), so sort by week_start first.
    inv_sorted = inv.rename(columns={"date": "week_start"}).sort_values("week_start")
    panel = panel.sort_values("week_start")
    panel = pd.merge_asof(
        panel, inv_sorted,
        by="sku_id", on="week_start", direction="backward",
    )

    # feature engineering: lags + rolling stats, per SKU, sorted by time
    panel = panel.sort_values(["sku_id", "week_start"]).reset_index(drop=True)
    g = panel.groupby("sku_id")["units_sold"]
    for lag in (1, 2, 4, 52):
        panel[f"lag_{lag}"] = g.shift(lag)
    panel["roll_mean_4"] = g.shift(1).rolling(4).mean().reset_index(level=0, drop=True)
    panel["roll_std_4"] = g.shift(1).rolling(4).std().reset_index(level=0, drop=True)
    panel["roll_mean_8"] = g.shift(1).rolling(8).mean().reset_index(level=0, drop=True)

    panel["week_of_year"] = panel["week_start"].dt.isocalendar().week.astype(int)
    return panel


def run():
    print("D1 pipeline — ingest & clean")
    sales, sku, cal, inv = load_raw()
    sku_clean = clean_sku_master(sku)
    sales_clean = clean_sales(sales)
    panel = build_weekly_panel(sales_clean, sku_clean, cal, inv)

    out_path = DATA_DIR / "processed_weekly.parquet"
    panel.to_parquet(out_path, index=False)
    print(f"  wrote {out_path}  ({len(panel):,} rows, {panel['sku_id'].nunique()} SKUs)")
    return panel


if __name__ == "__main__":
    run()
