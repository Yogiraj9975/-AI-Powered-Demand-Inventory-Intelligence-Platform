"""
D3 — Demand forecast model

Implements:
  - Seasonal-naive baseline (predict = same week, 52 weeks ago; falls back to
    the SKU's rolling mean when history < 52 weeks, e.g. new SKUs).
  - A LightGBM regression model on lag / rolling / calendar features.
  - Rolling-origin backtesting (never a single random train/test split for
    time series -- see brief Section 07).
  - WAPE (primary metric) and MAPE/bias (secondary), per Appendix B.

No data leakage: every feature at week t only uses information available
strictly before t (lags and rolling stats are shifted by 1 before rolling).

Run:
    python src/forecast.py
Produces:
    reports/backtest_results.csv   (per-fold WAPE, MAPE, bias for baseline vs model)
    data/forecast_output.parquet   (final model forecasts + intervals, for the dashboard/service)
"""
from pathlib import Path

import numpy as np
import pandas as pd
from lightgbm import LGBMRegressor

DATA_DIR = Path(__file__).parent.parent / "data"
REPORTS_DIR = Path(__file__).parent.parent / "reports"
HORIZON_WEEKS = 8          # forecast horizon required by the brief (6-8 weeks)
N_BACKTEST_FOLDS = 6       # rolling-origin folds


FEATURE_COLS = [
    "lag_1", "lag_2", "lag_4", "lag_52",
    "roll_mean_4", "roll_std_4", "roll_mean_8",
    "week_of_year", "month", "is_holiday_week", "has_promo_event", "promo_days",
]


def wape(actual: np.ndarray, forecast: np.ndarray) -> float:
    """Weighted Absolute Percentage Error = sum|actual-forecast| / sum(actual).
    Primary accuracy metric (Appendix B) -- robust to low-volume SKUs where
    MAPE explodes on near-zero weeks."""
    actual = np.asarray(actual, dtype=float)
    forecast = np.asarray(forecast, dtype=float)
    denom = np.sum(np.abs(actual))
    if denom == 0:
        return np.nan
    return np.sum(np.abs(actual - forecast)) / denom


def mape(actual: np.ndarray, forecast: np.ndarray) -> float:
    actual = np.asarray(actual, dtype=float)
    forecast = np.asarray(forecast, dtype=float)
    mask = actual != 0
    if mask.sum() == 0:
        return np.nan
    return np.mean(np.abs((actual[mask] - forecast[mask]) / actual[mask]))


def bias(actual: np.ndarray, forecast: np.ndarray) -> float:
    """Mean signed error -- checks systematic over/under forecasting."""
    return float(np.mean(np.asarray(forecast, dtype=float) - np.asarray(actual, dtype=float)))


def seasonal_naive_predict(panel: pd.DataFrame) -> pd.Series:
    """Predict = actual units_sold 52 weeks earlier for the same SKU.
    Falls back to the trailing 8-week mean when lag_52 is unavailable
    (e.g. SKU launched < 1 year ago)."""
    pred = panel["lag_52"].copy()
    fallback = panel["roll_mean_8"]
    pred = pred.fillna(fallback)
    pred = pred.fillna(panel.groupby("sku_id")["units_sold"].transform("mean"))
    return pred.fillna(0)


def rolling_origin_backtest(panel: pd.DataFrame) -> pd.DataFrame:
    """Rolling-origin CV: repeatedly train on the past, test on the next
    HORIZON_WEEKS block, roll the origin forward. Never trains on future
    data relative to its own test fold."""
    weeks = sorted(panel["week_start"].unique())
    if len(weeks) < 60:
        raise ValueError("Not enough history for rolling-origin backtest.")

    results = []
    # last fold ends at the most recent week; step back HORIZON_WEEKS per fold
    for fold in range(N_BACKTEST_FOLDS):
        test_end_idx = len(weeks) - 1 - fold * HORIZON_WEEKS
        test_start_idx = test_end_idx - HORIZON_WEEKS + 1
        train_end_idx = test_start_idx - 1
        if train_end_idx < 52:  # need at least a year of training history
            break

        train_weeks = weeks[: train_end_idx + 1]
        test_weeks = weeks[test_start_idx : test_end_idx + 1]

        train = panel[panel["week_start"].isin(train_weeks)].dropna(subset=FEATURE_COLS + ["units_sold"])
        test = panel[panel["week_start"].isin(test_weeks)].copy()

        if len(train) < 200 or test.empty:
            continue

        model = LGBMRegressor(
            n_estimators=200, learning_rate=0.05, max_depth=5,
            min_child_samples=15, random_state=42, verbosity=-1,
        )
        model.fit(train[FEATURE_COLS], train["units_sold"])

        test_valid = test.dropna(subset=FEATURE_COLS)
        model_pred = pd.Series(0.0, index=test.index)
        model_pred.loc[test_valid.index] = model.predict(test_valid[FEATURE_COLS])

        baseline_pred = seasonal_naive_predict(test)

        results.append(dict(
            fold=fold,
            train_end=str(train_weeks[-1].date()),
            test_start=str(test_weeks[0].date()),
            test_end=str(test_weeks[-1].date()),
            n_test_rows=len(test),
            wape_baseline=wape(test["units_sold"], baseline_pred),
            wape_model=wape(test["units_sold"], model_pred),
            mape_baseline=mape(test["units_sold"], baseline_pred),
            mape_model=mape(test["units_sold"], model_pred),
            bias_baseline=bias(test["units_sold"], baseline_pred),
            bias_model=bias(test["units_sold"], model_pred),
        ))

    return pd.DataFrame(results).sort_values("fold")


def train_final_model_and_forecast(panel: pd.DataFrame) -> pd.DataFrame:
    """Train on all available history, forecast HORIZON_WEEKS ahead per SKU,
    with an empirical 80% interval from backtest residual spread."""
    train = panel.dropna(subset=FEATURE_COLS + ["units_sold"])
    model = LGBMRegressor(
        n_estimators=300, learning_rate=0.05, max_depth=5,
        min_child_samples=15, random_state=42, verbosity=-1,
    )
    model.fit(train[FEATURE_COLS], train["units_sold"])

    # residual std per SKU from in-sample fit, used for a simple interval
    train = train.copy()
    train["fitted"] = model.predict(train[FEATURE_COLS])
    resid_std = (train["units_sold"] - train["fitted"]).groupby(train["sku_id"]).std().fillna(
        (train["units_sold"] - train["fitted"]).std()
    )

    last_week = panel["week_start"].max()
    future_weeks = [last_week + pd.Timedelta(weeks=i) for i in range(1, HORIZON_WEEKS + 1)]

    rows = []
    for sku_id, sku_hist in panel.groupby("sku_id"):
        sku_hist = sku_hist.sort_values("week_start").copy()
        history_units = list(sku_hist["units_sold"])
        cat = sku_hist["category"].iloc[-1]
        list_price = sku_hist["list_price"].iloc[-1]

        for wk in future_weeks:
            lag_1 = history_units[-1] if len(history_units) >= 1 else 0
            lag_2 = history_units[-2] if len(history_units) >= 2 else lag_1
            lag_4 = history_units[-4] if len(history_units) >= 4 else lag_1
            lag_52 = history_units[-52] if len(history_units) >= 52 else np.nan
            roll_mean_4 = np.mean(history_units[-4:]) if history_units else 0
            roll_std_4 = np.std(history_units[-4:]) if len(history_units) >= 2 else 0
            roll_mean_8 = np.mean(history_units[-8:]) if history_units else 0

            feat = pd.DataFrame([{
                "lag_1": lag_1, "lag_2": lag_2, "lag_4": lag_4, "lag_52": lag_52,
                "roll_mean_4": roll_mean_4, "roll_std_4": roll_std_4, "roll_mean_8": roll_mean_8,
                "week_of_year": wk.isocalendar()[1], "month": wk.month,
                "is_holiday_week": int(wk.month in (11, 12)),
                "has_promo_event": 0, "promo_days": 0,
            }])
            pred = max(0.0, float(model.predict(feat[FEATURE_COLS])[0]))
            std = resid_std.get(sku_id, resid_std.mean())

            rows.append(dict(
                sku_id=sku_id, category=cat, list_price=list_price,
                week_start=wk, forecast_units=pred,
                forecast_low=max(0.0, pred - 1.28 * std),   # ~80% interval
                forecast_high=pred + 1.28 * std,
            ))
            history_units.append(pred)  # roll forward for next-step lags

    forecast_df = pd.DataFrame(rows)
    return forecast_df


def run():
    panel = pd.read_parquet(DATA_DIR / "processed_weekly.parquet")

    print("Rolling-origin backtest (baseline vs LightGBM)...")
    backtest = rolling_origin_backtest(panel)
    REPORTS_DIR.mkdir(exist_ok=True)
    backtest.to_csv(REPORTS_DIR / "backtest_results.csv", index=False)

    avg_wape_base = backtest["wape_baseline"].mean()
    avg_wape_model = backtest["wape_model"].mean()
    improvement = (avg_wape_base - avg_wape_model) / avg_wape_base * 100

    print(backtest.to_string(index=False))
    print()
    print(f"Average WAPE — seasonal-naive baseline: {avg_wape_base:.1%}")
    print(f"Average WAPE — LightGBM model:          {avg_wape_model:.1%}")
    if avg_wape_model < avg_wape_base:
        print(f"Model BEATS baseline by {improvement:.1f}% (relative WAPE reduction).")
    else:
        print("Model does NOT beat the baseline on this backtest — reporting the baseline as the finding.")

    print("\nTraining final model on full history and generating forecast...")
    forecast_df = train_final_model_and_forecast(panel)
    forecast_df.to_parquet(DATA_DIR / "forecast_output.parquet", index=False)
    print(f"  wrote data/forecast_output.parquet  ({len(forecast_df):,} rows, "
          f"{forecast_df['sku_id'].nunique()} SKUs x {HORIZON_WEEKS} weeks)")

    return backtest, forecast_df


if __name__ == "__main__":
    run()
