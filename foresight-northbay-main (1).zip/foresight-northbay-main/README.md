# Project FORESIGHT — Demand & Inventory Intelligence
**Client: NorthBay Living** · Zidio Data Science Internship · Data Scientist role

FORESIGHT turns NorthBay Living's raw sales and inventory extracts into a
weekly SKU-level demand forecast, a transparent stockout/overstock risk
score, a planning dashboard the ops team can use unaided, and a deployed
scoring service.

## 1. The problem

NorthBay Living (a D2C home & lifestyle brand) plans inventory on gut feel
and spreadsheets. Best-sellers stock out (lost sales); slow movers pile up
(cash locked in stock that later gets marked down). FORESIGHT gives the
Head of Operations, per SKU: **how much we'll likely sell over the next few
weeks, which products are about to run out, and which are overstocked.**

## 2. The data

Four extracts, matching the brief's star schema (`data/`):

| Table | Grain | Contents |
|---|---|---|
| `sales_daily.csv` | 1 row / SKU / day | units sold, revenue, price, promo flag |
| `sku_master.csv` | 1 row / SKU | category, subcategory, launch date, cost, price |
| `calendar.csv` | 1 row / date | week, month, season, holiday, promo events |
| `inventory_snapshots.csv` | periodic / SKU | on-hand, on-order, lead time, reorder point |

**This build uses NorthBay Living's real data** (`data/convert_real_data.py`
converts the client's Excel export — Products / Stores / Sales_Fact /
Inventory_Fact / Date_Dim sheets — into the brief's four-table schema,
aggregating the 10-store network to SKU level since the brief asks for
SKU-level forecasting). 511,280 sales rows and 511,280 inventory rows,
2021–2025, 28 SKUs.

Documented conversion assumptions (source data didn't include these
columns, so a reasonable default was used):
- No promotion flag in the source → `promo_flag` set to 0 for all rows.
- No on-order/in-transit stock column → `on_order_units` set to 0 (makes
  stockout risk slightly conservative, since any stock already in transit
  isn't counted as available).
- No holiday calendar → Dec 25/31 and Jan 1 flagged as holidays by default.

`data/generate_data.py` (synthetic data on the same schema) is kept for
reference/testing but is not what this build's numbers are based on.

## 3. Setup & run (reproduces end-to-end from raw data)

```bash
python -m venv venv && source venv/bin/activate     # optional but recommended
pip install -r requirements.txt

# 1. The four CSVs in data/ are already generated from NorthBay's real
#    Excel export. To regenerate them from the original Excel file:
#    python data/convert_real_data.py "path/to/Demand_Inventory_Dataset_5Yr.xlsx"
#    (Not required if data/*.csv are already present in this repo.)

# 2. D1 — ingest & clean into one analysis-ready weekly dataset
python src/pipeline.py

# 3. D3 — baseline + model, rolling-origin backtest, 8-week forecast
python src/forecast.py

# 4. D4 — stockout/overstock risk scoring + decisioning grid
python src/risk.py

# 5. D5 — planning dashboard
streamlit run app/app.py

# 6. D6 — scoring service (separate terminal)
uvicorn service.main:app --reload --port 8000
# then: curl http://127.0.0.1:8000/score/SKU0001
```

Each script is idempotent and re-runs from the previous step's output — a
grader can clone this repo, run the six commands above in order, and land
on the same headline numbers.

## 4. Backtest result (WAPE vs baseline)

Rolling-origin cross-validation, 6 folds, 8-week test windows each,
never a random split (see `src/forecast.py::rolling_origin_backtest` and
full fold-by-fold numbers in `reports/backtest_results.csv`):

| | Seasonal-naive baseline | LightGBM model |
|---|---|---|
| **Average WAPE** | 6.1% | **3.9%** |

The trained model beats the baseline by **35.8%** (relative WAPE
reduction), averaged across all 6 folds. No fold leaks future data into
training — the backtest is honest by construction, per the engagement's
non-negotiable rule (brief Section 07).

## 5. Risk scoring & decisioning

Every SKU is scored on two independent 0–1 risk axes and placed into one
of four quadrants (brief Section 08):

| Quadrant | Meaning | Action |
|---|---|---|
| Reorder Now | High stockout risk, low overstock | Raise a replenishment order |
| Markdown / Clear | High overstock, low stockout | Promote or discount |
| Watch / Volatile | High on both | Investigate manually |
| Healthy | Low on both | No action |

The logic is a transparent rule (not a black box) in `src/risk.py`:
stockout risk compares forecast demand over the SKU's own lead time
against on-hand + on-order stock; overstock risk compares on-hand stock
against demand over the SKU's own reorder cycle. Each SKU's rupee value at
stake (sales at risk or capital locked) is attached so the ops team can
prioritise.

## 6. Key assumptions

- The synthetic extracts are representative of NorthBay's real sales/inventory behaviour (per brief 16.1).
- Forecast horizon is 8 weeks; backtest uses 6 rolling folds of the same length.
- "Available stock" for stockout scoring = on-hand + on-order units.
- Overstock risk is judged against each SKU's own replenishment cycle (lead time + review buffer), not a single fleet-wide threshold — a fast-cycling SKU and a slow-cycling SKU shouldn't be held to the same "weeks of cover" bar.
- Random seed is fixed (`RNG = np.random.default_rng(42)`) so results are reproducible.

## 7. Repository structure

```
foresight/
  data/               generate_data.py + raw & processed extracts
  src/
    pipeline.py       D1 — ingest & clean
    forecast.py       D3 — baseline, model, rolling-origin backtest, WAPE
    risk.py           D4 — stockout/overstock scoring + decisioning grid
  app/app.py          D5 — Streamlit planning dashboard
  service/
    main.py           D6 — FastAPI scoring service
    Dockerfile
  reports/
    data_quality_eda_memo.md    D2
    backtest_results.csv
    executive_readout.md        D7
  requirements.txt
  README.md
```

## 8. Limitations, honestly

- The model beats the baseline on average, but fold 0 (the most recent,
  holiday-heavy window) has the highest WAPE for both — year-end demand is
  the hardest to call and worth extra manual review during Nov–Dec.
- Risk thresholds (0.5 on each axis) are a reasonable starting rule, not
  tuned against real markdown/stockout outcomes — the natural next step
  once NorthBay's actual decisions are logged.
- This is trained on synthetic data recreated from the brief's schema; the
  pipeline is what should transfer to the real client extract, not the
  specific numbers reported here.

## 9. Future scope

SARIMA/Prophet for explicit seasonal decomposition as a second model to
compare against LightGBM; product-segmentation via K-Means; connecting the
pipeline to a live/refreshing data source instead of a static extract.
