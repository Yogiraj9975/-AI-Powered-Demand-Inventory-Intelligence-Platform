"""
D6 — Deployed scoring service (FastAPI)

Returns forecast + risk for a given SKU (or a batch), documented inputs and
outputs, and handles bad input gracefully instead of crashing.

Run locally:
    uvicorn service.main:app --reload --port 8000

Then:
    GET  /health
    GET  /skus
    GET  /score/{sku_id}
    POST /score/batch      body: {"sku_ids": ["SKU0001", "SKU0002"]}

Deploy (free options): Render, Railway, or Hugging Face Spaces (Docker).
A minimal Dockerfile is provided alongside this file.
"""
from pathlib import Path
from typing import List, Optional

import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

DATA_DIR = Path(__file__).parent.parent / "data"

app = FastAPI(
    title="FORESIGHT Scoring Service",
    description="Forecast + stockout/overstock risk scoring for NorthBay Living SKUs.",
    version="1.0.0",
)

_forecast_df: Optional[pd.DataFrame] = None
_risk_df: Optional[pd.DataFrame] = None


def _load():
    global _forecast_df, _risk_df
    if _forecast_df is None or _risk_df is None:
        forecast_path = DATA_DIR / "forecast_output.parquet"
        risk_path = DATA_DIR / "risk_output.parquet"
        if not forecast_path.exists() or not risk_path.exists():
            raise FileNotFoundError(
                "Model outputs not found. Run: python src/pipeline.py && "
                "python src/forecast.py && python src/risk.py"
            )
        _forecast_df = pd.read_parquet(forecast_path)
        _risk_df = pd.read_parquet(risk_path)
    return _forecast_df, _risk_df


class BatchRequest(BaseModel):
    sku_ids: List[str]


class WeeklyForecast(BaseModel):
    week_start: str
    forecast_units: float
    forecast_low: float
    forecast_high: float


class SkuScore(BaseModel):
    sku_id: str
    category: str
    quadrant: str
    recommended_action: str
    stockout_risk: float
    overstock_risk: float
    rupee_value_at_stake: float
    avg_weekly_demand: float
    on_hand_units: float
    forecast: List[WeeklyForecast]


@app.get("/health")
def health():
    try:
        _load()
        return {"status": "ok"}
    except FileNotFoundError as e:
        return {"status": "not_ready", "detail": str(e)}


@app.get("/skus")
def list_skus():
    """List all SKU ids the service can score."""
    try:
        _, risk_df = _load()
    except FileNotFoundError as e:
        raise HTTPException(status_code=503, detail=str(e))
    return {"sku_ids": sorted(risk_df["sku_id"].unique().tolist())}


def _score_one(sku_id: str, forecast_df: pd.DataFrame, risk_df: pd.DataFrame) -> SkuScore:
    risk_row = risk_df[risk_df["sku_id"] == sku_id]
    if risk_row.empty:
        raise HTTPException(status_code=404, detail=f"Unknown sku_id: '{sku_id}'")
    r = risk_row.iloc[0]

    fc = forecast_df[forecast_df["sku_id"] == sku_id].sort_values("week_start")
    weekly = [
        WeeklyForecast(
            week_start=str(pd.Timestamp(row.week_start).date()),
            forecast_units=round(float(row.forecast_units), 2),
            forecast_low=round(float(row.forecast_low), 2),
            forecast_high=round(float(row.forecast_high), 2),
        )
        for row in fc.itertuples()
    ]

    return SkuScore(
        sku_id=sku_id,
        category=str(r["category"]),
        quadrant=str(r["quadrant"]),
        recommended_action=str(r["recommended_action"]),
        stockout_risk=round(float(r["stockout_risk"]), 4),
        overstock_risk=round(float(r["overstock_risk"]), 4),
        rupee_value_at_stake=round(float(r["rupee_value_at_stake"]), 2),
        avg_weekly_demand=round(float(r["avg_weekly_demand"]), 2),
        on_hand_units=float(r["on_hand_units"]),
        forecast=weekly,
    )


@app.get("/score/{sku_id}", response_model=SkuScore)
def score_sku(sku_id: str):
    """Return the 8-week forecast and current risk/decision for one SKU."""
    try:
        forecast_df, risk_df = _load()
    except FileNotFoundError as e:
        raise HTTPException(status_code=503, detail=str(e))
    return _score_one(sku_id.strip().upper(), forecast_df, risk_df)


@app.post("/score/batch", response_model=List[SkuScore])
def score_batch(req: BatchRequest):
    """Return forecast + risk for a batch of SKU ids. Unknown ids in the
    batch are reported individually rather than failing the whole request."""
    if not req.sku_ids:
        raise HTTPException(status_code=400, detail="sku_ids must not be empty")
    try:
        forecast_df, risk_df = _load()
    except FileNotFoundError as e:
        raise HTTPException(status_code=503, detail=str(e))

    results = []
    errors = []
    for sku_id in req.sku_ids:
        try:
            results.append(_score_one(sku_id.strip().upper(), forecast_df, risk_df))
        except HTTPException as e:
            errors.append({"sku_id": sku_id, "error": e.detail})
    if errors and not results:
        raise HTTPException(status_code=404, detail=errors)
    return results
