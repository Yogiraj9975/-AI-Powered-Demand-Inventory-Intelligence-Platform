"""
D5 — Planning Dashboard (Streamlit)

Multi-tab layout modelled on the original 12-page Power BI report, rebuilt
on top of the FORESIGHT pipeline outputs (forecast + risk scoring), for
the NorthBay Living ops team.

Sidebar filters — Year, Region, Category, SKU, Risk quadrant — apply
consistently across every tab that can support them. The forecast/risk
model itself is trained at the network SKU level (per the brief's scope),
so the Forecast & Risk and Recommendations tabs show the whole business
regardless of Region — this is called out explicitly in-app rather than
silently ignoring the filter.

Run:
    streamlit run app/app.py
"""
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

DATA_DIR = Path(__file__).parent.parent / "data"
REPORTS_DIR = Path(__file__).parent.parent / "reports"

st.set_page_config(page_title="FORESIGHT — NorthBay Living", layout="wide", page_icon="📦")

MONTH_NAMES = {1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
               7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec"}


@st.cache_data
def load_data():
    panel = pd.read_parquet(DATA_DIR / "processed_weekly.parquet")
    forecast = pd.read_parquet(DATA_DIR / "forecast_output.parquet")
    risk = pd.read_parquet(DATA_DIR / "risk_output.parquet")
    sku_master = pd.read_csv(DATA_DIR / "sku_master.csv")
    backtest_path = REPORTS_DIR / "backtest_results.csv"
    backtest = pd.read_csv(backtest_path) if backtest_path.exists() else pd.DataFrame()
    store_path = DATA_DIR / "store_summary.csv"
    store_summary = pd.read_csv(store_path) if store_path.exists() else pd.DataFrame()
    inv_trend_path = DATA_DIR / "inventory_monthly_trend.csv"
    inv_trend = pd.read_csv(inv_trend_path, parse_dates=["month"]) if inv_trend_path.exists() else pd.DataFrame()
    stockout_sku_path = DATA_DIR / "stockout_by_sku.csv"
    stockout_by_sku = pd.read_csv(stockout_sku_path) if stockout_sku_path.exists() else pd.DataFrame()
    inv_levels_path = DATA_DIR / "inventory_levels_by_sku.csv"
    inv_levels = pd.read_csv(inv_levels_path) if inv_levels_path.exists() else pd.DataFrame()
    region_path = DATA_DIR / "region_weekly.csv"
    region_weekly = pd.read_csv(region_path, parse_dates=["week_start"]) if region_path.exists() else pd.DataFrame()
    inv_region_path = DATA_DIR / "inventory_region_monthly.csv"
    inv_region = pd.read_csv(inv_region_path, parse_dates=["month"]) if inv_region_path.exists() else pd.DataFrame()
    return (panel, forecast, risk, sku_master, backtest, store_summary,
            inv_trend, stockout_by_sku, inv_levels, region_weekly, inv_region)


# ---------- Loading state ----------
if not (DATA_DIR / "risk_output.parquet").exists():
    st.warning(
        "No data found yet. Run the pipeline first:\n\n"
        "```\npython data/convert_real_data.py <excel_path>\npython src/pipeline.py\n"
        "python src/forecast.py\npython src/risk.py\n```"
    )
    st.stop()

(panel, forecast, risk, sku_master, backtest, store_summary,
 inv_trend, stockout_by_sku, inv_levels, region_weekly, inv_region) = load_data()

panel["unit_cost"] = panel["sku_id"].map(sku_master.set_index("sku_id")["unit_cost"])
panel["profit"] = panel["revenue"] - panel["units_sold"] * panel["unit_cost"]

HAS_REGION = not region_weekly.empty
HAS_INV_REGION = not inv_region.empty
if HAS_INV_REGION:
    inv_region["year"] = inv_region["month"].dt.year
if HAS_REGION:
    region_weekly["unit_cost"] = region_weekly["sku_id"].map(sku_master.set_index("sku_id")["unit_cost"])
    region_weekly["profit"] = region_weekly["revenue"] - region_weekly["units_sold"] * region_weekly["unit_cost"]
    region_weekly["month"] = region_weekly["week_start"].dt.month
    region_weekly["year"] = region_weekly["week_start"].dt.year
    region_weekly["quarter"] = region_weekly["week_start"].dt.quarter

st.title("📦 FORESIGHT — Demand & Inventory Intelligence")
st.caption("Prepared for **NorthBay Living** · Planning dashboard for the Operations team")

# ---------- Sidebar filters ----------
st.sidebar.header("Filters")

year_counts = panel["week_start"].dt.year.value_counts()
valid_years = sorted(year_counts[year_counts >= 10].index.tolist())  # drop stray boundary weeks
sel_year = st.sidebar.selectbox("Year", ["All"] + valid_years)

region_options = ["All"] + sorted(region_weekly["region"].unique().tolist()) if HAS_REGION else ["All"]
sel_region = st.sidebar.selectbox("Region", region_options)

categories = ["All"] + sorted(risk["category"].unique().tolist())
sel_category = st.sidebar.selectbox("Category", categories)

sku_options = risk["sku_id"].tolist()
if sel_category != "All":
    sku_options = risk.loc[risk["category"] == sel_category, "sku_id"].tolist()
sel_sku = st.sidebar.selectbox("SKU (for the detail chart)", ["All"] + sku_options)

quadrant_filter = st.sidebar.multiselect(
    "Risk quadrant", options=risk["quadrant"].unique().tolist(),
    default=risk["quadrant"].unique().tolist(),
)

active_filters = [f for f in [
    f"Year: {sel_year}" if sel_year != "All" else None,
    f"Region: {sel_region}" if sel_region != "All" else None,
    f"Category: {sel_category}" if sel_category != "All" else None,
] if f]
if active_filters:
    st.sidebar.caption("Active: " + " · ".join(active_filters))

# risk_f — used by Forecast & Risk / Recommendations (SKU-level, category only —
# the model doesn't have a region dimension since forecasting is done at the
# network SKU level, per the brief's scope)
risk_f = risk[risk["quadrant"].isin(quadrant_filter)]
if sel_category != "All":
    risk_f = risk_f[risk_f["category"] == sel_category]

# df_f — the general-purpose filtered dataframe used by every revenue/units
# chart across tabs. Built from region_weekly (which retains Region) so that
# Year + Region + Category all apply consistently everywhere.
if HAS_REGION:
    df_f = region_weekly.copy()
    if sel_year != "All":
        df_f = df_f[df_f["year"] == sel_year]
    if sel_region != "All":
        df_f = df_f[df_f["region"] == sel_region]
    if sel_category != "All":
        df_f = df_f[df_f["category"] == sel_category]
else:
    # fallback if region_weekly.csv wasn't generated — filters just apply to
    # Year + Category, Region filter has no effect
    df_f = panel.copy()
    if sel_year != "All":
        df_f = df_f[df_f["week_start"].dt.year == sel_year]
    if sel_category != "All":
        df_f = df_f[df_f["category"] == sel_category]

# ---------- Top-line KPIs (respond to Year + Region + Category) ----------
total_revenue = df_f["revenue"].sum()
total_units = df_f["units_sold"].sum()
total_profit = df_f["profit"].sum()
margin_pct = total_profit / total_revenue * 100 if total_revenue else 0

k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Total revenue", f"₹{total_revenue/1e7:.2f} Cr")
k2.metric("Total units sold", f"{total_units/1e6:.2f}M")
k3.metric("Total profit", f"₹{total_profit/1e7:.2f} Cr")
k4.metric("Profit margin", f"{margin_pct:.1f}%")
k5.metric("Reorder Now SKUs", f"{(risk_f['quadrant'] == 'Reorder Now').sum()} / {risk_f['sku_id'].nunique()}")

if not backtest.empty:
    wape_base = backtest["wape_baseline"].mean()
    wape_model = backtest["wape_model"].mean()
    improvement = (wape_base - wape_model) / wape_base * 100
    st.info(
        f"**Forecast accuracy (rolling-origin backtest):** model WAPE **{wape_model:.1%}** "
        f"vs seasonal-naive baseline **{wape_base:.1%}** "
        f"({'beats' if wape_model < wape_base else 'does not beat'} baseline by {abs(improvement):.1f}%)."
    )

if df_f.empty:
    st.warning("No data matches the current filter combination. Try widening a filter.")
    st.stop()

st.divider()

tabs = st.tabs([
    "🏠 Executive", "📊 Sales Analytics", "🏆 Product Performance", "🏷️ Category",
    "🗺️ Store & Region", "📦 Inventory", "🔴 Stockout Risk", "🔵 Overstock",
    "📅 Seasonality", "🔮 Forecast", "✅ Recommendations",
])

# ============================================================ Executive ===
with tabs[0]:
    st.subheader("Executive Overview")
    c1, c2 = st.columns([1.4, 1])
    with c1:
        monthly = df_f.groupby(df_f["week_start"].dt.to_period("M"))["revenue"].sum().reset_index()
        monthly["month_ts"] = monthly["week_start"].dt.to_timestamp()
        fig = px.bar(monthly, x="month_ts", y="revenue", title="Revenue Trend",
                     labels={"revenue": "Revenue (₹)", "month_ts": ""})
        fig.update_traces(marker_color="#1f77b4")
        fig.update_layout(height=320, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        cat_rev = df_f.groupby("category")["revenue"].sum().reset_index()
        fig = px.pie(cat_rev, names="category", values="revenue", hole=0.5, title="Revenue by Category")
        fig.update_layout(height=320)
        st.plotly_chart(fig, use_container_width=True)

    c3, c4 = st.columns(2)
    with c3:
        reg_rev = df_f.groupby("region")["revenue"].sum().sort_values().reset_index() if HAS_REGION else pd.DataFrame()
        if not reg_rev.empty:
            fig = px.bar(reg_rev, x="revenue", y="region", orientation="h", title="Revenue by Region",
                         labels={"revenue": "Revenue (₹)", "region": ""})
            fig.update_traces(marker_color="#d62728")
            fig.update_layout(height=300, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Region data not available.")
    with c4:
        top5 = df_f.groupby("sku_id")["revenue"].sum().sort_values(ascending=False).head(5).reset_index()
        fig = px.bar(top5.sort_values("revenue"), x="revenue", y="sku_id", orientation="h",
                     title="Top 5 SKUs by Revenue", labels={"revenue": "Revenue (₹)", "sku_id": ""})
        fig.update_traces(marker_color="#2ca02c")
        fig.update_layout(height=300, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

# ======================================================= Sales Analytics ===
with tabs[1]:
    st.subheader("Sales Analytics")
    weekly = df_f.groupby("week_start").agg(units_sold=("units_sold", "sum"),
                                             revenue=("revenue", "sum")).reset_index()
    fig = go.Figure()
    fig.add_trace(go.Bar(x=weekly["week_start"], y=weekly["units_sold"], name="Units Sold", yaxis="y1"))
    fig.add_trace(go.Scatter(x=weekly["week_start"], y=weekly["revenue"], name="Revenue",
                              yaxis="y2", line=dict(color="orange")))
    fig.update_layout(
        title="Dual-axis Trend — Units Sold vs Revenue", height=380,
        yaxis=dict(title="Units sold"), yaxis2=dict(title="Revenue (₹)", overlaying="y", side="right"),
    )
    st.plotly_chart(fig, use_container_width=True)

    c1, c2 = st.columns(2)
    with c1:
        if not store_summary.empty:
            s = store_summary.copy()
            if sel_region != "All":
                s = s[s["region"] == sel_region]
            s = s.sort_values("revenue")
            fig = px.bar(s, x="revenue", y="store_name", orientation="h", title="Sales by Store",
                         labels={"revenue": "Revenue (₹)", "store_name": ""})
            fig.update_traces(marker_color="#1f77b4")
            fig.update_layout(height=380, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
            if sel_category != "All" or sel_year != "All":
                st.caption("Store totals are for all categories/years (store data isn't broken down that far).")
    with c2:
        cat_prod = df_f.groupby(["category", "sku_id"])["revenue"].sum().reset_index()
        fig = px.treemap(cat_prod, path=["category", "sku_id"], values="revenue",
                          title="Category → Product Revenue Breakdown")
        fig.update_layout(height=380)
        st.plotly_chart(fig, use_container_width=True)

# ==================================================== Product Performance ===
with tabs[2]:
    st.subheader("Product Performance")
    prod = df_f.groupby("sku_id").agg(
        revenue=("revenue", "sum"), units_sold=("units_sold", "sum"), profit=("profit", "sum"),
    ).reset_index()
    prod["margin_pct"] = np.where(prod["revenue"] > 0, prod["profit"] / prod["revenue"] * 100, 0)
    prod = prod.merge(sku_master[["sku_id", "category"]], on="sku_id", how="left")

    if prod.empty:
        st.info("No products match the current filter.")
    else:
        c1, c2 = st.columns(2)
        with c1:
            top15 = prod.sort_values("revenue", ascending=False).head(15).sort_values("revenue")
            fig = px.bar(top15, x="revenue", y="sku_id", orientation="h", title="Top Products by Revenue",
                         labels={"revenue": "Revenue (₹)", "sku_id": ""})
            fig.update_traces(marker_color="#d62728")
            fig.update_layout(height=460, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
        with c2:
            margin_sorted = prod.sort_values("margin_pct", ascending=False).head(15).sort_values("margin_pct")
            fig = px.bar(margin_sorted, x="margin_pct", y="sku_id", orientation="h",
                         title="Profit Margin % by Product", labels={"margin_pct": "Margin %", "sku_id": ""})
            fig.update_traces(marker_color="#f1c40f")
            fig.update_layout(height=460, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)

        fig = px.scatter(prod, x="units_sold", y="revenue", size=prod["profit"].clip(lower=1),
                          color="category", hover_data=["sku_id", "margin_pct"],
                          title="Product Performance Matrix — Volume vs Revenue")
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)

        st.markdown("**Product Performance Scorecard**")
        scorecard = prod[["sku_id", "category", "units_sold", "revenue", "margin_pct"]].sort_values(
            "revenue", ascending=False
        )
        scorecard.columns = ["SKU", "Category", "Units Sold", "Revenue (₹)", "Margin %"]
        st.dataframe(scorecard, use_container_width=True, hide_index=True)

# ============================================================= Category ===
with tabs[3]:
    st.subheader("Category Performance")
    st.caption("Respects Year/Region filters. Category filter itself is ignored here on purpose "
               "(the point of this tab is comparing categories against each other).")
    df_cat_base = df_f.copy()
    if sel_category != "All":
        # this tab always compares ALL categories, so re-derive from the
        # Year/Region-filtered (but not Category-filtered) data
        if HAS_REGION:
            df_cat_base = region_weekly.copy()
            if sel_year != "All":
                df_cat_base = df_cat_base[df_cat_base["year"] == sel_year]
            if sel_region != "All":
                df_cat_base = df_cat_base[df_cat_base["region"] == sel_region]
        else:
            df_cat_base = panel.copy()
            if sel_year != "All":
                df_cat_base = df_cat_base[df_cat_base["week_start"].dt.year == sel_year]

    cat = df_cat_base.groupby("category").agg(
        revenue=("revenue", "sum"), units_sold=("units_sold", "sum"), profit=("profit", "sum"),
    ).reset_index()
    cat["margin_pct"] = np.where(cat["revenue"] > 0, cat["profit"] / cat["revenue"] * 100, 0)

    c1, c2, c3 = st.columns(3)
    with c1:
        fig = px.bar(cat.sort_values("revenue", ascending=False), x="category", y="revenue",
                     title="Revenue by Category", color="category")
        fig.update_layout(height=340, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        fig = px.bar(cat.sort_values("units_sold", ascending=False), x="category", y="units_sold",
                     title="Units Sold by Category", color="category")
        fig.update_layout(height=340, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    with c3:
        fig = px.bar(cat.sort_values("margin_pct", ascending=False), x="category", y="margin_pct",
                     title="Profit Margin % by Category", color="category")
        fig.update_layout(height=340, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    cat_trend = df_cat_base.groupby([df_cat_base["week_start"].dt.to_period("M"), "category"])["revenue"].sum().reset_index()
    cat_trend["month_ts"] = cat_trend["week_start"].dt.to_timestamp()
    fig = px.area(cat_trend, x="month_ts", y="revenue", color="category", title="Category Revenue Trend Over Time")
    fig.update_layout(height=380)
    st.plotly_chart(fig, use_container_width=True)

# ========================================================= Store & Region ===
with tabs[4]:
    st.subheader("Store & Region Performance")
    if store_summary.empty:
        st.info("Store-level data not available in this build.")
    else:
        s = store_summary.copy()
        if sel_region != "All":
            s = s[s["region"] == sel_region]
        if sel_category != "All" or sel_year != "All":
            st.caption("Store totals are for all categories/years (store data isn't broken down that far).")

        c1, c2 = st.columns(2)
        with c1:
            reg = s.groupby("region")["revenue"].sum().sort_values(ascending=False).reset_index()
            fig = px.bar(reg, x="region", y="revenue", title="Revenue Contribution by Region", color="region")
            fig.update_layout(height=350, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
        with c2:
            s_sorted = s.sort_values("revenue", ascending=False)
            fig = px.bar(s_sorted, x="revenue", y="store_name", orientation="h", title="Store Performance Ranking",
                         labels={"revenue": "Revenue (₹)", "store_name": ""}, color="region")
            fig.update_layout(height=350)
            st.plotly_chart(fig, use_container_width=True)
        st.markdown("**Store Summary Table**")
        st.dataframe(s.sort_values("revenue", ascending=False), use_container_width=True, hide_index=True)

# ============================================================= Inventory ===
with tabs[5]:
    st.subheader("Inventory")
    if not HAS_INV_REGION:
        st.info("Inventory detail files not found. Run `python data/convert_real_data.py <excel>` again.")
    else:
        inv_f = inv_region.copy()
        if sel_year != "All":
            inv_f = inv_f[inv_f["year"] == sel_year]
        if sel_region != "All":
            inv_f = inv_f[inv_f["region"] == sel_region]
        if sel_category != "All":
            inv_f = inv_f[inv_f["category"] == sel_category]

        if inv_f.empty:
            st.warning("No inventory data matches the current filter combination.")
        else:
            trend = inv_f.groupby("month").agg(
                stock_received=("stock_received", "sum"), stock_on_hand=("stock_on_hand", "sum"),
                stockout_days=("stockout_days", "sum"),
            ).reset_index()
            levels_by_sku = inv_f.groupby("sku_id")["stock_on_hand"].mean().sort_values(ascending=False).reset_index()
            stockout_sku_f = inv_f.groupby("sku_id")["stockout_days"].sum().sort_values(ascending=False).reset_index()

            c1, c2 = st.columns([1.4, 1])
            with c1:
                fig = go.Figure()
                fig.add_trace(go.Bar(x=trend["month"], y=trend["stock_received"], name="Stock Received"))
                fig.add_trace(go.Scatter(x=trend["month"], y=trend["stock_on_hand"], name="Stock On Hand",
                                          line=dict(color="orange")))
                fig.update_layout(title="Stock Received vs Stock On Hand — Monthly Trend", height=360)
                st.plotly_chart(fig, use_container_width=True)
            with c2:
                top_levels = levels_by_sku.head(10).sort_values("stock_on_hand")
                fig = px.bar(top_levels, x="stock_on_hand", y="sku_id", orientation="h",
                             title="Avg Inventory Levels by Product", labels={"stock_on_hand": "Avg stock on hand", "sku_id": ""})
                fig.update_traces(marker_color="#d62728")
                fig.update_layout(height=360, showlegend=False)
                st.plotly_chart(fig, use_container_width=True)

            c3, c4 = st.columns(2)
            with c3:
                fig = px.bar(trend, x="month", y="stockout_days", title="Stockout Occurrences Over Time",
                             color_discrete_sequence=["#9b59b6"])
                fig.update_layout(height=340, showlegend=False)
                st.plotly_chart(fig, use_container_width=True)
            with c4:
                top_stockout = stockout_sku_f.head(10).sort_values("stockout_days")
                fig = px.bar(top_stockout, x="stockout_days", y="sku_id", orientation="h",
                             title="Top Products by Stockout Frequency",
                             labels={"stockout_days": "Stockout days", "sku_id": ""})
                fig.update_traces(marker_color="#9b59b6")
                fig.update_layout(height=340, showlegend=False)
                st.plotly_chart(fig, use_container_width=True)

# =========================================================== Seasonality ===
with tabs[8]:
    st.subheader("Seasonality")
    monthly_season = df_f.groupby("month")["units_sold"].mean().reset_index()
    monthly_season["month_name"] = monthly_season["month"].map(MONTH_NAMES)
    c1, c2 = st.columns(2)
    with c1:
        fig = px.bar(monthly_season, x="month_name", y="units_sold",
                     category_orders={"month_name": list(MONTH_NAMES.values())},
                     title="Monthly Sales Seasonality — Avg Units/Week", color_discrete_sequence=["#2ca02c"])
        fig.update_layout(height=360, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        q = df_f.groupby("quarter")["revenue"].sum().reset_index() if HAS_REGION else pd.DataFrame()
        if not q.empty:
            fig = px.bar(q, x="quarter", y="revenue", title="Quarterly Sales Pattern",
                         color_discrete_sequence=["#e74c3c"])
            fig.update_layout(height=360, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)

    if HAS_REGION:
        yoy = df_f.groupby(["year", "month"])["revenue"].sum().reset_index()
        yoy["month_name"] = yoy["month"].map(MONTH_NAMES)
        fig = px.line(yoy, x="month_name", y="revenue", color="year",
                      category_orders={"month_name": list(MONTH_NAMES.values())},
                      title="Year-over-Year Revenue Comparison")
        fig.update_layout(height=380)
        st.plotly_chart(fig, use_container_width=True)

# =========================================================== Stockout Risk ===
with tabs[6]:
    st.subheader("Stockout Risk")
    st.caption("Category filter applies. Year/Region don't (risk model is a current SKU-level snapshot).")
    stockout_occurrences = None
    if HAS_INV_REGION:
        inv_all = inv_region.copy()
        if sel_category != "All":
            inv_all = inv_all[inv_all["category"] == sel_category]
        stockout_occurrences = int(inv_all["stockout_days"].sum()) if not inv_all.empty else 0

    k1, k2 = st.columns(2)
    k1.metric("Total stockout occurrences (period)", f"{stockout_occurrences:,}" if stockout_occurrences is not None else "n/a")
    k2.metric("SKUs at stockout risk (Reorder Now)", f"{(risk_f['quadrant'] == 'Reorder Now').sum()}")

    if HAS_INV_REGION:
        inv_so = inv_region.copy()
        if sel_category != "All":
            inv_so = inv_so[inv_so["category"] == sel_category]
        c1, c2 = st.columns(2)
        with c1:
            trend = inv_so.groupby("month")["stockout_days"].sum().reset_index()
            fig = px.bar(trend, x="month", y="stockout_days", title="Stockout Occurrences Over Time",
                         color_discrete_sequence=["#9b59b6"])
            fig.update_layout(height=360, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
        with c2:
            top_so = inv_so.groupby("sku_id")["stockout_days"].sum().sort_values(ascending=False).head(10).sort_values()
            fig = px.bar(top_so.reset_index(), x="stockout_days", y="sku_id", orientation="h",
                         title="Top Products by Stockout Frequency",
                         labels={"stockout_days": "Stockout days", "sku_id": ""})
            fig.update_traces(marker_color="#9b59b6")
            fig.update_layout(height=360, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)

    st.markdown("**Reorder Alert List**")
    reorder = risk_f[risk_f["quadrant"] == "Reorder Now"].sort_values("rupee_value_at_stake", ascending=False)
    st.dataframe(reorder[["sku_id", "category", "on_hand_units", "avg_weekly_demand", "lead_time_days",
                           "sales_at_risk_rs", "recommended_action"]], use_container_width=True, hide_index=True)
    if reorder.empty:
        st.caption("No SKUs currently flagged for reorder in this filter.")

# =============================================================== Overstock ===
with tabs[7]:
    st.subheader("Overstock")
    st.caption("Category filter applies. Year/Region don't (risk model is a current SKU-level snapshot).")
    k1, k2 = st.columns(2)
    k1.metric("Capital locked in overstock", f"₹{risk_f['capital_locked_rs'].sum()/1e5:.1f} lakh")
    k2.metric("SKUs flagged Markdown/Clear", f"{(risk_f['quadrant'] == 'Markdown / Clear').sum()}")

    c1, c2 = st.columns(2)
    with c1:
        excess = risk_f.sort_values("on_hand_units", ascending=False).head(10).sort_values("on_hand_units")
        fig = px.bar(excess, x="on_hand_units", y="sku_id", orientation="h",
                     title="Products with Excess Inventory", labels={"on_hand_units": "Stock on hand", "sku_id": ""})
        fig.update_traces(marker_color="#3498db")
        fig.update_layout(height=380, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        by_value = risk_f.sort_values("capital_locked_rs", ascending=False).head(10).sort_values("capital_locked_rs")
        fig = px.bar(by_value, x="capital_locked_rs", y="sku_id", orientation="h",
                     title="Overstock Value by Product", labels={"capital_locked_rs": "Capital locked (₹)", "sku_id": ""})
        fig.update_traces(marker_color="#3498db")
        fig.update_layout(height=380, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("**Slow-Moving Inventory — Action Required**")
    markdown = risk_f[risk_f["quadrant"] == "Markdown / Clear"].sort_values("rupee_value_at_stake", ascending=False)
    st.dataframe(markdown[["sku_id", "category", "on_hand_units", "avg_weekly_demand",
                            "capital_locked_rs", "recommended_action"]], use_container_width=True, hide_index=True)
    if markdown.empty:
        st.caption("No SKUs currently flagged for markdown — inventory is running lean, not excess.")

# ================================================================ Forecast ===
with tabs[9]:
    st.subheader("Demand & Revenue Forecast")
    st.caption("Modelled at the network SKU level — Year/Region filters don't apply; Category filter does.")

    fc_f = forecast.copy()
    hist_f = panel.copy()
    if sel_category != "All":
        fc_f = fc_f[fc_f["category"] == sel_category]
        hist_f = hist_f[hist_f["category"] == sel_category]

    hist_agg = hist_f.groupby("week_start").agg(units_sold=("units_sold", "sum"), revenue=("revenue", "sum")).reset_index()
    fut_agg = fc_f.groupby("week_start").agg(
        forecast_units=("forecast_units", "sum"),
        forecast_low=("forecast_low", "sum"),
        forecast_high=("forecast_high", "sum"),
    ).reset_index()
    fut_agg["forecast_revenue"] = fc_f.groupby("week_start").apply(
        lambda g: (g["forecast_units"] * g["list_price"]).sum()
    ).values

    c1, c2 = st.columns(2)
    with c1:
        f = go.Figure()
        f.add_trace(go.Scatter(x=hist_agg["week_start"], y=hist_agg["units_sold"], name="Actual", line=dict(color="black")))
        f.add_trace(go.Scatter(x=fut_agg["week_start"], y=fut_agg["forecast_units"], name="Forecast", line=dict(color="#f39c12")))
        f.add_trace(go.Scatter(
            x=list(fut_agg["week_start"]) + list(fut_agg["week_start"])[::-1],
            y=list(fut_agg["forecast_high"]) + list(fut_agg["forecast_low"])[::-1],
            fill="toself", fillcolor="rgba(243,156,18,0.15)", line=dict(color="rgba(0,0,0,0)"), name="80% interval",
        ))
        f.update_layout(title="Units Sold Forecast", height=380, xaxis_title="Week", yaxis_title="Units/week")
        st.plotly_chart(f, use_container_width=True)
    with c2:
        f2 = go.Figure()
        f2.add_trace(go.Scatter(x=hist_agg["week_start"], y=hist_agg["revenue"], name="Actual", line=dict(color="black")))
        f2.add_trace(go.Scatter(x=fut_agg["week_start"], y=fut_agg["forecast_revenue"], name="Forecast", line=dict(color="#e74c3c")))
        f2.update_layout(title="Revenue Forecast", height=380, xaxis_title="Week", yaxis_title="Revenue (₹)")
        st.plotly_chart(f2, use_container_width=True)

    c3, c4 = st.columns(2)
    with c3:
        proj_prod = fc_f.groupby("sku_id")["forecast_units"].sum().sort_values(ascending=False).head(10).sort_values()
        fig = px.bar(proj_prod.reset_index(), x="forecast_units", y="sku_id", orientation="h",
                     title="Projected Product Demand — Next 8 Weeks", labels={"forecast_units": "Units", "sku_id": ""})
        fig.update_traces(marker_color="#9b59b6")
        fig.update_layout(height=340, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    with c4:
        proj_cat = fc_f.groupby("category")["forecast_units"].sum().sort_values(ascending=False).reset_index()
        fig = px.bar(proj_cat, x="category", y="forecast_units", title="Projected Category Demand — Next 8 Weeks",
                     color="category", labels={"forecast_units": "Units"})
        fig.update_layout(height=340, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Decisioning view — every SKU on a stockout vs overstock grid")
    fig = px.scatter(
        risk_f, x="overstock_risk", y="stockout_risk", color="quadrant",
        size=risk_f["rupee_value_at_stake"].clip(lower=1),
        hover_data=["sku_id", "category", "recommended_action", "rupee_value_at_stake"],
        color_discrete_map={
            "Reorder Now": "#d62728", "Markdown / Clear": "#1f77b4",
            "Watch / Volatile": "#ff7f0e", "Healthy": "#2ca02c",
        },
        labels={"overstock_risk": "Overstock risk →", "stockout_risk": "Stockout risk →"},
    )
    fig.add_vline(x=0.5, line_dash="dot", line_color="gray")
    fig.add_hline(y=0.5, line_dash="dot", line_color="gray")
    fig.update_layout(height=420)
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Forecast vs actual — single SKU")
    if sel_sku != "All":
        hist = panel[panel["sku_id"] == sel_sku][["week_start", "units_sold"]]
        fut = forecast[forecast["sku_id"] == sel_sku][["week_start", "forecast_units", "forecast_low", "forecast_high"]]
        f3 = go.Figure()
        f3.add_trace(go.Scatter(x=hist["week_start"], y=hist["units_sold"], name="Actual", line=dict(color="black")))
        f3.add_trace(go.Scatter(x=fut["week_start"], y=fut["forecast_units"], name="Forecast", line=dict(color="#1f77b4")))
        f3.add_trace(go.Scatter(
            x=list(fut["week_start"]) + list(fut["week_start"])[::-1],
            y=list(fut["forecast_high"]) + list(fut["forecast_low"])[::-1],
            fill="toself", fillcolor="rgba(31,119,180,0.15)", line=dict(color="rgba(0,0,0,0)"), name="80% interval",
        ))
        f3.update_layout(height=380, xaxis_title="Week", yaxis_title="Units / week")
        st.plotly_chart(f3, use_container_width=True)
    else:
        st.caption("Pick a SKU in the sidebar to see its individual forecast vs actual history.")

# ===================================================== Recommendations ===
with tabs[10]:
    st.subheader("Executive Recommendations")
    st.caption("Revenue insights below respect Year/Region/Category filters. Risk-based items "
               "(Highest Risk, Reorder/Markdown lists) respect Category only — the risk model is a "
               "current snapshot at the network SKU level, so it has no Year/Region dimension.")

    if df_f.empty:
        st.warning("No data matches the current filter combination.")
    else:
        top_cat = df_f.groupby("category")["revenue"].sum().idxmax()
        top_cat_rev = df_f.groupby("category")["revenue"].sum().max()
        best_seller = df_f.groupby("sku_id")["revenue"].sum().idxmax()
        best_seller_rev = df_f.groupby("sku_id")["revenue"].sum().max()

        c1, c2 = st.columns(2)
        c1.success(f"🏆 **Top Category:** {top_cat} (₹{top_cat_rev/1e7:.2f} Cr)")
        c2.success(f"⭐ **Best Seller:** {best_seller} (₹{best_seller_rev/1e7:.2f} Cr)")

    if risk_f.empty:
        st.info("No SKUs match the current Category/Risk-quadrant filter.")
    else:
        highest_risk = risk_f.sort_values("stockout_risk", ascending=False).iloc[0]
        c3, c4 = st.columns(2)
        c3.warning(f"⚠️ **Highest Risk:** {highest_risk['sku_id']} ({highest_risk['stockout_risk']:.0%} stockout risk)")
        c4.info(f"📈 **Sales at risk (8-week horizon):** ₹{risk_f['sales_at_risk_rs'].sum()/1e5:.1f} lakh")

        st.markdown("**Priority Reorder List**")
        reorder_all = risk_f[risk_f["quadrant"] == "Reorder Now"].sort_values("rupee_value_at_stake", ascending=False)
        if reorder_all.empty:
            st.caption("No SKUs currently flagged for reorder in this filter.")
        else:
            st.dataframe(reorder_all[["sku_id", "category", "on_hand_units", "lead_time_days",
                                      "sales_at_risk_rs", "recommended_action"]], use_container_width=True, hide_index=True)

        st.markdown("**Overstock / Clearance List**")
        markdown_all = risk_f[risk_f["quadrant"] == "Markdown / Clear"].sort_values("rupee_value_at_stake", ascending=False)
        if markdown_all.empty:
            st.caption("No SKUs currently flagged for markdown — inventory is running lean, not excess.")
        else:
            st.dataframe(markdown_all[["sku_id", "category", "on_hand_units", "capital_locked_rs",
                                       "recommended_action"]], use_container_width=True, hide_index=True)

st.divider()
if not backtest.empty:
    wape_base = backtest["wape_baseline"].mean()
    wape_model = backtest["wape_model"].mean()
    improvement = (wape_base - wape_model) / wape_base * 100
    st.caption(
        f"FORESIGHT · Forecast: LightGBM, rolling-origin backtested — WAPE {wape_model:.1%} vs "
        f"{wape_base:.1%} baseline ({improvement:.1f}% better). Risk logic: transparent rules-based scorer "
        f"on forecast + inventory position (see `src/risk.py`)."
    )
