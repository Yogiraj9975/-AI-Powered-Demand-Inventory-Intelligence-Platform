# Project FORESIGHT — Demand & Inventory Intelligence

**Client:** NorthBay Living (D2C home & lifestyle brand) · **Program:** Zidio Development Internship
**This repo currently contains:** the forecasting module (Milestones M2/M3, owner: **B — Data
Scientist / Forecasting Lead**). Folders for the other three team members' deliverables are
scaffolded and documented below so this merges cleanly with the rest of the team's work.

## 1. The problem

NorthBay Living stocks ~200 SKUs and plans inventory on gut feel and spreadsheets. They lose
money two ways at once: best-sellers stock out (lost sales), slow movers pile up (cash locked in
markdowns). This engagement turns their sales/inventory history into a demand forecast and an
early-warning system for what to reorder, clear, or leave alone. Full brief:
`Zidio_Project_Data_1_1.pdf` (not committed — internal/confidential per the brief).

## 2. The data

One workbook, four tables (see `reports/Data_Quality_EDA_Memo.md` §1-2 for full data-quality
notes):

| Table | Grain |
|---|---|
| `Products` | 1 row per product (28 products) |
| `Stores` | 1 row per store (10 stores, 4 regions) |
| `Sales_Fact` | 1 row per (Product, Store, Date) — 511,280 rows, 2021-01-01 → 2025-12-31 |
| `Inventory_Fact` | 1 row per (Product, Store, Date) — on-hand/on-order stock, lead time |
| `Date_Dim` | 1 row per calendar date |

**Data is not committed to this repo** (`.gitignore` excludes `data/raw/` and `data/processed/`)
per the brief's data-governance guidance — treat client data as confidential. Place the raw
workbook at `data/raw_source/Demand_Inventory_Dataset_5Yr.xlsx` and run the setup step below to
regenerate everything.

**Key assumption — "SKU" definition:** stock is held and reordered **per store**
(`Inventory_Fact` is at Product × Store grain), so this project defines **SKU = (ProductID,
StoreID)**, not ProductID alone. Product-level rollups are produced separately for
category/executive views. See the memo for the full reasoning and the schema difference from the
brief's generic description (no promo/holiday columns exist in the actual extract).

## 3. Setup & run steps (reproducibility)

```bash
python -m venv .venv && source .venv/bin/activate      # optional but recommended
pip install -r requirements.txt

# 1. Put the raw workbook where the loader expects the exported CSVs, e.g.:
python -c "
import pandas as pd
xl = pd.ExcelFile('PATH_TO/Demand_Inventory_Dataset_5Yr.xlsx')
for sn in xl.sheet_names:
    xl.parse(sn).to_csv(f'data/raw/{sn}.csv', index=False)
"

# 2. Run the notebooks in order (each is self-contained and re-executable end to end)
jupyter nbconvert --to notebook --execute --inplace notebooks/01_eda.ipynb
jupyter nbconvert --to notebook --execute --inplace notebooks/02_baseline.ipynb
jupyter nbconvert --to notebook --execute --inplace notebooks/03_model.ipynb
```

This regenerates `data/processed/weekly_panel.csv`, `final_forecast.csv`,
`final_forecast_product_level.csv`, `reports/backtest_summary.csv`, and every chart in
`reports/figures/` from the raw extract — no manual steps, no hidden state, matching the "one
command" reproducibility bar in Section 13 of the brief.

## 4. Forecast result (backtest vs. baseline)

Rolling-origin backtest, 6 origins over the last 12 months, 6-week horizon, all 280 SKUs, no
leakage (full methodology: `notebooks/03_model.ipynb`):

| | LightGBM model | Seasonal-naive baseline |
|---|---|---|
| **WAPE** | **6.6%** | 9.0% |
| **Bias** | −0.3% | −4.8% (systematically under-forecasts) |

**~27% relative WAPE reduction vs. baseline, consistent across all 6 forecast weeks.** See
`reports/figures/backtest_wape_by_horizon.png` and `reports/Data_Quality_EDA_Memo.md` §7 for the
full write-up, including why the baseline's negative bias is expected (every product in this
data grew year-over-year; a naive copy of last year structurally lags a growing trend).

## 5. Repository structure

```
foresight/
  data/
    raw/            # raw extracts as CSV (gitignored — see §2)
    processed/      # weekly_panel.csv, final_forecast*.csv (gitignored, regenerated)
  notebooks/
    01_eda.ipynb       # data quality + EDA insights            (owner: B)
    02_baseline.ipynb  # metric definition + seasonal-naive      (owner: B)
    03_model.ipynb     # features, model, backtest, final fc.    (owner: B)
  src/
    forecast.py     # reusable forecasting module (D3)           (owner: B)
    pipeline.py      # ingest + clean (D1)                       (owner: A — to be added)
    risk.py          # stockout/overstock scoring (D4)           (owner: C — to be added)
  app/               # Streamlit planning dashboard (D5)         (owner: D — to be added)
  service/           # FastAPI scoring service (D6)              (owner: D — to be added)
  reports/
    Data_Quality_EDA_Memo.md   # D2 (forecasting slice)          (owner: B)
    backtest_summary.csv
    figures/
  requirements.txt
```

## 6. Key assumptions & limitations (honest, per the brief's non-negotiable rule)

- SKU = (ProductID, StoreID) — see §2.
- No promotion/holiday-flag data exists in the actual extract; the model relies on calendar
  seasonality and each SKU's own history, not promo signals.
- Forecast assumes the next year's seasonal pattern resembles the last five years.
- Prediction intervals are empirical backtest-residual quantiles, not a formal statistical CI.
- Full detail: `reports/Data_Quality_EDA_Memo.md` §8 and `notebooks/03_model.ipynb` §3.7.

## 7. How this merges with the rest of the team

This module only touches `src/forecast.py`, `notebooks/0*.ipynb`, and its own reports/figures.
A's `src/pipeline.py`, C's `src/risk.py`, and D's `app/`/`service/` drop into the folders already
scaffolded above with no expected filename collisions (see the team's file-ownership convention
in the internal execution plan). `data/processed/final_forecast.csv` and
`final_forecast_product_level.csv` are the hand-off contract to C (risk scoring) and D
(dashboard/service) — see `notebooks/03_model.ipynb` §3.6 for the exact columns.
