# app/ — Planning Dashboard (D5)

**Owner: D — Product & Comms Engineer** (per the team execution plan).

This folder is reserved for the Streamlit planning dashboard. It should read:

- `data/processed/weekly_panel.csv` and `final_forecast.csv` / `final_forecast_product_level.csv`
  (produced by `notebooks/03_model.ipynb` / `src/forecast.py` — owner B)
- risk flags and recommended actions from `src/risk.py` (owner C)

to build the forecast-vs-actual view, risk flags, and prioritised reorder/markdown list
described in Section 09 (D5) of the engagement brief.
