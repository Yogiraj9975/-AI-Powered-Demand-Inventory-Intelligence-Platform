# service/ — Deployed Scoring Service (D6)

**Owner: D — Product & Comms Engineer** (per the team execution plan).

This folder is reserved for the FastAPI scoring service that returns forecast + risk for a
given SKU (ProductID, StoreID) or batch, per Section 09 (D6) of the engagement brief. It should
import `src/forecast.py` (owner B) for the forecast and `src/risk.py` (owner C) for the risk
score, rather than re-implementing either.
