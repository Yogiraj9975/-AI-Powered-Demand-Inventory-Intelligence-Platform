# Data-Quality & EDA Insight Memo — Forecasting Slice

**Project FORESIGHT · Client: NorthBay Living · Author: B (Data Scientist / Forecasting Lead)**
**Covers:** Milestone M1 (data quality, forecasting-relevant checks) and M2 (EDA insights, baseline & metric)

> This memo documents the checks and insights that fed the demand forecast (D3). Full
> pipeline-level ingestion/cleaning documentation for all four raw extracts is A's memo
> (`src/pipeline.py` + A's data-quality report). This file is the forecasting team's record of
> what we found and why it shaped the modelling choices below.

## 1. Data received

Four tables, provided as one workbook (`Demand_Inventory_Dataset_5Yr__3_.xlsx`):

| Table | Grain | Rows |
|---|---|---|
| `Products` | 1 row per product | 28 |
| `Stores` | 1 row per store | 10 |
| `Sales_Fact` | 1 row per (Product, Store, Date) | 511,280 |
| `Inventory_Fact` | 1 row per (Product, Store, Date) | 511,280 |
| `Date_Dim` | 1 row per date | 1,826 (2021-01-01 → 2025-12-31) |

This maps to the brief's generic `sku_master` / `sales_daily` / `inventory_snapshots` / `calendar`
schema, with one structural difference worth flagging up front (see §3).

## 2. Data-quality checks (forecasting-relevant)

| Check | Result |
|---|---|
| Nulls in `Sales_Fact` / `Inventory_Fact` | None |
| Duplicate (Date, ProductID, StoreID) keys | None |
| Negative units sold / negative on-hand stock | None |
| `Revenue == Units Sold × Unit Price` | Consistent to the cent for every row |
| Panel density (rows vs. Product × Store × Date) | Fully dense — every product/store pair has a row for all 1,826 days, no gaps |

**Finding:** the brief's generic description warns to "expect missing values, the odd duplicate,
inconsistent labels." This specific extract does not have those issues at the fact-table level.
Rather than manufacture cleaning steps that aren't needed, we report this honestly — the
forecasting effort here went into feature engineering and validation, not data repair.

## 3. Schema difference from the brief (documented assumption)

The brief's generic schema describes a `promo_flag` in `sales_daily` and holiday/promo fields in
`calendar`. **This actual dataset contains neither** — no promotion flag, no holiday indicator, no
promo-event calendar. This is called out explicitly rather than fabricated:

- The forecast model uses **calendar seasonality (week/month/quarter) and each SKU's own lag/
  rolling history** as its seasonal signal, not promotion data.
- This is stated as a limitation in the executive readout: a real promotional calendar, if
  NorthBay can supply one later, would likely improve accuracy further, especially around known
  promotional spikes the ops team currently tracks informally.

## 4. "SKU" definition (documented assumption)

`Inventory_Fact` — and therefore stock position, lead time, and reorder point — is tracked **per
store**, not just per product. NorthBay ships from regional stores across 4 regions (West, South,
East, North), so a reorder decision is made per (Product, Store) pair, not per product alone.

**Decision:** "SKU" = **(ProductID, StoreID)** throughout the forecast and (by extension) the
risk-scoring module. Product-level rollups are produced separately (`final_forecast_product_level.csv`)
for category/executive views where store-level granularity isn't needed.

## 5. Business insights (≥3, plain language)

1. **Demand is strongly seasonal, peaking Sep–Dec.** Average weekly demand per SKU rises from a
   summer trough (~160 units/week in Jun–Jul) to a Nov peak (~243 units/week) — a >50% seasonal
   swing. This is the single biggest driver of forecast accuracy: a model that ignores it will
   under-order heading into the festive season and over-order right after.
2. **Every product grew, year over year — there is no genuine dead stock in this data.** Average
   weekly demand from Year 1 to Year 5 rose between roughly +19% and +23% across all 28 products.
   The lowest-volume products (Electric Kettle, Smart LED Bulb, Moisturizer Combo) are simply
   lower-velocity, not declining — we report this rather than forcing a "markdown candidate"
   narrative the data doesn't support.
3. **Demand is concentrated in Personal Care and Apparel, and in the West/South regions.**
   Personal Care and Apparel together account for ~57% of total units sold; West and South
   regions carry ~64% of volume between them. If the ops team can only act on a subset of alerts
   first, these are where the rupee impact is largest.
4. **No promotion data exists to explain the remaining demand volatility** (see §3) — a
   documented limitation, not a hidden gap.

## 6. Metric & baseline (M2 checkpoint)

- **Primary metric: WAPE** (weighted absolute percentage error) — robust to the many low-volume
  SKU-store combinations where MAPE would explode. **Secondary: bias**, to check for systematic
  over/under-forecasting.
- **Baseline: seasonal-naive** (forecast = actual value 52 weeks earlier). This directly encodes
  the seasonality found in §5.1, making it a genuinely strong baseline to beat, not a strawman.
- Full definitions and an illustrative example are in `notebooks/02_baseline.ipynb`.

## 7. Forecast model performance (M3 checkpoint — headline result)

Backtested with rolling-origin cross-validation (6 origins spread across the last 12 months,
6-week-ahead forecasts, all 280 SKUs, no leakage — see `notebooks/03_model.ipynb` for the full
methodology and code):

| | Model (LightGBM) | Seasonal-naive baseline |
|---|---|---|
| **WAPE (overall)** | **6.6%** | 9.0% |
| **Bias (overall)** | −0.3% (near zero) | −4.8% (systematically under-forecasts) |

**The model beats the baseline by ~27% relative WAPE reduction, consistently at every horizon
step from 1 to 6 weeks out** — see `reports/figures/backtest_wape_by_horizon.png`. The baseline's
persistent negative bias is a direct consequence of the year-over-year growth in §5.2: a naive
copy of last year always lags a growing trend, while the model learns the trend directly.

**Decision:** ship the LightGBM model as D3, not the baseline. Full detail, code, and the final
6-week forward forecast are in `notebooks/03_model.ipynb` and `src/forecast.py`.

## 8. Limitations carried into the executive readout

- No promotion/holiday data — promotional spikes the ops team knows about informally aren't
  modelled.
- The approach assumes next year's seasonal pattern resembles the last five years; a structural
  change in the business would need a retrain and fresh backtest, not just a re-run.
- Prediction intervals are empirical (backtest residual quantiles per horizon step), which is
  honest about *historical* miss size but is not a formal statistical confidence interval.
