"""
forecast.py — Project FORESIGHT (NorthBay Living)
Owner: B — Data Scientist / Forecasting Lead

What this module does (maps to brief Section 07 methodology):
    1. Build a clean weekly SKU-level demand panel from the raw extracts.
    2. Build a seasonal-naive baseline (the bar every model must beat).
    3. Engineer lag / rolling / calendar features with NO leakage.
    4. Train a global LightGBM demand model and forecast recursively over
       a multi-week horizon.
    5. Backtest both the baseline and the model with rolling-origin CV and
       report WAPE / bias, exactly as the brief's non-negotiable rule requires.
    6. Produce the final forward forecast (point + 80% interval) that the
       Risk & Decisioning module (C) and the dashboard (D) consume.

Design decisions (documented here so the team / mentor can audit them):
    - "SKU" is defined as a (ProductID, StoreID) pair, not ProductID alone.
      NorthBay's inventory is held and replenished per store (Inventory_Fact
      is at Product x Store grain), so that is the operational unit a
      reorder decision is made for. Product-level rollups are provided
      separately for executive-level reporting.
    - Weeks run Monday-Sunday (pandas 'W-SUN' anchors on Sunday close).
      Only fully-observed 7-day weeks are kept in the panel.
    - The actual provided dataset does NOT contain promo_flag / is_holiday /
      promo_event columns described in the brief's generic schema. This is
      called out explicitly rather than silently fabricated: seasonality is
      captured only through calendar (week-of-year/month/quarter) and lag/
      rolling features, not promotion signals.
    - Forecast horizon (H) = 6 weeks, per the brief's suggested 6-8 week range.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import lightgbm as lgb

# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
HORIZON = 6                       # weeks ahead to forecast
SEASON_LENGTH = 52                # weeks, for seasonal-naive baseline
LAGS = [1, 2, 3, 4, 8, 12, 52]     # weeks
ROLL_WINDOWS = [4, 8, 12]         # weeks
GROUP_COLS = ["ProductID", "StoreID"]
TARGET = "units_sold"
DATE_COL = "week"

CAT_FEATURES = ["ProductID", "StoreID", "Category", "Region"]

LGB_PARAMS = dict(
    objective="regression",
    metric="mae",
    learning_rate=0.05,
    num_leaves=63,
    min_data_in_leaf=30,
    feature_fraction=0.85,
    bagging_fraction=0.85,
    bagging_freq=1,
    verbose=-1,
    seed=42,
)
LGB_NUM_ROUNDS = 400


# --------------------------------------------------------------------------- #
# 1. Load raw extracts
# --------------------------------------------------------------------------- #
def load_raw(data_dir: str = "data/raw") -> dict[str, pd.DataFrame]:
    """Load the four raw extracts. Mirrors what src/pipeline.py (A) ingests."""
    sales = pd.read_csv(f"{data_dir}/Sales_Fact.csv", parse_dates=["Date"])
    inv = pd.read_csv(f"{data_dir}/Inventory_Fact.csv", parse_dates=["Date"])
    prod = pd.read_csv(f"{data_dir}/Products.csv")
    stores = pd.read_csv(f"{data_dir}/Stores.csv")
    cal = pd.read_csv(f"{data_dir}/Date_Dim.csv", parse_dates=["Date"])
    return dict(sales=sales, inventory=inv, products=prod, stores=stores, calendar=cal)


# --------------------------------------------------------------------------- #
# 2. Build the weekly SKU-level panel
# --------------------------------------------------------------------------- #
def build_weekly_panel(raw: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """
    Aggregate daily Sales_Fact to weekly (Mon-Sun) units_sold / revenue per
    (ProductID, StoreID), then attach static Product/Store attributes.
    Incomplete boundary weeks (< 7 observed days) are dropped so every row
    represents a full week of demand.
    """
    sales = raw["sales"].copy()
    sales[DATE_COL] = sales["Date"].dt.to_period("W-SUN").dt.start_time

    wk = sales.groupby(GROUP_COLS + [DATE_COL], as_index=False).agg(
        units_sold=("Units Sold", "sum"),
        revenue=("Revenue", "sum"),
        n_days=("Date", "count"),
    )
    wk = wk[wk["n_days"] == 7].drop(columns="n_days")

    prod = raw["products"].rename(columns={
        "Unit Cost": "unit_cost", "Unit Price": "unit_price",
        "Reorder Level": "reorder_level", "Lead Time Days": "lead_time_days",
        "Product Name": "product_name",
    })
    stores = raw["stores"].rename(columns={"Store Name": "store_name"})

    panel = wk.merge(prod, on="ProductID", how="left").merge(stores, on="StoreID", how="left")
    panel = panel.sort_values(GROUP_COLS + [DATE_COL]).reset_index(drop=True)
    return panel


# --------------------------------------------------------------------------- #
# 3. Feature engineering (leakage-safe)
# --------------------------------------------------------------------------- #
def add_calendar_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["year"] = df[DATE_COL].dt.isocalendar().year.astype(int)
    df["week_of_year"] = df[DATE_COL].dt.isocalendar().week.astype(int)
    df["month"] = df[DATE_COL].dt.month
    df["quarter"] = df[DATE_COL].dt.quarter
    # linear trend index, shared across all SKUs
    week_index = {w: i for i, w in enumerate(sorted(df[DATE_COL].unique()))}
    df["time_idx"] = df[DATE_COL].map(week_index)
    return df


def add_lag_roll_features(df: pd.DataFrame, target: str = TARGET) -> pd.DataFrame:
    """
    All lag/rolling features are computed strictly from the past: rolling
    windows are built on the already-shifted (lag-1) series, so the row for
    week t never touches units_sold at t or later. This is what keeps the
    model leakage-free per the brief's non-negotiable rule.
    """
    df = df.sort_values(GROUP_COLS + [DATE_COL]).copy()
    g = df.groupby(GROUP_COLS)[target]

    for lag in LAGS:
        df[f"lag_{lag}"] = g.shift(lag)

    shifted = g.shift(1)  # base series for rolling stats: strictly pre-t
    df["_shift1"] = shifted
    for w in ROLL_WINDOWS:
        df[f"roll_mean_{w}"] = df.groupby(GROUP_COLS)["_shift1"].transform(
            lambda s: s.rolling(w, min_periods=max(2, w // 2)).mean()
        )
        df[f"roll_std_{w}"] = df.groupby(GROUP_COLS)["_shift1"].transform(
            lambda s: s.rolling(w, min_periods=max(2, w // 2)).std()
        )
    df = df.drop(columns="_shift1")
    return df


def feature_columns(df: pd.DataFrame) -> list[str]:
    lag_cols = [f"lag_{l}" for l in LAGS]
    roll_cols = [f"roll_mean_{w}" for w in ROLL_WINDOWS] + [f"roll_std_{w}" for w in ROLL_WINDOWS]
    cal_cols = ["year", "week_of_year", "month", "quarter", "time_idx"]
    static_cols = ["unit_cost", "unit_price", "reorder_level", "lead_time_days"]
    return lag_cols + roll_cols + cal_cols + static_cols + CAT_FEATURES


def prep_categoricals(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for c in CAT_FEATURES:
        df[c] = df[c].astype("category")
    return df


# --------------------------------------------------------------------------- #
# 4. Seasonal-naive baseline
# --------------------------------------------------------------------------- #
def seasonal_naive_forecast(history: pd.DataFrame, horizon: int = HORIZON,
                             season: int = SEASON_LENGTH) -> pd.DataFrame:
    """
    For each SKU and each of the next `horizon` weeks, forecast = the actual
    value observed `season` weeks earlier. Falls back to the SKU's trailing
    mean if that much history isn't available yet (only matters for very
    early backtest origins).
    """
    history = history.sort_values(GROUP_COLS + [DATE_COL])
    last_week = history[DATE_COL].max()
    future_weeks = [last_week + pd.Timedelta(weeks=i) for i in range(1, horizon + 1)]

    out = []
    for keys, grp in history.groupby(GROUP_COLS):
        grp = grp.set_index(DATE_COL)[TARGET]
        fallback = grp.tail(8).mean() if len(grp) else 0.0
        for i, fw in enumerate(future_weeks, start=1):
            src_week = fw - pd.Timedelta(weeks=season)
            val = grp.get(src_week, np.nan)
            if pd.isna(val):
                val = fallback
            row = dict(zip(GROUP_COLS, keys if isinstance(keys, tuple) else (keys,)))
            row[DATE_COL] = fw
            row["h"] = i
            row["baseline_forecast"] = max(val, 0.0)
            out.append(row)
    return pd.DataFrame(out)


# --------------------------------------------------------------------------- #
# 5. Model training + recursive multi-step forecasting
# --------------------------------------------------------------------------- #
def train_model(train_df: pd.DataFrame, feat_cols: list[str], target: str = TARGET):
    train_df = train_df.dropna(subset=feat_cols, how="all")
    train_df = prep_categoricals(train_df)
    ds = lgb.Dataset(train_df[feat_cols], label=train_df[target],
                      categorical_feature=CAT_FEATURES, free_raw_data=False)
    model = lgb.train(LGB_PARAMS, ds, num_boost_round=LGB_NUM_ROUNDS)
    return model


def recursive_forecast(model, panel_hist: pd.DataFrame, horizon: int = HORIZON) -> pd.DataFrame:
    """
    Forecast `horizon` weeks forward for every SKU using the trained 1-week
    -ahead model, feeding each week's prediction back in as if it were the
    latest observation so lag/rolling features stay defined. No future
    actuals are ever used — only previously forecasted or genuinely
    historical values.
    """
    work = panel_hist.copy()
    last_week = work[DATE_COL].max()
    static_cols = ["unit_cost", "unit_price", "reorder_level", "lead_time_days",
                   "Category", "Region", "product_name", "store_name"]
    static = work.sort_values(DATE_COL).groupby(GROUP_COLS)[static_cols].last().reset_index()

    forecasts = []
    for h in range(1, horizon + 1):
        fw = last_week + pd.Timedelta(weeks=h)
        future_rows = static.copy()
        future_rows[DATE_COL] = fw
        future_rows[TARGET] = np.nan

        combined = pd.concat([work, future_rows], ignore_index=True, sort=False)
        combined = add_calendar_features(combined)
        combined = add_lag_roll_features(combined)

        cur = combined[combined[DATE_COL] == fw].copy()
        feat_cols = feature_columns(cur)
        cur = prep_categoricals(cur)
        pred = model.predict(cur[feat_cols])
        cur[TARGET] = np.clip(pred, 0, None)
        cur["h"] = h

        forecasts.append(cur[GROUP_COLS + [DATE_COL, "h", TARGET]].rename(
            columns={TARGET: "model_forecast"}))

        # append this step's forecast to working history so h+1 can lag off it
        step_actual = cur[GROUP_COLS + [DATE_COL]].copy()
        step_actual[TARGET] = cur[TARGET].values
        work = pd.concat([work, step_actual], ignore_index=True, sort=False)

    return pd.concat(forecasts, ignore_index=True)


# --------------------------------------------------------------------------- #
# 6. Metrics
# --------------------------------------------------------------------------- #
def wape(actual: np.ndarray, forecast: np.ndarray) -> float:
    actual, forecast = np.asarray(actual, dtype=float), np.asarray(forecast, dtype=float)
    denom = np.sum(np.abs(actual))
    if denom == 0:
        return np.nan
    return float(np.sum(np.abs(actual - forecast)) / denom)


def bias(actual: np.ndarray, forecast: np.ndarray) -> float:
    actual, forecast = np.asarray(actual, dtype=float), np.asarray(forecast, dtype=float)
    denom = np.sum(np.abs(actual))
    if denom == 0:
        return np.nan
    return float(np.sum(forecast - actual) / denom)


# --------------------------------------------------------------------------- #
# 7. Rolling-origin backtest
# --------------------------------------------------------------------------- #
def rolling_origin_backtest(panel: pd.DataFrame, origins: list[pd.Timestamp],
                             horizon: int = HORIZON) -> pd.DataFrame:
    """
    For each origin week O:
      - train the model on all data with week <= O (expanding window)
      - forecast weeks O+1 .. O+horizon recursively (model) and via
        seasonal-naive (baseline)
      - compare both to the true actuals for those weeks
    Returns one row per (origin, SKU, h) with actual / model_forecast /
    baseline_forecast, ready to aggregate into WAPE.
    """
    results = []
    for origin in origins:
        train_hist = panel[panel[DATE_COL] <= origin].copy()
        future_actuals = panel[
            (panel[DATE_COL] > origin) &
            (panel[DATE_COL] <= origin + pd.Timedelta(weeks=horizon))
        ][GROUP_COLS + [DATE_COL, TARGET]].copy()

        feat_train = add_calendar_features(train_hist)
        feat_train = add_lag_roll_features(feat_train)
        feat_cols = feature_columns(feat_train)
        feat_train = feat_train.dropna(subset=[f"lag_{max(LAGS)}"])  # need full lag history
        if feat_train.empty:
            continue

        model = train_model(feat_train, feat_cols)
        model_fc = recursive_forecast(model, train_hist, horizon)
        base_fc = seasonal_naive_forecast(train_hist, horizon)

        merged = future_actuals.merge(model_fc, on=GROUP_COLS + [DATE_COL], how="left")
        merged = merged.merge(
            base_fc.drop(columns="h"), on=GROUP_COLS + [DATE_COL], how="left"
        )
        merged["origin"] = origin
        results.append(merged)

    return pd.concat(results, ignore_index=True)


def summarize_backtest(bt: pd.DataFrame) -> pd.DataFrame:
    """Overall + per-horizon-step WAPE and bias for model vs. baseline."""
    rows = []
    overall = dict(
        h="all",
        model_wape=wape(bt[TARGET], bt["model_forecast"]),
        baseline_wape=wape(bt[TARGET], bt["baseline_forecast"]),
        model_bias=bias(bt[TARGET], bt["model_forecast"]),
        baseline_bias=bias(bt[TARGET], bt["baseline_forecast"]),
    )
    rows.append(overall)
    for h, grp in bt.groupby("h"):
        rows.append(dict(
            h=h,
            model_wape=wape(grp[TARGET], grp["model_forecast"]),
            baseline_wape=wape(grp[TARGET], grp["baseline_forecast"]),
            model_bias=bias(grp[TARGET], grp["model_forecast"]),
            baseline_bias=bias(grp[TARGET], grp["baseline_forecast"]),
        ))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# 8. Final forward forecast with empirical prediction intervals
# --------------------------------------------------------------------------- #
def final_forecast_with_intervals(panel: pd.DataFrame, backtest: pd.DataFrame,
                                   horizon: int = HORIZON) -> pd.DataFrame:
    """
    Train on ALL available history and forecast the next `horizon` weeks per
    SKU. Uncertainty intervals are the empirical 10th/90th percentile of the
    model's backtest residuals *at the matching horizon step h*, pooled
    across SKUs — a simple, honest way to say "the model missed by about
    this much at h weeks out, historically."
    """
    feat_full = add_calendar_features(panel)
    feat_full = add_lag_roll_features(feat_full)
    feat_cols = feature_columns(feat_full)
    train_full = feat_full.dropna(subset=[f"lag_{max(LAGS)}"])

    model = train_model(train_full, feat_cols)
    fc = recursive_forecast(model, panel, horizon)

    backtest = backtest.copy()
    backtest["resid"] = backtest[TARGET] - backtest["model_forecast"]
    resid_by_h = backtest.groupby("h")["resid"].quantile([0.1, 0.9]).unstack()
    resid_by_h.columns = ["q10", "q90"]

    fc = fc.merge(resid_by_h, left_on="h", right_index=True, how="left")
    fc["forecast_low"] = np.clip(fc["model_forecast"] + fc["q10"], 0, None)
    fc["forecast_high"] = np.clip(fc["model_forecast"] + fc["q90"], 0, None)
    fc = fc.drop(columns=["q10", "q90"])
    return fc
