from dataclasses import dataclass, field
from typing import List, Optional, Dict, Literal
import pandas as pd


@dataclass
class ValidationIssue:
    dataset: str
    rule: str
    severity: Literal["error", "warning"]
    status: str
    message: str
    affected_column: Optional[str] = None
    affected_rows: Optional[int] = None
    parent_dataset: Optional[str] = None
    parent_column: Optional[str] = None
    distinct_orphan_values: Optional[int] = None


@dataclass
class DatasetResult:
    dataset_name: str
    passed: bool
    errors: List[ValidationIssue] = field(default_factory=list)
    warnings: List[ValidationIssue] = field(default_factory=list)


@dataclass
class DataQualityResult:
    passed: bool
    status: Literal["PASS", "FAIL", "ERROR"]
    summary: str
    dataset_results: Dict[str, DatasetResult] = field(default_factory=dict)
    issues: List[ValidationIssue] = field(default_factory=list)
    data: Optional[Dict[str, pd.DataFrame]] = None
