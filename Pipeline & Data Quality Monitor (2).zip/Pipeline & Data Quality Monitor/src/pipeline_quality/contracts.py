from dataclasses import dataclass
from typing import List, Optional, Dict, Tuple


@dataclass
class ColumnSpec:
    name: str
    dtype: str
    required: bool = True
    nullable: bool = False
    purpose: str = ""
    domain: Optional[Tuple[str, ...]] = None


@dataclass
class DatasetContract:
    name: str
    columns: List[ColumnSpec]
    grain: Optional[Tuple[str, ...]] = None
    primary_key: Optional[Tuple[str, ...]] = None


PRODUCTS_CONTRACT = DatasetContract(
    name="products",
    columns=[
        ColumnSpec(name="ProductID", dtype="string", required=True, nullable=False, purpose="Product identifier"),
        ColumnSpec(name="Product Name", dtype="string", required=True, nullable=False, purpose="Product name"),
        ColumnSpec(name="Category", dtype="string", required=True, nullable=False, purpose="Product category"),
        ColumnSpec(name="Unit Cost", dtype="float", required=True, nullable=False, purpose="Unit cost"),
        ColumnSpec(name="Unit Price", dtype="float", required=True, nullable=False, purpose="Unit price"),
        ColumnSpec(name="Reorder Level", dtype="int", required=True, nullable=False, purpose="Reorder level"),
        ColumnSpec(name="Lead Time Days", dtype="int", required=True, nullable=False, purpose="Lead time in days"),
    ],
    grain=("ProductID",),
    primary_key=("ProductID",),
)

STORES_CONTRACT = DatasetContract(
    name="stores",
    columns=[
        ColumnSpec(name="StoreID", dtype="string", required=True, nullable=False, purpose="Store identifier"),
        ColumnSpec(name="Store Name", dtype="string", required=True, nullable=False, purpose="Store name"),
        ColumnSpec(name="Region", dtype="string", required=True, nullable=False, purpose="Store region"),
    ],
    grain=("StoreID",),
    primary_key=("StoreID",),
)

SALES_FACT_CONTRACT = DatasetContract(
    name="sales",
    columns=[
        ColumnSpec(name="Date", dtype="date", required=True, nullable=False, purpose="Transaction date"),
        ColumnSpec(name="ProductID", dtype="string", required=True, nullable=False, purpose="Product identifier"),
        ColumnSpec(name="StoreID", dtype="string", required=True, nullable=False, purpose="Store identifier"),
        ColumnSpec(name="Units Sold", dtype="int", required=True, nullable=False, purpose="Quantity sold"),
        ColumnSpec(name="Revenue", dtype="float", required=True, nullable=False, purpose="Revenue"),
    ],
    grain=("Date", "ProductID", "StoreID"),
    primary_key=("Date", "ProductID", "StoreID"),
)

INVENTORY_FACT_CONTRACT = DatasetContract(
    name="inventory",
    columns=[
        ColumnSpec(name="Date", dtype="date", required=True, nullable=False, purpose="Snapshot date"),
        ColumnSpec(name="ProductID", dtype="string", required=True, nullable=False, purpose="Product identifier"),
        ColumnSpec(name="StoreID", dtype="string", required=True, nullable=False, purpose="Store identifier"),
        ColumnSpec(name="Stock Received", dtype="int", required=True, nullable=False, purpose="Stock received"),
        ColumnSpec(name="Stock On Hand (End of Week)", dtype="int", required=True, nullable=False, purpose="Stock on hand at end of week"),
        ColumnSpec(name="Stockout Flag", dtype="string", required=True, nullable=False, purpose="Stockout indicator", domain=("Yes", "No")),
    ],
    grain=("Date", "ProductID", "StoreID"),
    primary_key=("Date", "ProductID", "StoreID"),
)

DATE_DIM_CONTRACT = DatasetContract(
    name="date_dim",
    columns=[
        ColumnSpec(name="Date", dtype="date", required=True, nullable=False, purpose="Calendar date"),
        ColumnSpec(name="Year", dtype="int", required=True, nullable=False, purpose="Calendar year"),
        ColumnSpec(name="Month", dtype="string", required=True, nullable=False, purpose="Month name"),
        ColumnSpec(name="MonthNum", dtype="int", required=True, nullable=False, purpose="Month number"),
        ColumnSpec(name="Week", dtype="int", required=True, nullable=False, purpose="Week number"),
        ColumnSpec(name="Quarter", dtype="int", required=True, nullable=False, purpose="Quarter number"),
    ],
    grain=("Date",),
    primary_key=("Date",),
)

DATASET_CONTRACTS: Dict[str, DatasetContract] = {
    "products": PRODUCTS_CONTRACT,
    "stores": STORES_CONTRACT,
    "sales": SALES_FACT_CONTRACT,
    "inventory": INVENTORY_FACT_CONTRACT,
    "date_dim": DATE_DIM_CONTRACT,
}

RELATIONSHIPS: List[Tuple[str, str, str, str]] = [
    ("sales", "ProductID", "products", "ProductID"),
    ("inventory", "ProductID", "products", "ProductID"),
    ("sales", "StoreID", "stores", "StoreID"),
    ("inventory", "StoreID", "stores", "StoreID"),
    ("sales", "Date", "date_dim", "Date"),
    ("inventory", "Date", "date_dim", "Date"),
]
