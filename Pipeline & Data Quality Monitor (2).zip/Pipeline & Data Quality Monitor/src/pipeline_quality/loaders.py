from pathlib import Path
from typing import Dict

import pandas as pd

REQUIRED_DATASETS = {
    "sales": "Sales_Fact.csv",
    "products": "Products.csv",
    "stores": "Stores.csv",
    "inventory": "Inventory_Fact.csv",
    "date_dim": "Date_Dim.csv",
}


def load_raw_datasets(data_dir):
    """Load raw FORESIGHT CSV datasets from a directory.

    Args:
        data_dir: Path to a directory containing the five required CSV files:
            Sales_Fact.csv, Products.csv, Stores.csv, Inventory_Fact.csv,
            and Date_Dim.csv.

    Returns:
        dict: Mapping from dataset name to pandas DataFrame.

    Raises:
        FileNotFoundError: If the directory or a required CSV is missing.
        RuntimeError: If a required CSV cannot be parsed.
    """
    base = Path(data_dir)

    if not base.exists() or not base.is_dir():
        raise FileNotFoundError(
            f"Raw data directory does not exist or is not a directory: {base}"
        )

    datasets: Dict[str, pd.DataFrame] = {}

    for dataset_name, filename in REQUIRED_DATASETS.items():
        file_path = base / filename

        if not file_path.is_file():
            raise FileNotFoundError(
                f"Required raw dataset file is missing: {file_path}"
            )

        try:
            df = pd.read_csv(file_path)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to read required CSV file: {file_path}"
            ) from exc

        datasets[dataset_name] = df

    return datasets
