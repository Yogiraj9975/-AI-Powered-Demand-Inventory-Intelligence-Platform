from .loaders import load_raw_datasets
from .result import DataQualityResult, DatasetResult, ValidationIssue
from .validators import (
    validate_duplicates,
    validate_missing_values,
    validate_relationships,
    validate_schema,
    validate_value_domains,
)

__all__ = [
    "run_data_quality_gate",
    "DataQualityResult",
    "DatasetResult",
    "ValidationIssue",
]


def run_data_quality_gate(raw_data_directory):
    """Validate raw FORESIGHT datasets and return a quality gate result.

    Args:
        raw_data_directory: Path to a directory containing the five required
            CSV files: Sales_Fact.csv, Products.csv, Stores.csv,
            Inventory_Fact.csv, and Date_Dim.csv.

    Returns:
        DataQualityResult: Structured result with PASS, FAIL, or ERROR status,
        validation issues, and trusted data on success.
    """
    datasets = load_raw_datasets(raw_data_directory)

    all_issues = []
    dataset_results = {}

    per_dataset_validators = [
        validate_schema,
        validate_missing_values,
        validate_duplicates,
    ]

    cross_dataset_validators = [
        validate_relationships,
        validate_value_domains,
    ]

    for dataset_name, dataframe in datasets.items():
        for validator in per_dataset_validators:
            try:
                result = validator(dataset_name, dataframe)
                ds_name = result.dataset_name
                
                if ds_name not in dataset_results:
                    dataset_results[ds_name] = result
                else:
                    existing = dataset_results[ds_name]
                    existing.errors.extend(result.errors)
                    existing.warnings.extend(result.warnings)
                    existing.passed = len(existing.errors) == 0

                all_issues.extend(result.errors)
                all_issues.extend(result.warnings)
            except Exception as e:
                all_issues.append(ValidationIssue(
                    dataset=dataset_name,
                    rule="unexpected_exception",
                    severity="error",
                    status="ERROR",
                    message=f"Validator {validator.__name__} crashed: {str(e)}"
                ))

    for validator in cross_dataset_validators:
        try:
            result = validator(datasets)
            all_issues.extend(result.issues)
            
            for ds_name, ds_result in result.dataset_results.items():
                if ds_name not in dataset_results:
                    dataset_results[ds_name] = ds_result
                else:
                    existing = dataset_results[ds_name]
                    existing.errors.extend(ds_result.errors)
                    existing.warnings.extend(ds_result.warnings)
                    existing.passed = len(existing.errors) == 0
        except Exception as e:
            all_issues.append(ValidationIssue(
                dataset="global",
                rule="unexpected_exception",
                severity="error",
                status="ERROR",
                message=f"Cross-dataset validator {validator.__name__} crashed: {str(e)}"
            ))

    passed = len(all_issues) == 0
    status = "PASS" if passed else "FAIL"
    summary = (
        "All validations passed."
        if passed
        else f"{len(all_issues)} validation issue(s) found."
    )

    return DataQualityResult(
        passed=passed,
        status=status,
        summary=summary,
        dataset_results=dataset_results,
        issues=all_issues,
        data=datasets if passed else None,
    )
