from typing import Dict, List, Optional

import pandas as pd

from pipeline_quality.contracts import DATASET_CONTRACTS, RELATIONSHIPS, DatasetContract
from pipeline_quality.result import DataQualityResult, DatasetResult, ValidationIssue


def validate_schema(dataset_name: str, dataframe: pd.DataFrame) -> DatasetResult:
    """Validate a loaded DataFrame against its dataset contract.

    This is a read-only structural check. It does not modify the DataFrame.

    Args:
        dataset_name: Logical dataset name, e.g. ``sales``.
        dataframe: Loaded pandas DataFrame to validate.

    Returns:
        DatasetResult with errors and warnings describing schema mismatches.

    Raises:
        ValueError: If ``dataset_name`` is not a known contracted dataset.
    """
    if dataset_name not in DATASET_CONTRACTS:
        raise ValueError(
            f"Unknown dataset: {dataset_name}. "
            f"Known datasets: {sorted(DATASET_CONTRACTS.keys())}"
        )

    contract = DATASET_CONTRACTS[dataset_name]
    errors: List[ValidationIssue] = []
    warnings: List[ValidationIssue] = []

    if len(dataframe) == 0:
        errors.append(
            ValidationIssue(
                dataset=dataset_name,
                rule="empty_dataset",
                severity="error",
                status="FAIL",
                message=f"{dataset_name} contains no rows",
            )
        )

    actual_columns = list(dataframe.columns)
    expected_columns = [col.name for col in contract.columns]
    required_columns = [col.name for col in contract.columns if col.required]

    missing = [col for col in required_columns if col not in actual_columns]
    for col in missing:
        errors.append(
            ValidationIssue(
                dataset=dataset_name,
                rule="required_columns",
                severity="error",
                status="FAIL",
                message=f"{dataset_name} is missing required column: {col}",
                affected_column=col,
            )
        )

    unexpected = [col for col in actual_columns if col not in expected_columns]
    for col in unexpected:
        warnings.append(
            ValidationIssue(
                dataset=dataset_name,
                rule="unexpected_columns",
                severity="warning",
                status="WARN",
                message=f"{dataset_name} contains unexpected column: {col}",
                affected_column=col,
            )
        )

    for col_spec in contract.columns:
        if col_spec.name not in actual_columns:
            continue

        if col_spec.dtype == "date":
            continue

        actual_dtype = str(dataframe[col_spec.name].dtype)
        if not _is_compatible_dtype(col_spec.dtype, actual_dtype):
            warnings.append(
                ValidationIssue(
                    dataset=dataset_name,
                    rule="type_advisory",
                    severity="warning",
                    status="WARN",
                    message=(
                        f"{dataset_name}.{col_spec.name} has pandas dtype "
                        f"{actual_dtype}, which may be incompatible with "
                        f"contract logical type {col_spec.dtype}"
                    ),
                    affected_column=col_spec.name,
                )
            )

    return DatasetResult(
        dataset_name=dataset_name,
        passed=len(errors) == 0,
        errors=errors,
        warnings=warnings,
    )


def _is_compatible_dtype(logical_type: str, pandas_dtype: str) -> bool:
    pandas_dtype_lower = pandas_dtype.lower()

    if logical_type == "int":
        return any(token in pandas_dtype_lower for token in ["int", "uint"])
    if logical_type == "float":
        return any(token in pandas_dtype_lower for token in ["float"])
    if logical_type == "string":
        return any(token in pandas_dtype_lower for token in ["object", "string", "str"])
    if logical_type == "bool":
        return "bool" in pandas_dtype_lower

    return True


def validate_duplicates(dataset_name: str, dataframe: pd.DataFrame) -> DatasetResult:
    """Validate that a dataset contains no duplicate logical keys.

    This is a read-only diagnostic check. It does not modify the DataFrame.

    Uniqueness expectations are derived from the dataset contract's
    ``primary_key`` or ``grain`` field.

    Args:
        dataset_name: Logical dataset name, e.g. ``sales``.
        dataframe: Loaded pandas DataFrame to validate.

    Returns:
        DatasetResult with errors describing duplicate-key violations.

    Raises:
        ValueError: If ``dataset_name`` is not a known contracted dataset,
            or if the dataset contract does not define a uniqueness key.
    """
    if dataset_name not in DATASET_CONTRACTS:
        raise ValueError(
            f"Unknown dataset: {dataset_name}. "
            f"Known datasets: {sorted(DATASET_CONTRACTS.keys())}"
        )

    contract = DATASET_CONTRACTS[dataset_name]
    key_columns = contract.primary_key or contract.grain

    if not key_columns:
        raise ValueError(
            f"Dataset {dataset_name} does not define a primary_key or grain "
            f"in its contract, so duplicate validation cannot be performed."
        )

    errors: List[ValidationIssue] = []

    missing_key_columns = [col for col in key_columns if col not in dataframe.columns]
    if missing_key_columns:
        return DatasetResult(
            dataset_name=dataset_name,
            passed=True,
            errors=errors,
            warnings=[],
        )

    key_df = dataframe[list(key_columns)]

    has_null_key = key_df.isna().any(axis=1).any()
    if has_null_key:
        clean_key_df = key_df.dropna()
    else:
        clean_key_df = key_df

    if clean_key_df.empty:
        return DatasetResult(
            dataset_name=dataset_name,
            passed=True,
            errors=errors,
            warnings=[],
        )

    duplicate_mask = clean_key_df.duplicated(keep=False)
    duplicate_rows = int(duplicate_mask.sum())

    if duplicate_rows == 0:
        return DatasetResult(
            dataset_name=dataset_name,
            passed=True,
            errors=errors,
            warnings=[],
        )

    duplicate_key_groups = int(clean_key_df[duplicate_mask].drop_duplicates().shape[0])

    errors.append(
        ValidationIssue(
            dataset=dataset_name,
            rule="duplicate_key",
            severity="error",
            status="FAIL",
            message=(
                f"{dataset_name} contains {duplicate_rows} duplicated rows "
                f"across {duplicate_key_groups} duplicated key group(s) "
                f"for key {key_columns}"
            ),
            affected_column=",".join(key_columns),
            affected_rows=duplicate_rows,
        )
    )

    return DatasetResult(
        dataset_name=dataset_name,
        passed=False,
        errors=errors,
        warnings=[],
    )


def validate_missing_values(dataset_name: str, dataframe: pd.DataFrame) -> DatasetResult:
    """Validate that required non-nullable columns contain no missing values.

    This is a read-only diagnostic check. It does not modify the DataFrame.

    Args:
        dataset_name: Logical dataset name, e.g. ``sales``.
        dataframe: Loaded pandas DataFrame to validate.

    Returns:
        DatasetResult with errors describing missing-value violations.

    Raises:
        ValueError: If ``dataset_name`` is not a known contracted dataset.
    """
    if dataset_name not in DATASET_CONTRACTS:
        raise ValueError(
            f"Unknown dataset: {dataset_name}. "
            f"Known datasets: {sorted(DATASET_CONTRACTS.keys())}"
        )

    contract = DATASET_CONTRACTS[dataset_name]
    errors: List[ValidationIssue] = []
    actual_columns = set(dataframe.columns)

    for col_spec in contract.columns:
        if col_spec.name not in actual_columns:
            continue

        if col_spec.nullable:
            continue

        missing_count = int(dataframe[col_spec.name].isna().sum())
        if missing_count > 0:
            errors.append(
                ValidationIssue(
                    dataset=dataset_name,
                    rule="missing_values",
                    severity="error",
                    status="FAIL",
                    message=f"{dataset_name}.{col_spec.name} contains {missing_count} missing values",
                    affected_column=col_spec.name,
                    affected_rows=missing_count,
                )
            )

    return DatasetResult(
        dataset_name=dataset_name,
        passed=len(errors) == 0,
        errors=errors,
        warnings=[],
    )


def validate_relationships(datasets: Dict[str, pd.DataFrame]) -> DataQualityResult:
    """Validate cross-dataset referential integrity for contracted relationships.

    This is a read-only check. It does not modify any DataFrame.

    For each relationship defined in ``contracts.RELATIONSHIPS``, every
    non-null child reference value is checked for membership in the
    corresponding parent reference/key column. Missing datasets or columns
    are reported as structural errors rather than orphan values.

    Args:
        datasets: Mapping from dataset name to loaded pandas DataFrame.

    Returns:
        DataQualityResult with errors describing orphan references and
        structural relationship problems.
    """
    errors: List[ValidationIssue] = []
    dataset_results: Dict[str, DatasetResult] = {}

    for child_dataset, child_column, parent_dataset, parent_column in RELATIONSHIPS:
        if child_dataset not in datasets:
            errors.append(
                ValidationIssue(
                    dataset=child_dataset,
                    rule="relationship_structure",
                    severity="error",
                    status="FAIL",
                    message=(
                        f"Cannot evaluate {child_dataset}.{child_column} -> "
                        f"{parent_dataset}.{parent_column}: child dataset "
                        f"'{child_dataset}' is missing"
                    ),
                    affected_column=child_column,
                    parent_dataset=parent_dataset,
                    parent_column=parent_column,
                )
            )
            continue

        if parent_dataset not in datasets:
            errors.append(
                ValidationIssue(
                    dataset=child_dataset,
                    rule="relationship_structure",
                    severity="error",
                    status="FAIL",
                    message=(
                        f"Cannot evaluate {child_dataset}.{child_column} -> "
                        f"{parent_dataset}.{parent_column}: parent dataset "
                        f"'{parent_dataset}' is missing"
                    ),
                    affected_column=child_column,
                    parent_dataset=parent_dataset,
                    parent_column=parent_column,
                )
            )
            continue

        child_df = datasets[child_dataset]
        parent_df = datasets[parent_dataset]

        if child_column not in child_df.columns:
            errors.append(
                ValidationIssue(
                    dataset=child_dataset,
                    rule="relationship_structure",
                    severity="error",
                    status="FAIL",
                    message=(
                        f"Cannot evaluate {child_dataset}.{child_column} -> "
                        f"{parent_dataset}.{parent_column}: child column "
                        f"'{child_column}' is missing from '{child_dataset}'"
                    ),
                    affected_column=child_column,
                    parent_dataset=parent_dataset,
                    parent_column=parent_column,
                )
            )
            continue

        if parent_column not in parent_df.columns:
            errors.append(
                ValidationIssue(
                    dataset=child_dataset,
                    rule="relationship_structure",
                    severity="error",
                    status="FAIL",
                    message=(
                        f"Cannot evaluate {child_dataset}.{child_column} -> "
                        f"{parent_dataset}.{parent_column}: parent column "
                        f"'{parent_column}' is missing from '{parent_dataset}'"
                    ),
                    affected_column=child_column,
                    parent_dataset=parent_dataset,
                    parent_column=parent_column,
                )
            )
            continue

        child_series = child_df[child_column]
        parent_series = parent_df[parent_column]

        non_null_child = child_series.dropna()

        if len(non_null_child) == 0:
            continue

        parent_values = pd.Index(parent_series.dropna())

        orphan_mask = ~non_null_child.isin(parent_values)
        orphan_values = non_null_child[orphan_mask]

        orphan_row_count = int(len(orphan_values))
        distinct_orphan_count = int(orphan_values.nunique())

        if orphan_row_count > 0:
            issue = ValidationIssue(
                dataset=child_dataset,
                rule="orphan_reference",
                severity="error",
                status="FAIL",
                message=(
                    f"{child_dataset}.{child_column} -> "
                    f"{parent_dataset}.{parent_column}: "
                    f"{orphan_row_count} orphan rows referencing "
                    f"{distinct_orphan_count} distinct values"
                ),
                affected_column=child_column,
                affected_rows=orphan_row_count,
                parent_dataset=parent_dataset,
                parent_column=parent_column,
                distinct_orphan_values=distinct_orphan_count,
            )
            errors.append(issue)

            if child_dataset not in dataset_results:
                dataset_results[child_dataset] = DatasetResult(
                    dataset_name=child_dataset,
                    passed=False,
                    errors=[],
                    warnings=[],
                )
            dataset_results[child_dataset].errors.append(issue)

    passed = len(errors) == 0
    status = "PASS" if passed else "FAIL"
    summary = (
        "All relationship validations passed."
        if passed
        else f"{len(errors)} relationship validation issue(s) found."
    )

    return DataQualityResult(
        passed=passed,
        status=status,
        summary=summary,
        dataset_results=dataset_results,
        issues=errors,
    )


def validate_value_domains(datasets: Dict[str, pd.DataFrame]) -> DataQualityResult:
    """Validate individual field values against contract-defined logical types.

    This is a read-only check. It does not modify any DataFrame.

    Categories supported by the current contract:

    - ``date`` columns: non-null values must be parseable as dates.
    - ``int`` columns: non-null values must be integer-like (whole numbers).
    - columns with a contract ``domain``: non-null values must belong to
      the allowed value set.

    Null handling is delegated to the missing-value validation layer.
    Schema, duplicate, relationship, and business-rule validation belong
    to their respective layers.

    Args:
        datasets: Mapping from dataset name to loaded pandas DataFrame.

    Returns:
        DataQualityResult with errors describing invalid values.
    """
    errors: List[ValidationIssue] = []
    dataset_results: Dict[str, DatasetResult] = {}

    for dataset_name, contract in DATASET_CONTRACTS.items():
        if dataset_name not in datasets:
            continue

        df = datasets[dataset_name]
        dataset_errors: List[ValidationIssue] = []

        for col_spec in contract.columns:
            if col_spec.name not in df.columns:
                continue

            non_null = df[col_spec.name].dropna()
            if len(non_null) == 0:
                continue

            if col_spec.dtype == "date":
                parsed = pd.to_datetime(non_null, errors="coerce")
                invalid_mask = parsed.isna()
                invalid_count = int(invalid_mask.sum())
                if invalid_count > 0:
                    dataset_errors.append(
                        ValidationIssue(
                            dataset=dataset_name,
                            rule="invalid_date",
                            severity="error",
                            status="FAIL",
                            message=(
                                f"{dataset_name}.{col_spec.name} contains "
                                f"{invalid_count} invalid date value(s)"
                            ),
                            affected_column=col_spec.name,
                            affected_rows=invalid_count,
                        )
                    )
            elif col_spec.dtype == "int":
                numeric = pd.to_numeric(non_null, errors="coerce")
                invalid_mask = numeric.isna() | (numeric != numeric.round())
                invalid_count = int(invalid_mask.sum())
                if invalid_count > 0:
                    dataset_errors.append(
                        ValidationIssue(
                            dataset=dataset_name,
                            rule="invalid_integer",
                            severity="error",
                            status="FAIL",
                            message=(
                                f"{dataset_name}.{col_spec.name} contains "
                                f"{invalid_count} invalid integer value(s)"
                            ),
                            affected_column=col_spec.name,
                            affected_rows=invalid_count,
                        )
                    )

            if col_spec.domain:
                allowed = set(col_spec.domain)
                invalid_mask = ~non_null.isin(allowed)
                invalid_count = int(invalid_mask.sum())
                if invalid_count > 0:
                    dataset_errors.append(
                        ValidationIssue(
                            dataset=dataset_name,
                            rule="invalid_category",
                            severity="error",
                            status="FAIL",
                            message=(
                                f"{dataset_name}.{col_spec.name} contains "
                                f"{invalid_count} invalid categorical value(s); "
                                f"expected one of {sorted(allowed)}"
                            ),
                            affected_column=col_spec.name,
                            affected_rows=invalid_count,
                        )
                    )

        if dataset_errors:
            dataset_results[dataset_name] = DatasetResult(
                dataset_name=dataset_name,
                passed=False,
                errors=dataset_errors,
                warnings=[],
            )
            errors.extend(dataset_errors)

    passed = len(errors) == 0
    status = "PASS" if passed else "FAIL"
    summary = (
        "All value domain validations passed."
        if passed
        else f"{len(errors)} value domain validation issue(s) found."
    )

    return DataQualityResult(
        passed=passed,
        status=status,
        summary=summary,
        dataset_results=dataset_results,
        issues=errors,
    )
