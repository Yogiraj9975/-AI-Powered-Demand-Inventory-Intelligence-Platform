# FORESIGHT — Pipeline & Data Quality by Ch.Mouryan

# Any problems regarding the code is requested to be reported with a proper report/analysis on it for effective improvisation/debugging

## Project

FORESIGHT is an AI-powered demand forecasting and inventory intelligence platform.

## For this Module

This module provides the **Pipeline & Data Quality** layer for FORESIGHT. It validates raw business datasets and determines whether they satisfy the structural and data-quality requirements necessary for downstream processing.

## overall contributions 

- **Pipeline & Data Quality Lead:** Ch.Mouryan
- **Forecasting Lead:** []
- **Risk & Business Impact Lead:** Karthik Sunkari
- **Dashboard / Deployment / Readout Lead:** Yogiraj Deshmukh

## A over view

This module does NOT implement:

- Demand forecasting or forecasting algorithms
- Forecasting-specific feature engineering
- Stockout / overstock prediction
- Risk scoring or business impact calculations
- Inventory optimization or recommendations
- Dashboard, frontend, Streamlit, or FastAPI applications
- Deployment infrastructure
- LLM functionality

## Datasets

The module validates five required raw datasets:

- `Sales_Fact.csv`
- `Products.csv`
- `Stores.csv`
- `Inventory_Fact.csv`
- `Date_Dim.csv`

## Dataset Contracts

### Products.csv

| Field | Type | Required | Purpose |
|-------|------|----------|---------|
| ProductID | string | Yes | Product identifier |
| Product Name | string | Yes | Product name |
| Category | string | Yes | Product category |
| Unit Cost | float | Yes | Unit cost |
| Unit Price | float | Yes | Unit price |
| Reorder Level | int | Yes | Reorder level |
| Lead Time Days | int | Yes | Lead time in days |

Grain: `(ProductID)`

### Stores.csv

| Field | Type | Required | Purpose |
|-------|------|----------|---------|
| StoreID | string | Yes | Store identifier |
| Store Name | string | Yes | Store name |
| Region | string | Yes | Store region |

Grain: `(StoreID)`

### Sales_Fact.csv

| Field | Type | Required | Purpose |
|-------|------|----------|---------|
| Date | date | Yes | Transaction date |
| ProductID | string | Yes | Product identifier |
| StoreID | string | Yes | Store identifier |
| Units Sold | int | Yes | Quantity sold |
| Revenue | float | Yes | Revenue |

Grain: `(Date, ProductID, StoreID)`

### Inventory_Fact.csv

| Field | Type | Required | Purpose |
|-------|------|----------|---------|
| Date | date | Yes | Snapshot date |
| ProductID | string | Yes | Product identifier |
| StoreID | string | Yes | Store identifier |
| Stock Received | int | Yes | Stock received |
| Stock On Hand (End of Week) | int | Yes | Stock on hand at end of week |
| Stockout Flag | string | Yes | Stockout indicator (Yes/No) |

Grain: `(Date, ProductID, StoreID)`

### Date_Dim.csv

| Field | Type | Required | Purpose |
|-------|------|----------|---------|
| Date | date | Yes | Calendar date |
| Year | int | Yes | Calendar year |
| Month | string | Yes | Month name |
| MonthNum | int | Yes | Month number |
| Week | int | Yes | Week number |
| Quarter | int | Yes | Quarter number |

Grain: `(Date)`

### Approved Relationships

- `sales.ProductID` → `products.ProductID`
- `inventory.ProductID` → `products.ProductID`
- `sales.StoreID` → `stores.StoreID`
- `inventory.StoreID` → `stores.StoreID`
- `sales.Date` → `date_dim.Date`
- `inventory.Date` → `date_dim.Date`

## Public API

```python
from pipeline_quality import run_data_quality_gate, DataQualityResult

result = run_data_quality_gate(raw_data_directory)

if result.passed:
    # downstream processing can continue
    trusted_data = result.data
else:
    # stop processing
    errors = result.issues
```

Downstream developers should depend only on these public symbols:

- `run_data_quality_gate`
- `DataQualityResult`
- `DatasetResult`
- `ValidationIssue`

Do not import internal modules or implementation details.

## Status Semantics

- **PASS** — Validation completed and no blocking data-quality issue exists.
- **FAIL** — Validation completed, but one or more blocking data-quality issues were found.
- **ERROR** — Validation could not be performed due to an operational problem (e.g., missing file, unreadable CSV).

## Integration Principle

This module is an upstream shared dependency for the FORESIGHT platform. It guarantees that data satisfies the defined Pipeline & Data Quality contract. It does not guarantee forecast readiness, risk-score accuracy, or dashboard fitness. Those remain the responsibility of their respective owners.

## Current State

**Phase 2.6 — contract-defined value validation implemented. Validation engine and quality gate are fully implemented.**

## Data Loading Layer

The module exposes an internal loading function:

```python
from pipeline_quality.loaders import load_raw_datasets

datasets = load_raw_datasets(raw_data_directory)
# datasets["sales"] -> pd.DataFrame
# datasets["products"] -> pd.DataFrame
# datasets["stores"] -> pd.DataFrame
# datasets["inventory"] -> pd.DataFrame
# datasets["date_dim"] -> pd.DataFrame
```

The loader:

- Accepts a directory path (`str` or `pathlib.Path`).
- Reads exactly the five required CSV files.
- Returns a dictionary of pandas DataFrames keyed by dataset name.
- Raises `FileNotFoundError` if the directory or a required CSV is missing.
- Raises `RuntimeError` if a required CSV cannot be parsed.

The loader deliberately does **not** validate, clean, or transform data. Raw values are preserved so the validation layer can detect problems.

Downstream code should call the loader only through the internal `pipeline_quality.loaders` module. The loader is not part of the stable public API.

## Schema Validation Layer

The module exposes an internal schema validator:

```python
from pipeline_quality.validators import validate_schema

result = validate_schema("sales_daily", dataframe)
# result.passed -> bool
# result.errors -> list[ValidationIssue]
# result.warnings -> list[ValidationIssue]
```

The validator:

- Derives its expectations from the Phase 1 dataset contracts.
- Checks for missing required columns (error).
- Warns on unexpected columns because the current contract does not establish a strict closed schema.
- Issues lightweight type advisories when a pandas dtype may be incompatible with the contract's logical type.
- Does **not** modify the DataFrame.
- Does **not** validate nulls, duplicates, ranges, dates, referential integrity, or business rules.

Value-level validation belongs to later phases.

## Missing-Value Validation Layer

The module exposes an internal missing-value validator:

```python
from pipeline_quality.validators import validate_missing_values

result = validate_missing_values("sales_daily", dataframe)
# result.passed -> bool
# result.errors -> list[ValidationIssue]
```

The validator:

- Derives its nullability expectations from the Phase 1 dataset contracts.
- Reports missing values in non-nullable required columns as errors.
- Reports the exact count of missing values per affected column.
- Does **not** modify the DataFrame.
- Does **not** perform schema, duplicate, range, date, referential integrity, or business-rule validation.

Value-level diagnostics belong to this layer. Overall quality gating belongs to a later phase.

## Duplicate & Key Integrity Validation Layer

The module exposes an internal duplicate validator:

```python
from pipeline_quality.validators import validate_duplicates

result = validate_duplicates("sales_daily", dataframe)
# result.passed -> bool
# result.errors -> list[ValidationIssue]
```

The validator:

- Derives uniqueness expectations from the dataset contract's ``primary_key`` or ``grain`` field.
- Reports duplicated logical keys as errors, including the count of duplicated rows and duplicated key groups.
- Treats missing key values as a missing-value concern, not a duplicate concern, so they do not produce misleading duplicate violations.
- Does **not** modify the DataFrame.
- Does **not** validate cross-dataset relationships, nulls, ranges, dates, or business rules.

Cross-dataset relationship validation belongs to a later phase.

## Cross-Dataset Relationship Integrity Validation Layer

The module exposes an internal relationship validator:

```python
from pipeline_quality.validators import validate_relationships

datasets = load_raw_datasets(raw_data_directory)
result = validate_relationships(datasets)
# result.passed -> bool
# result.issues -> list[ValidationIssue]
```

The validator:

- Derives its relationship expectations from the dataset contracts.
- Validates exactly six approved relationships:
  - `sales.ProductID` → `products.ProductID`
  - `inventory.ProductID` → `products.ProductID`
  - `sales.StoreID` → `stores.StoreID`
  - `inventory.StoreID` → `stores.StoreID`
  - `sales.Date` → `date_dim.Date`
  - `inventory.Date` → `date_dim.Date`
- For each relationship, checks whether every non-null child reference value exists in the corresponding parent reference/key column.
- Reports orphan references as errors, including the orphan row count and distinct orphan-value count.
- Ignores null child values during orphan checking. Null handling remains the responsibility of the missing-value validation layer.
- Does not report repeated valid references as violations. Duplicate/key integrity remains the responsibility of the duplicate validation layer.
- Reports structural problems (missing dataset, missing column) as distinct errors so they are not misreported as orphan values.
- Does **not** modify any DataFrame.
- Does **not** validate schema, missing values, duplicates, ranges, dates, business rules, or quality scoring.

### Orphan Definition

An orphan reference is a non-null child reference value that does not exist in the corresponding parent reference/key column.

### Orphan-Row Count

The number of child rows that contain at least one orphan reference value. If a single row contains multiple orphan values, it is still counted once per row.

### Distinct-Orphan-Value Count

The number of unique invalid reference values found among the child rows.

### NULL Behavior

Null child values are excluded from orphan checking. They are not counted as orphan rows and do not contribute to the distinct-orphan-value count. Missing-value validation is handled separately.

### Relationship Validation Boundary

Relationship validation is limited to checking referential membership between explicitly contracted datasets. It does not infer relationships, validate date ranges, parse dates, or enforce business rules.

## Contract-Defined Value Validation Layer

The module exposes an internal value-domain validator:

```python
from pipeline_quality.validators import validate_value_domains

datasets = load_raw_datasets(raw_data_directory)
result = validate_value_domains(datasets)
# result.passed -> bool
# result.issues -> list[ValidationIssue]
```

The validator:

- Derives its expectations from the dataset contracts.
- Validates non-null values against the column's declared logical type.
- Currently supports three contract-defined value categories:
  - **Date validity** — for columns with logical type ``date``, checks that non-null values are parseable dates.
  - **Integer validity** — for columns with logical type ``int``, checks that non-null values are integer-like (whole numbers).
  - **Categorical domain** — for columns with a contract ``domain`` (e.g. ``Stockout Flag``), checks that non-null values belong to the allowed value set.
- Ignores null values. Null handling remains the responsibility of the missing-value validation layer.
- Does **not** modify any DataFrame.
- Does **not** validate ranges, patterns, business rules, or quality scoring.

### Value Validation Boundary

Value-domain validation is limited to checking whether individual field values are compatible with their declared logical representation. It does not infer business semantics, enforce ranges, validate date ranges, or impose policy decisions such as string length or character restrictions. Those belong to future phases.

### Intentionally Deferred

The current contracts do not define numeric bounds or pattern constraints. Consequently, the following are intentionally not implemented in this phase:

- Minimum/maximum range checks
- Pattern / regex checks
- Business-rule validation
- Quality scoring or thresholds

## Data Quality Gate

The module exposes a public validation entry point:

```python
from pipeline_quality import run_data_quality_gate

result = run_data_quality_gate(raw_data_directory)

if result.passed:
    trusted_data = result.data
else:
    errors = result.issues
```

The gate:

- Loads raw datasets using the existing loader.
- Invokes the validation layers in dependency order:
  1. Schema validation
  2. Missing-value validation
  3. Duplicate / grain validation
  4. Cross-dataset relationship validation
  5. Contract-defined value validation
- Aggregates all `ValidationIssue` objects and `DatasetResult` objects into a unified `DataQualityResult`.
- Returns `PASS` when no validation issues are found.
- Returns `FAIL` when one or more data-quality issues are found.
- Returns `ERROR` when the raw data cannot be loaded (missing directory, missing file, or unreadable CSV).
- Populates `result.data` with the loaded datasets on success.
- Sets `result.data` to `None` on failure.
- Does **not** modify any DataFrame.
- Does **not** implement business rules, quality scoring, forecasting, risk analysis, or downstream processing.

### Integration Usage

Teammates should call `run_data_quality_gate` as the single entry point for Pipeline & Data Quality validation. The returned `DataQualityResult` contains all issues and trusted data needed for downstream processing.

### Status Semantics

- **PASS** — All validation layers completed and no blocking data-quality issue exists. `result.data` contains the trusted datasets.
- **FAIL** — One or more blocking data-quality issues were found. `result.data` is `None`. Inspect `result.issues` for details.
- **ERROR** — Validation could not be performed due to an operational problem (e.g., missing file, unreadable CSV). `result.data` is `None`.
