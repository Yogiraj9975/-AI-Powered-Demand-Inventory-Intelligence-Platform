"""Adversarial audit tests for the Pipeline & Data Quality gate."""
import pandas as pd
import pytest

from pipeline_quality import run_data_quality_gate
from pipeline_quality.contracts import DATASET_CONTRACTS


def _write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    header = ",".join(rows[0].keys())
    lines = [header]
    for row in rows:
        lines.append(",".join("" if row[k] is None else str(row[k]) for k in rows[0].keys()))
    path.write_text("\n".join(lines))


def _base_valid(tmp_path):
    _write_csv(tmp_path / "Sales_Fact.csv", [
        {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
        {"Date": "2024-01-02", "ProductID": "P2", "StoreID": "S2", "Units Sold": "5", "Revenue": "30.0"},
    ])
    _write_csv(tmp_path / "Products.csv", [
        {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        {"ProductID": "P2", "Product Name": "Widget B", "Category": "Gadgets", "Unit Cost": "3.0", "Unit Price": "6.0", "Reorder Level": "15", "Lead Time Days": "5"},
    ])
    _write_csv(tmp_path / "Stores.csv", [
        {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        {"StoreID": "S2", "Store Name": "Store Two", "Region": "South"},
    ])
    _write_csv(tmp_path / "Inventory_Fact.csv", [
        {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        {"Date": "2024-01-02", "ProductID": "P2", "StoreID": "S2", "Stock Received": "30", "Stock On Hand (End of Week)": "60", "Stockout Flag": "No"},
    ])
    _write_csv(tmp_path / "Date_Dim.csv", [
        {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        {"Date": "2024-01-02", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
    ])


PRODUCTS_REQ = ["ProductID", "Product Name", "Category", "Unit Cost", "Unit Price", "Reorder Level", "Lead Time Days"]
STORES_REQ = ["StoreID", "Store Name", "Region"]
SALES_REQ = ["Date", "ProductID", "StoreID", "Units Sold", "Revenue"]
INVENTORY_REQ = ["Date", "ProductID", "StoreID", "Stock Received", "Stock On Hand (End of Week)", "Stockout Flag"]
DATE_DIM_REQ = ["Date", "Year", "Month", "MonthNum", "Week", "Quarter"]

# ---------- A. Contract verification ----------
@pytest.mark.parametrize("dataset,req_cols", [
    ("products", PRODUCTS_REQ),
    ("stores", STORES_REQ),
    ("sales", SALES_REQ),
    ("inventory", INVENTORY_REQ),
    ("date_dim", DATE_DIM_REQ),
])
def test_contract_required_columns_exact(dataset, req_cols):
    contract = DATASET_CONTRACTS[dataset]
    cols = [c.name for c in contract.columns if c.required]
    assert cols == req_cols


@pytest.mark.parametrize("dataset,key", [
    ("products", ("ProductID",)),
    ("stores", ("StoreID",)),
    ("date_dim", ("Date",)),
    ("sales", ("Date", "ProductID", "StoreID")),
    ("inventory", ("Date", "ProductID", "StoreID")),
])
def test_contract_primary_key_exact(dataset, key):
    contract = DATASET_CONTRACTS[dataset]
    assert contract.primary_key == key


# ---------- B. Schema attacks ----------
@pytest.mark.parametrize("missing", [
    "ProductID", "Product Name", "Category", "Unit Cost", "Unit Price",
    "Reorder Level", "Lead Time Days",
])
def test_products_missing_each_required_column(tmp_path, missing):
    present = [c for c in PRODUCTS_REQ if c != missing]
    _write_csv(tmp_path / "Products.csv", [{k: "" for k in present}])
    _write_csv(tmp_path / "Sales_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "1", "Revenue": "1.0"}])
    _write_csv(tmp_path / "Stores.csv", [{"StoreID": "S1", "Store Name": "S1", "Region": "N"}])
    _write_csv(tmp_path / "Inventory_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "1", "Stock On Hand (End of Week)": "1", "Stockout Flag": "No"}])
    _write_csv(tmp_path / "Date_Dim.csv", [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}])
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is False
    assert any(i.rule == "required_columns" and i.affected_column == missing for i in r.issues), f"missing {missing} not reported"


def test_zero_column_products(tmp_path):
    (tmp_path / "Products.csv").write_text("")
    _write_csv(tmp_path / "Sales_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "1", "Revenue": "1.0"}])
    _write_csv(tmp_path / "Stores.csv", [{"StoreID": "S1", "Store Name": "S1", "Region": "N"}])
    _write_csv(tmp_path / "Inventory_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "1", "Stock On Hand (End of Week)": "1", "Stockout Flag": "No"}])
    _write_csv(tmp_path / "Date_Dim.csv", [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}])
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is False
    assert "required_columns" in {i.rule for i in r.issues}


def test_completely_unrelated_columns(tmp_path):
    _write_csv(tmp_path / "Products.csv", [{"foo": "x", "bar": "y", "baz": "z"}])
    _write_csv(tmp_path / "Sales_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "1", "Revenue": "1.0"}])
    _write_csv(tmp_path / "Stores.csv", [{"StoreID": "S1", "Store Name": "S1", "Region": "N"}])
    _write_csv(tmp_path / "Inventory_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "1", "Stock On Hand (End of Week)": "1", "Stockout Flag": "No"}])
    _write_csv(tmp_path / "Date_Dim.csv", [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}])
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is False


def test_extra_columns_does_not_break_gate(tmp_path):
    _base_valid(tmp_path)
    extra = tmp_path / "Products.csv"
    df = pd.read_csv(extra)
    df["ExtraColumn"] = "X"
    df.to_csv(extra, index=False)
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is True, f"extra column unexpectedly failed; issues: {r.issues}"


def test_column_name_case_sensitive(tmp_path):
    _write_csv(tmp_path / "Products.csv", [{"ProductId": "P1", "Product Name": "W", "Category": "C", "Unit Cost": "1.0", "Unit Price": "2.0", "Reorder Level": "1", "Lead Time Days": "1"}])
    _write_csv(tmp_path / "Sales_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "1", "Revenue": "1.0"}])
    _write_csv(tmp_path / "Stores.csv", [{"StoreID": "S1", "Store Name": "S1", "Region": "N"}])
    _write_csv(tmp_path / "Inventory_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "1", "Stock On Hand (End of Week)": "1", "Stockout Flag": "No"}])
    _write_csv(tmp_path / "Date_Dim.csv", [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}])
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is False
    assert any(i.rule == "required_columns" and i.affected_column == "ProductID" for i in r.issues)


# ---------- C. Empty dataset ----------
def test_empty_sales_csv(tmp_path):
    (tmp_path / "Sales_Fact.csv").write_text("Date,ProductID,StoreID,Units Sold,Revenue`n")
    _write_csv(tmp_path / "Products.csv", [{"ProductID": "P1", "Product Name": "W", "Category": "C", "Unit Cost": "1.0", "Unit Price": "2.0", "Reorder Level": "1", "Lead Time Days": "1"}])
    _write_csv(tmp_path / "Stores.csv", [{"StoreID": "S1", "Store Name": "S1", "Region": "N"}])
    _write_csv(tmp_path / "Inventory_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "1", "Stock On Hand (End of Week)": "1", "Stockout Flag": "No"}])
    _write_csv(tmp_path / "Date_Dim.csv", [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}])
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is False
    assert any(i.rule == "empty_dataset" and i.dataset == "sales" for i in r.issues)


# ---------- D. Null attacks ----------
@pytest.mark.parametrize("col", ["ProductID", "Product Name", "Category", "Unit Cost", "Unit Price", "Reorder Level", "Lead Time Days"])
def test_products_null_in_required_field(tmp_path, col):
    row = {c: ("x" if c != col else "") for c in PRODUCTS_REQ}
    _write_csv(tmp_path / "Products.csv", [row])
    _write_csv(tmp_path / "Sales_Fact.csv", [{"Date": "2024-01-01", "ProductID": "x", "StoreID": "S1", "Units Sold": "1", "Revenue": "1.0"}])
    _write_csv(tmp_path / "Stores.csv", [{"StoreID": "S1", "Store Name": "S1", "Region": "N"}])
    _write_csv(tmp_path / "Inventory_Fact.csv", [{"Date": "2024-01-01", "ProductID": "x", "StoreID": "S1", "Stock Received": "1", "Stock On Hand (End of Week)": "1", "Stockout Flag": "No"}])
    _write_csv(tmp_path / "Date_Dim.csv", [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}])
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is False
    assert any(i.rule == "missing_values" and i.affected_column == col for i in r.issues), f"missing_values not reported for {col}"


@pytest.mark.parametrize("col", ["StoreID", "Store Name", "Region"])
def test_stores_null_in_required_field(tmp_path, col):
    row = {c: ("x" if c != col else "") for c in STORES_REQ}
    _write_csv(tmp_path / "Stores.csv", [row])
    _write_csv(tmp_path / "Sales_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "x", "Units Sold": "1", "Revenue": "1.0"}])
    _write_csv(tmp_path / "Products.csv", [{"ProductID": "P1", "Product Name": "W", "Category": "C", "Unit Cost": "1.0", "Unit Price": "2.0", "Reorder Level": "1", "Lead Time Days": "1"}])
    _write_csv(tmp_path / "Inventory_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "x", "Stock Received": "1", "Stock On Hand (End of Week)": "1", "Stockout Flag": "No"}])
    _write_csv(tmp_path / "Date_Dim.csv", [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}])
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is False
    assert any(i.rule == "missing_values" and i.affected_column == col for i in r.issues)


@pytest.mark.parametrize("col", ["Date", "ProductID", "StoreID", "Units Sold", "Revenue"])
def test_sales_null_in_required_field(tmp_path, col):
    row = {c: ("x" if c != col else "") for c in SALES_REQ}
    _write_csv(tmp_path / "Sales_Fact.csv", [row])
    _write_csv(tmp_path / "Products.csv", [{"ProductID": "P1", "Product Name": "W", "Category": "C", "Unit Cost": "1.0", "Unit Price": "2.0", "Reorder Level": "1", "Lead Time Days": "1"}])
    _write_csv(tmp_path / "Stores.csv", [{"StoreID": "S1", "Store Name": "S1", "Region": "N"}])
    _write_csv(tmp_path / "Inventory_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "1", "Stock On Hand (End of Week)": "1", "Stockout Flag": "No"}])
    _write_csv(tmp_path / "Date_Dim.csv", [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}])
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is False
    assert any(i.rule == "missing_values" and i.affected_column == col for i in r.issues)


@pytest.mark.parametrize("col", ["Date", "ProductID", "StoreID", "Stock Received", "Stock On Hand (End of Week)", "Stockout Flag"])
def test_inventory_null_in_required_field(tmp_path, col):
    row = {c: ("x" if c != col else "") for c in INVENTORY_REQ}
    _write_csv(tmp_path / "Inventory_Fact.csv", [row])
    _write_csv(tmp_path / "Products.csv", [{"ProductID": "P1", "Product Name": "W", "Category": "C", "Unit Cost": "1.0", "Unit Price": "2.0", "Reorder Level": "1", "Lead Time Days": "1"}])
    _write_csv(tmp_path / "Stores.csv", [{"StoreID": "S1", "Store Name": "S1", "Region": "N"}])
    _write_csv(tmp_path / "Sales_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "1", "Revenue": "1.0"}])
    _write_csv(tmp_path / "Date_Dim.csv", [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}])
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is False
    assert any(i.rule == "missing_values" and i.affected_column == col for i in r.issues)


@pytest.mark.parametrize("col", ["Date", "Year", "Month", "MonthNum", "Week", "Quarter"])
def test_date_dim_null_in_required_field(tmp_path, col):
    row = {c: ("x" if c != col else "") for c in DATE_DIM_REQ}
    _write_csv(tmp_path / "Date_Dim.csv", [row])
    _write_csv(tmp_path / "Products.csv", [{"ProductID": "P1", "Product Name": "W", "Category": "C", "Unit Cost": "1.0", "Unit Price": "2.0", "Reorder Level": "1", "Lead Time Days": "1"}])
    _write_csv(tmp_path / "Stores.csv", [{"StoreID": "S1", "Store Name": "S1", "Region": "N"}])
    _write_csv(tmp_path / "Sales_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "1", "Revenue": "1.0"}])
    _write_csv(tmp_path / "Inventory_Fact.csv", [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "1", "Stock On Hand (End of Week)": "1", "Stockout Flag": "No"}])
    r = run_data_quality_gate(str(tmp_path))
    assert r.passed is False
    assert any(i.rule == "missing_values" and i.affected_column == col for i in r.issues)
