import pandas as pd
import pytest

from pipeline_quality.contracts import (
    PRODUCTS_CONTRACT,
    STORES_CONTRACT,
    SALES_FACT_CONTRACT,
    INVENTORY_FACT_CONTRACT,
    DATE_DIM_CONTRACT,
)
from pipeline_quality.validators import validate_schema


def test_valid_products():
    df = pd.DataFrame(
        {
            "ProductID": ["P1", "P2"],
            "Product Name": ["Widget A", "Widget B"],
            "Category": ["Gadgets", "Gadgets"],
            "Unit Cost": [5.0, 3.0],
            "Unit Price": [10.0, 6.0],
            "Reorder Level": [20, 15],
            "Lead Time Days": [7, 5],
        }
    )
    result = validate_schema("products", df)
    assert result.passed is True
    assert len(result.errors) == 0
    assert len(result.warnings) == 0


def test_valid_stores():
    df = pd.DataFrame(
        {
            "StoreID": ["S1", "S2"],
            "Store Name": ["Store One", "Store Two"],
            "Region": ["North", "South"],
        }
    )
    result = validate_schema("stores", df)
    assert result.passed is True
    assert len(result.errors) == 0
    assert len(result.warnings) == 0


def test_valid_sales():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    result = validate_schema("sales", df)
    assert result.passed is True
    assert len(result.errors) == 0
    assert len(result.warnings) == 0


def test_valid_inventory():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", "No"],
        }
    )
    result = validate_schema("inventory", df)
    assert result.passed is True
    assert len(result.errors) == 0
    assert len(result.warnings) == 0


def test_valid_date_dim():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "Year": [2024, 2024],
            "Month": ["January", "January"],
            "MonthNum": [1, 1],
            "Week": [1, 1],
            "Quarter": [1, 1],
        }
    )
    result = validate_schema("date_dim", df)
    assert result.passed is True
    assert len(result.errors) == 0
    assert len(result.warnings) == 0


def test_missing_storeid_from_sales():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01"],
            "ProductID": ["P1"],
            "Units Sold": [10],
            "Revenue": [100.0],
        }
    )
    result = validate_schema("sales", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_column == "StoreID"
    assert "missing required column" in result.errors[0].message


def test_missing_storeid_from_inventory():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01"],
            "ProductID": ["P1"],
            "Stock Received": [50],
            "Stock On Hand (End of Week)": [100],
            "Stockout Flag": ["No"],
        }
    )
    result = validate_schema("inventory", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_column == "StoreID"
    assert "missing required column" in result.errors[0].message


def test_missing_productid():
    df = pd.DataFrame(
        {
            "Product Name": ["Widget A"],
            "Category": ["Gadgets"],
            "Unit Cost": [5.0],
            "Unit Price": [10.0],
            "Reorder Level": [20],
            "Lead Time Days": [7],
        }
    )
    result = validate_schema("products", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_column == "ProductID"


def test_missing_date():
    df = pd.DataFrame(
        {
            "ProductID": ["P1"],
            "StoreID": ["S1"],
            "Units Sold": [10],
            "Revenue": [100.0],
        }
    )
    result = validate_schema("sales", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_column == "Date"


def test_exact_real_column_names_accepted():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01"],
            "ProductID": ["P1"],
            "StoreID": ["S1"],
            "Stock Received": [50],
            "Stock On Hand (End of Week)": [100],
            "Stockout Flag": ["No"],
        }
    )
    result = validate_schema("inventory", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_unexpected_columns_are_warnings_not_errors():
    df = pd.DataFrame(
        {
            "ProductID": ["P1"],
            "Product Name": ["Widget A"],
            "Category": ["Gadgets"],
            "Unit Cost": [5.0],
            "Unit Price": [10.0],
            "Reorder Level": [20],
            "Lead Time Days": [7],
            "extra_col": ["x"],
        }
    )
    result = validate_schema("products", df)
    assert result.passed is True
    assert len(result.errors) == 0
    assert len(result.warnings) == 1
    assert result.warnings[0].affected_column == "extra_col"
    assert "unexpected column" in result.warnings[0].message


def test_type_incompatibility_advisory():
    df = pd.DataFrame(
        {
            "ProductID": [1, 2, 3],
            "Product Name": ["A", "B", "C"],
            "Category": ["Gadgets", "Gadgets", "Gadgets"],
            "Unit Cost": [5.0, 3.0, 2.0],
            "Unit Price": [10.0, 6.0, 4.0],
            "Reorder Level": [20, 15, 10],
            "Lead Time Days": [7, 5, 3],
        }
    )
    result = validate_schema("products", df)
    assert result.passed is True
    assert len(result.errors) == 0
    assert len(result.warnings) == 1
    assert result.warnings[0].affected_column == "ProductID"
    assert "incompatible" in result.warnings[0].message


def test_empty_dataset_fails_schema():
    df = pd.DataFrame(
        {
            "ProductID": pd.Series([], dtype="object"),
            "Product Name": pd.Series([], dtype="object"),
            "Category": pd.Series([], dtype="object"),
            "Unit Cost": pd.Series([], dtype="float64"),
            "Unit Price": pd.Series([], dtype="float64"),
            "Reorder Level": pd.Series([], dtype="int64"),
            "Lead Time Days": pd.Series([], dtype="int64"),
        }
    )
    result = validate_schema("products", df)
    assert result.passed is False
    assert any(issue.rule == "empty_dataset" for issue in result.errors)


def test_multiple_structural_problems():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01"],
            "Units Sold": [10],
            "extra_col": ["x"],
        }
    )
    result = validate_schema("sales", df)
    assert result.passed is False
    missing_cols = {error.affected_column for error in result.errors}
    assert "ProductID" in missing_cols
    assert "StoreID" in missing_cols
    assert "Revenue" in missing_cols
    assert len(result.warnings) == 1
    assert result.warnings[0].affected_column == "extra_col"


def test_unknown_dataset_raises():
    df = pd.DataFrame({"a": [1]})
    with pytest.raises(ValueError):
        validate_schema("unknown_dataset", df)


def test_dataframe_is_not_modified():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01"],
            "ProductID": ["P1"],
            "StoreID": ["S1"],
            "Units Sold": [10],
            "Revenue": [100.0],
        }
    )
    original_id = id(df)
    original_columns = list(df.columns)
    original_shape = df.shape

    validate_schema("sales", df)

    assert id(df) == original_id
    assert list(df.columns) == original_columns
    assert df.shape == original_shape


def test_all_five_known_datasets_validate():
    datasets = {
        "products": pd.DataFrame(
            {
                "ProductID": ["P1"],
                "Product Name": ["Widget A"],
                "Category": ["Gadgets"],
                "Unit Cost": [5.0],
                "Unit Price": [10.0],
                "Reorder Level": [20],
                "Lead Time Days": [7],
            }
        ),
        "stores": pd.DataFrame(
            {
                "StoreID": ["S1"],
                "Store Name": ["Store One"],
                "Region": ["North"],
            }
        ),
        "sales": pd.DataFrame(
            {
                "Date": ["2024-01-01"],
                "ProductID": ["P1"],
                "StoreID": ["S1"],
                "Units Sold": [10],
                "Revenue": [100.0],
            }
        ),
        "inventory": pd.DataFrame(
            {
                "Date": ["2024-01-01"],
                "ProductID": ["P1"],
                "StoreID": ["S1"],
                "Stock Received": [50],
                "Stock On Hand (End of Week)": [100],
                "Stockout Flag": ["No"],
            }
        ),
        "date_dim": pd.DataFrame(
            {
                "Date": ["2024-01-01"],
                "Year": [2024],
                "Month": ["January"],
                "MonthNum": [1],
                "Week": [1],
                "Quarter": [1],
            }
        ),
    }
    for name, df in datasets.items():
        result = validate_schema(name, df)
        assert result.passed is True, f"{name} should pass schema validation"
        assert len(result.errors) == 0
        assert len(result.warnings) == 0
