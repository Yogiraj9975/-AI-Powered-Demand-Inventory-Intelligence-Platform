import pytest
import pandas as pd
from pathlib import Path

from pipeline_quality.loaders import load_raw_datasets, REQUIRED_DATASETS


def _write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    header = ",".join(rows[0].keys())
    lines = [header]
    for row in rows:
        lines.append(",".join(str(row[k]) for k in rows[0].keys()))
    path.write_text("\n".join(lines))


def _write_all_valid(data_dir):
    _write_csv(
        data_dir / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
            {"Date": "2024-01-02", "ProductID": "P2", "StoreID": "S2", "Units Sold": "5", "Revenue": "30.0"},
        ],
    )
    _write_csv(
        data_dir / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
            {"ProductID": "P2", "Product Name": "Widget B", "Category": "Gadgets", "Unit Cost": "3.0", "Unit Price": "6.0", "Reorder Level": "15", "Lead Time Days": "5"},
        ],
    )
    _write_csv(
        data_dir / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
            {"StoreID": "S2", "Store Name": "Store Two", "Region": "South"},
        ],
    )
    _write_csv(
        data_dir / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
            {"Date": "2024-01-02", "ProductID": "P2", "StoreID": "S2", "Stock Received": "30", "Stock On Hand (End of Week)": "60", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        data_dir / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
            {"Date": "2024-01-02", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )


def test_load_all_five_valid_csvs(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()
    _write_all_valid(data_dir)

    datasets = load_raw_datasets(str(data_dir))

    assert set(datasets.keys()) == set(REQUIRED_DATASETS.keys())
    assert len(datasets["sales"]) == 2
    assert len(datasets["products"]) == 2
    assert len(datasets["stores"]) == 2
    assert len(datasets["inventory"]) == 2
    assert len(datasets["date_dim"]) == 2


def test_loaded_datasets_are_deterministic(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()
    _write_all_valid(data_dir)

    first = load_raw_datasets(data_dir)
    second = load_raw_datasets(data_dir)

    for name in REQUIRED_DATASETS.keys():
        pd.testing.assert_frame_equal(first[name], second[name])


def test_missing_data_directory():
    with pytest.raises(FileNotFoundError):
        load_raw_datasets("/nonexistent/path/to/nowhere")


def test_path_not_a_directory(tmp_path):
    file_path = tmp_path / "not_a_dir.csv"
    file_path.write_text("a,b\n1,2")
    with pytest.raises(FileNotFoundError):
        load_raw_datasets(file_path)


def test_missing_sales_fact_csv(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()

    _write_csv(
        data_dir / "Products.csv",
        [{"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"}],
    )
    _write_csv(data_dir / "Stores.csv", [{"StoreID": "S1", "Store Name": "Store One", "Region": "North"}])
    _write_csv(
        data_dir / "Inventory_Fact.csv",
        [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"}],
    )
    _write_csv(
        data_dir / "Date_Dim.csv",
        [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}],
    )

    with pytest.raises(FileNotFoundError) as exc_info:
        load_raw_datasets(data_dir)

    assert "Sales_Fact.csv" in str(exc_info.value)


def test_missing_products_csv(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()

    _write_csv(
        data_dir / "Sales_Fact.csv",
        [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"}],
    )
    _write_csv(data_dir / "Stores.csv", [{"StoreID": "S1", "Store Name": "Store One", "Region": "North"}])
    _write_csv(
        data_dir / "Inventory_Fact.csv",
        [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"}],
    )
    _write_csv(
        data_dir / "Date_Dim.csv",
        [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}],
    )

    with pytest.raises(FileNotFoundError) as exc_info:
        load_raw_datasets(data_dir)

    assert "Products.csv" in str(exc_info.value)


def test_missing_stores_csv(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()

    _write_csv(
        data_dir / "Sales_Fact.csv",
        [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"}],
    )
    _write_csv(
        data_dir / "Products.csv",
        [{"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"}],
    )
    _write_csv(
        data_dir / "Inventory_Fact.csv",
        [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"}],
    )
    _write_csv(
        data_dir / "Date_Dim.csv",
        [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}],
    )

    with pytest.raises(FileNotFoundError) as exc_info:
        load_raw_datasets(data_dir)

    assert "Stores.csv" in str(exc_info.value)


def test_missing_inventory_fact_csv(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()

    _write_csv(
        data_dir / "Sales_Fact.csv",
        [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"}],
    )
    _write_csv(
        data_dir / "Products.csv",
        [{"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"}],
    )
    _write_csv(data_dir / "Stores.csv", [{"StoreID": "S1", "Store Name": "Store One", "Region": "North"}])
    _write_csv(
        data_dir / "Date_Dim.csv",
        [{"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"}],
    )

    with pytest.raises(FileNotFoundError) as exc_info:
        load_raw_datasets(data_dir)

    assert "Inventory_Fact.csv" in str(exc_info.value)


def test_missing_date_dim_csv(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()

    _write_csv(
        data_dir / "Sales_Fact.csv",
        [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"}],
    )
    _write_csv(
        data_dir / "Products.csv",
        [{"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"}],
    )
    _write_csv(data_dir / "Stores.csv", [{"StoreID": "S1", "Store Name": "Store One", "Region": "North"}])
    _write_csv(
        data_dir / "Inventory_Fact.csv",
        [{"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"}],
    )

    with pytest.raises(FileNotFoundError) as exc_info:
        load_raw_datasets(data_dir)

    assert "Date_Dim.csv" in str(exc_info.value)


def test_empty_required_csv_detected(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()
    _write_all_valid(data_dir)

    empty_file = data_dir / "Products.csv"
    empty_file.write_text("ProductID,Product Name,Category,Unit Cost,Unit Price,Reorder Level,Lead Time Days\n")

    datasets = load_raw_datasets(data_dir)
    assert len(datasets["products"]) == 0


def test_unreadable_malformed_csv(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()
    _write_all_valid(data_dir)

    bad_file = data_dir / "Sales_Fact.csv"
    bad_file.write_bytes(b"\xff\xfe\x00\x01\x02\x03\x04\x05")

    with pytest.raises(RuntimeError) as exc_info:
        load_raw_datasets(data_dir)

    assert "Sales_Fact.csv" in str(exc_info.value)
    assert exc_info.value.__cause__ is not None


def test_string_path_input(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()
    _write_all_valid(data_dir)

    datasets = load_raw_datasets(str(data_dir))
    assert len(datasets) == 5


def test_path_object_input(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()
    _write_all_valid(data_dir)

    datasets = load_raw_datasets(data_dir)
    assert len(datasets) == 5


def test_raw_values_not_cleaned_during_load(tmp_path):
    data_dir = tmp_path / "raw"
    data_dir.mkdir()

    _write_csv(
        data_dir / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
            {"Date": "2024-01-02", "ProductID": "P2", "StoreID": "S2", "Units Sold": "", "Revenue": "30.0"},
            {"Date": "2024-01-03", "ProductID": "P1", "StoreID": "S1", "Units Sold": "not_a_number", "Revenue": "10.0"},
        ],
    )
    _write_csv(
        data_dir / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
            {"ProductID": "P2", "Product Name": "Widget B", "Category": "Gadgets", "Unit Cost": "3.0", "Unit Price": "6.0", "Reorder Level": "15", "Lead Time Days": "5"},
        ],
    )
    _write_csv(
        data_dir / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
            {"StoreID": "S2", "Store Name": "Store Two", "Region": "South"},
        ],
    )
    _write_csv(
        data_dir / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
            {"Date": "2024-01-02", "ProductID": "P2", "StoreID": "S2", "Stock Received": "30", "Stock On Hand (End of Week)": "60", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        data_dir / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
            {"Date": "2024-01-02", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    datasets = load_raw_datasets(data_dir)

    sales = datasets["sales"]
    assert len(sales) == 3
    assert sales["Units Sold"].iloc[0] == "10"
    assert pd.isna(sales["Units Sold"].iloc[1])
    assert sales["Units Sold"].iloc[2] == "not_a_number"
