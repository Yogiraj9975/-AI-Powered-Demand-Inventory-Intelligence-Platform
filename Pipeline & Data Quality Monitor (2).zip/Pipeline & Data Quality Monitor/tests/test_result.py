import pytest
from pipeline_quality.result import ValidationIssue, DatasetResult, DataQualityResult


def test_validation_issue_construction():
    issue = ValidationIssue(
        dataset="sales",
        rule="required_columns",
        severity="error",
        status="FAIL",
        message="Missing required column: Date",
        affected_column="Date",
        affected_rows=10,
    )
    assert issue.dataset == "sales"
    assert issue.rule == "required_columns"
    assert issue.severity == "error"
    assert issue.status == "FAIL"
    assert issue.message == "Missing required column: Date"
    assert issue.affected_column == "Date"
    assert issue.affected_rows == 10


def test_validation_issue_optional_fields_none():
    issue = ValidationIssue(
        dataset="date_dim",
        rule="schema",
        severity="warning",
        status="WARN",
        message="Optional column missing.",
    )
    assert issue.affected_column is None
    assert issue.affected_rows is None


def test_dataset_result_defaults():
    result = DatasetResult(dataset_name="sales", passed=True)
    assert result.dataset_name == "sales"
    assert result.passed is True
    assert result.errors == []
    assert result.warnings == []


def test_dataset_result_with_issues():
    issue = ValidationIssue(
        dataset="sales",
        rule="null_check",
        severity="error",
        status="FAIL",
        message="Null found in required field.",
        affected_column="ProductID",
        affected_rows=5,
    )
    result = DatasetResult(
        dataset_name="sales",
        passed=False,
        errors=[issue],
        warnings=[],
    )
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_column == "ProductID"
    assert len(result.warnings) == 0


def test_data_quality_result_pass():
    result = DataQualityResult(
        passed=True,
        status="PASS",
        summary="All datasets passed validation.",
    )
    assert result.passed is True
    assert result.status == "PASS"
    assert result.summary == "All datasets passed validation."
    assert result.dataset_results == {}
    assert result.issues == []
    assert result.data is None


def test_data_quality_result_fail():
    result = DataQualityResult(
        passed=False,
        status="FAIL",
        summary="Validation failed.",
    )
    assert result.passed is False
    assert result.status == "FAIL"


def test_data_quality_result_error():
    result = DataQualityResult(
        passed=False,
        status="ERROR",
        summary="Operational failure: missing input directory.",
    )
    assert result.passed is False
    assert result.status == "ERROR"


def test_data_quality_result_with_data():
    import pandas as pd
    df = pd.DataFrame({"a": [1, 2]})
    result = DataQualityResult(
        passed=True,
        status="PASS",
        summary="Pass.",
        data={"sales": df},
    )
    assert result.data is not None
    assert "sales" in result.data
    assert len(result.data["sales"]) == 2
