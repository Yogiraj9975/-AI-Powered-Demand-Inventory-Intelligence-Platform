import pandas as pd
import pytest
from pipeline_quality import (
    run_data_quality_gate,
    DataQualityResult,
    DatasetResult,
    ValidationIssue,
)


def test_public_symbols_importable():
    assert callable(run_data_quality_gate)
    assert DataQualityResult is not None
    assert DatasetResult is not None
    assert ValidationIssue is not None


def test_run_data_quality_gate_returns_data_quality_result(tmp_path):
    import pipeline_quality.loaders as loaders_mod

    original = dict(loaders_mod.REQUIRED_DATASETS)
    try:
        loaders_mod.REQUIRED_DATASETS = {}
        result = run_data_quality_gate(str(tmp_path))
        assert isinstance(result, DataQualityResult)
    finally:
        loaders_mod.REQUIRED_DATASETS = original


def test_data_quality_result_is_public_type():
    result = DataQualityResult(
        passed=True,
        status="PASS",
        summary="Phase 1 placeholder.",
    )
    assert isinstance(result, DataQualityResult)


def test_validation_issue_is_public_type():
    issue = ValidationIssue(
        dataset="sales",
        rule="placeholder",
        severity="error",
        status="FAIL",
        message="Not yet implemented.",
    )
    assert isinstance(issue, ValidationIssue)


def test_dataset_result_is_public_type():
    result = DatasetResult(dataset_name="sales", passed=True)
    assert isinstance(result, DatasetResult)
