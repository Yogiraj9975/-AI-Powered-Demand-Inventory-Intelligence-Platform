import pandas as pd
import pytest

from pipeline_quality import run_data_quality_gate, DataQualityResult


def _write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    header = ",".join(rows[0].keys())
    lines = [header]
    for row in rows:
        lines.append(",".join(str(row[k]) for k in rows[0].keys()))
    path.write_text("\n".join(lines))


def _write_all_valid(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
            {"Date": "2024-01-02", "ProductID": "P2", "StoreID": "S2", "Units Sold": "5", "Revenue": "30.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
            {"ProductID": "P2", "Product Name": "Widget B", "Category": "Gadgets", "Unit Cost": "3.0", "Unit Price": "6.0", "Reorder Level": "15", "Lead Time Days": "5"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
            {"StoreID": "S2", "Store Name": "Store Two", "Region": "South"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
            {"Date": "2024-01-02", "ProductID": "P2", "StoreID": "S2", "Stock Received": "30", "Stock On Hand (End of Week)": "60", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
            {"Date": "2024-01-02", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )


def test_valid_datasets_return_pass(tmp_path):
    _write_all_valid(tmp_path)

    result = run_data_quality_gate(str(tmp_path))

    assert result.passed is True
    assert result.status == "PASS"
    assert len(result.issues) == 0
    assert result.data is not None
    assert set(result.data.keys()) == {
        "sales",
        "products",
        "stores",
        "inventory",
        "date_dim",
    }


def test_schema_violation_reports_failure(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))

    assert result.passed is False
    assert result.status == "FAIL"
    assert len(result.issues) > 0
    assert any(issue.rule == "required_columns" for issue in result.issues)


def test_missing_value_violation_reports_failure(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))

    assert result.passed is False
    assert result.status == "FAIL"
    assert any(issue.rule == "missing_values" for issue in result.issues)


def test_duplicate_violation_reports_failure(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "12", "Revenue": "120.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))

    assert result.passed is False
    assert result.status == "FAIL"
    assert any(issue.rule == "duplicate_key" for issue in result.issues)


def test_relationship_violation_reports_failure(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "BAD", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))

    assert result.passed is False
    assert result.status == "FAIL"
    assert any(issue.rule == "orphan_reference" for issue in result.issues)


def test_invalid_value_violation_reports_failure(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "not-a-date", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))

    assert result.passed is False
    assert result.status == "FAIL"
    assert any(issue.rule == "invalid_date" for issue in result.issues)


def test_multiple_simultaneous_failures_retain_all_issues(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "not-a-date", "ProductID": "BAD", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
            {"Date": "2024-01-01", "ProductID": "BAD", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))

    assert result.passed is False
    assert result.status == "FAIL"
    rules = {issue.rule for issue in result.issues}
    assert "invalid_date" in rules
    assert "orphan_reference" in rules


def test_result_is_data_quality_result(tmp_path):
    _write_all_valid(tmp_path)

    result = run_data_quality_gate(str(tmp_path))
    assert isinstance(result, DataQualityResult)


def test_successful_data_propagation(tmp_path):
    _write_all_valid(tmp_path)

    result = run_data_quality_gate(str(tmp_path))
    assert result.data is not None
    assert len(result.data["sales"]) == 2
    assert len(result.data["products"]) == 2
    assert len(result.data["stores"]) == 2
    assert len(result.data["inventory"]) == 2
    assert len(result.data["date_dim"]) == 2


def test_failed_validation_data_is_none(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "not-a-date", "ProductID": "BAD", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))
    assert result.data is None


def test_dataframe_immutability(tmp_path):
    _write_all_valid(tmp_path)

    result = run_data_quality_gate(str(tmp_path))

    assert result.data is not None
    for name, df in result.data.items():
        assert list(df.columns) == list(df.columns)
        assert df.shape == df.shape
        assert (df.dtypes == df.dtypes).all()


def test_missing_data_directory_returns_error():
    with pytest.raises(FileNotFoundError):
        run_data_quality_gate("/nonexistent/path/to/nowhere")


def test_dataset_results_populated(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "not-a-date", "ProductID": "BAD", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))
    assert "sales" in result.dataset_results
    assert result.dataset_results["sales"].passed is False
    assert len(result.dataset_results["sales"].errors) > 0


def test_empty_dataset_causes_gate_failure(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    (tmp_path / "Products.csv").write_text(
        "ProductID,Product Name,Category,Unit Cost,Unit Price,Reorder Level,Lead Time Days\n"
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))
    assert result.passed is False
    assert result.status == "FAIL"
    assert result.data is None
    assert any(issue.rule == "empty_dataset" for issue in result.issues)


def test_schema_failure_fails_gate_before_downstream(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))
    assert result.passed is False
    assert result.data is None
    assert any(
        issue.rule == "required_columns" and issue.affected_column == "StoreID"
        for issue in result.issues
    )


def test_no_partial_output_after_fatal_schema_failure(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))
    assert result.passed is False
    assert result.data is None


def test_referential_integrity_failure_fails_gate(tmp_path):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "NOPE", "Units Sold": "10", "Revenue": "100.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )

    result = run_data_quality_gate(str(tmp_path))
    assert result.passed is False
    assert result.data is None
    assert any(
        issue.rule == "orphan_reference" and issue.affected_column == "StoreID"
        for issue in result.issues
    )
