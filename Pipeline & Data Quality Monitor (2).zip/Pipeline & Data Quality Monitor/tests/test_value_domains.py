import numpy as np
import pandas as pd
import pytest

from pipeline_quality.validators import validate_value_domains
from pipeline_quality.contracts import DATASET_CONTRACTS


def _base_datasets():
    return {
        "products": pd.DataFrame(
            {
                "ProductID": ["P1", "P2"],
                "Product Name": ["A", "B"],
                "Category": ["Gadgets", "Gadgets"],
                "Unit Cost": [5.0, 3.0],
                "Unit Price": [10.0, 6.0],
                "Reorder Level": [20, 15],
                "Lead Time Days": [7, 5],
            }
        ),
        "stores": pd.DataFrame(
            {
                "StoreID": ["S1", "S2"],
                "Store Name": ["Store One", "Store Two"],
                "Region": ["North", "South"],
            }
        ),
        "sales": pd.DataFrame(
            {
                "Date": ["2024-01-01", "2024-01-02"],
                "ProductID": ["P1", "P2"],
                "StoreID": ["S1", "S2"],
                "Units Sold": [10, 5],
                "Revenue": [100.0, 30.0],
            }
        ),
        "inventory": pd.DataFrame(
            {
                "Date": ["2024-01-01", "2024-01-02"],
                "ProductID": ["P1", "P2"],
                "StoreID": ["S1", "S2"],
                "Stock Received": [50, 30],
                "Stock On Hand (End of Week)": [100, 60],
                "Stockout Flag": ["No", "No"],
            }
        ),
        "date_dim": pd.DataFrame(
            {
                "Date": ["2024-01-01", "2024-01-02"],
                "Year": [2024, 2024],
                "Month": ["January", "January"],
                "MonthNum": [1, 1],
                "Week": [1, 1],
                "Quarter": [1, 1],
            }
        ),
    }


def test_valid_date_values_pass():
    datasets = _base_datasets()
    result = validate_value_domains(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_valid_integer_values_pass():
    datasets = _base_datasets()
    result = validate_value_domains(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_valid_string_values_pass():
    datasets = _base_datasets()
    result = validate_value_domains(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_invalid_date_values_fail():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "not-a-date"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.dataset == "sales"
    assert issue.affected_column == "Date"
    assert issue.rule == "invalid_date"
    assert issue.affected_rows == 1


def test_invalid_integer_values_fail():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, "not-an-int"],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.dataset == "sales"
    assert issue.affected_column == "Units Sold"
    assert issue.rule == "invalid_integer"
    assert issue.affected_rows == 1


def test_invalid_stockout_flag_fails():
    inv = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", "Maybe"],
        }
    )
    datasets = _base_datasets()
    datasets["inventory"] = inv
    result = validate_value_domains(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.dataset == "inventory"
    assert issue.affected_column == "Stockout Flag"
    assert issue.rule == "invalid_category"
    assert issue.affected_rows == 1


def test_invalid_stockout_flag_lowercase_rejected():
    inv = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["yes", "no"],
        }
    )
    datasets = _base_datasets()
    datasets["inventory"] = inv
    result = validate_value_domains(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    assert result.issues[0].rule == "invalid_category"


def test_null_values_not_duplicated_as_domain_errors():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", None],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, None],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_missing_values_layer_handles_nulls():
    from pipeline_quality.validators import validate_missing_values

    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", None],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, None],
            "Revenue": [100.0, 30.0],
        }
    )
    result = validate_missing_values("sales", sales)
    assert result.passed is False
    assert len(result.errors) == 2


def test_multiple_invalid_fields_reported_independently():
    sales = pd.DataFrame(
        {
            "Date": ["bad-date", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, "bad-int"],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert result.passed is False
    assert len(result.issues) == 2
    affected_columns = {issue.affected_column for issue in result.issues}
    assert affected_columns == {"Date", "Units Sold"}


def test_correct_invalid_row_count():
    sales = pd.DataFrame(
        {
            "Date": ["bad1", "bad2", "bad3", "2024-01-02"],
            "ProductID": ["P1", "P2", "P1", "P2"],
            "StoreID": ["S1", "S2", "S1", "S2"],
            "Units Sold": [10, 20, 30, 40],
            "Revenue": [100.0, 200.0, 300.0, 400.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert result.passed is False
    issue = result.issues[0]
    assert issue.affected_rows == 3


def test_unknown_dataset_ignored():
    datasets = _base_datasets()
    datasets["unknown"] = pd.DataFrame({"a": [1]})
    result = validate_value_domains(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_dataframes_remain_unchanged():
    datasets = _base_datasets()
    snapshots = {}
    for name, df in datasets.items():
        snapshots[name] = {
            "id": id(df),
            "columns": list(df.columns),
            "shape": df.shape,
            "dtypes": df.dtypes.copy(),
            "values": df.copy(),
        }

    validate_value_domains(datasets)

    for name, df in datasets.items():
        snap = snapshots[name]
        assert id(df) == snap["id"]
        assert list(df.columns) == snap["columns"]
        assert df.shape == snap["shape"]
        assert (df.dtypes == snap["dtypes"]).all()
        pd.testing.assert_frame_equal(df, snap["values"])


def test_missing_contracted_dataset_skipped():
    datasets = _base_datasets()
    del datasets["date_dim"]
    result = validate_value_domains(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_missing_column_skipped():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01"],
            "Units Sold": [10],
            "Revenue": [100.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_all_contracted_columns_validated():
    datasets = _base_datasets()
    datasets["sales"]["Date"] = ["bad", "2024-01-02"]
    result = validate_value_domains(datasets)
    assert result.passed is False
    assert len(result.issues) == 1


def test_invalid_integer_float_with_fraction():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 2.5],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert result.passed is False
    issue = result.issues[0]
    assert issue.affected_rows == 1


def test_invalid_integer_non_numeric_string():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, "abc"],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert result.passed is False
    issue = result.issues[0]
    assert issue.affected_rows == 1


def test_invalid_date_unparseable_string():
    cal = pd.DataFrame({"Date": ["2024-01-01", "not-a-date"]})
    datasets = _base_datasets()
    datasets["date_dim"] = cal
    result = validate_value_domains(datasets)
    assert result.passed is False
    issue = result.issues[0]
    assert issue.dataset == "date_dim"
    assert issue.affected_column == "Date"
    assert issue.affected_rows == 1


def test_valid_integer_whole_number_float():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 2.0],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_valid_integer_numeric_string():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": ["10", "20"],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_multiple_invalid_dates():
    cal = pd.DataFrame({"Date": ["bad1", "bad2", "2024-01-01"]})
    datasets = _base_datasets()
    datasets["date_dim"] = cal
    result = validate_value_domains(datasets)
    assert result.passed is False
    issue = result.issues[0]
    assert issue.affected_rows == 2


def test_compatibility_with_public_api():
    from pipeline_quality import (
        run_data_quality_gate,
        DataQualityResult,
        DatasetResult,
        ValidationIssue,
    )

    assert callable(run_data_quality_gate)
    assert DataQualityResult is not None
    assert DatasetResult is not None
    assert ValidationIssue is not None


def test_compatibility_with_loaders():
    from pipeline_quality.loaders import load_raw_datasets

    assert callable(load_raw_datasets)


def test_compatibility_with_schema_validator():
    from pipeline_quality.validators import validate_schema

    df = pd.DataFrame({"StoreID": ["S1"], "Store Name": ["Store One"], "Region": ["North"]})
    result = validate_schema("stores", df)
    assert result.passed is True


def test_compatibility_with_missing_values_validator():
    from pipeline_quality.validators import validate_missing_values

    df = pd.DataFrame({"ProductID": ["P1", None]})
    result = validate_missing_values("products", df)
    assert result.passed is False


def test_compatibility_with_duplicate_validator():
    from pipeline_quality.validators import validate_duplicates

    df = pd.DataFrame({"ProductID": ["P1", "P1"]})
    result = validate_duplicates("products", df)
    assert result.passed is False


def test_compatibility_with_relationship_validator():
    from pipeline_quality.validators import validate_relationships

    datasets = _base_datasets()
    result = validate_relationships(datasets)
    assert result.passed is True


def test_dataset_results_populated():
    sales = pd.DataFrame(
        {
            "Date": ["bad", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_value_domains(datasets)
    assert "sales" in result.dataset_results
    assert result.dataset_results["sales"].passed is False
    assert len(result.dataset_results["sales"].errors) == 1


def test_multiple_datasets_can_fail():
    sales = pd.DataFrame(
        {
            "Date": ["bad", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    inv = pd.DataFrame(
        {
            "Date": ["2024-01-01", "bad"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", "No"],
        }
    )
    cal = pd.DataFrame({"Date": ["bad"]})
    datasets = _base_datasets()
    datasets["sales"] = sales
    datasets["inventory"] = inv
    datasets["date_dim"] = cal
    result = validate_value_domains(datasets)
    assert result.passed is False
    assert len(result.issues) == 3
    failed_datasets = {issue.dataset for issue in result.issues}
    assert failed_datasets == {"sales", "inventory", "date_dim"}


def test_stockout_flag_only_valid_values_pass():
    inv = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02", "2024-01-03"],
            "ProductID": ["P1", "P2", "P1"],
            "StoreID": ["S1", "S2", "S1"],
            "Stock Received": [50, 30, 20],
            "Stock On Hand (End of Week)": [100, 60, 40],
            "Stockout Flag": ["Yes", "No", "Yes"],
        }
    )
    datasets = _base_datasets()
    datasets["inventory"] = inv
    result = validate_value_domains(datasets)
    assert result.passed is True
    assert len(result.issues) == 0
