import pytest
from pipeline_quality.contracts import (
    PRODUCTS_CONTRACT,
    STORES_CONTRACT,
    SALES_FACT_CONTRACT,
    INVENTORY_FACT_CONTRACT,
    DATE_DIM_CONTRACT,
    DATASET_CONTRACTS,
    RELATIONSHIPS,
    ColumnSpec,
    DatasetContract,
)


def test_all_five_contracts_exist():
    assert "products" in DATASET_CONTRACTS
    assert "stores" in DATASET_CONTRACTS
    assert "sales" in DATASET_CONTRACTS
    assert "inventory" in DATASET_CONTRACTS
    assert "date_dim" in DATASET_CONTRACTS


def test_products_contract():
    contract = PRODUCTS_CONTRACT
    assert contract.name == "products"
    assert contract.primary_key == ("ProductID",)
    column_names = [c.name for c in contract.columns]
    assert "ProductID" in column_names
    assert "Product Name" in column_names
    assert "Category" in column_names
    assert "Unit Cost" in column_names
    assert "Unit Price" in column_names
    assert "Reorder Level" in column_names
    assert "Lead Time Days" in column_names
    assert len(column_names) == 7


def test_stores_contract():
    contract = STORES_CONTRACT
    assert contract.name == "stores"
    assert contract.primary_key == ("StoreID",)
    column_names = [c.name for c in contract.columns]
    assert "StoreID" in column_names
    assert "Store Name" in column_names
    assert "Region" in column_names
    assert len(column_names) == 3


def test_sales_fact_contract():
    contract = SALES_FACT_CONTRACT
    assert contract.name == "sales"
    assert contract.grain == ("Date", "ProductID", "StoreID")
    assert contract.primary_key == ("Date", "ProductID", "StoreID")
    column_names = [c.name for c in contract.columns]
    assert "Date" in column_names
    assert "ProductID" in column_names
    assert "StoreID" in column_names
    assert "Units Sold" in column_names
    assert "Revenue" in column_names


def test_inventory_fact_contract():
    contract = INVENTORY_FACT_CONTRACT
    assert contract.name == "inventory"
    assert contract.grain == ("Date", "ProductID", "StoreID")
    assert contract.primary_key == ("Date", "ProductID", "StoreID")
    column_names = [c.name for c in contract.columns]
    assert "Date" in column_names
    assert "ProductID" in column_names
    assert "StoreID" in column_names
    assert "Stock Received" in column_names
    assert "Stock On Hand (End of Week)" in column_names
    assert "Stockout Flag" in column_names


def test_date_dim_contract():
    contract = DATE_DIM_CONTRACT
    assert contract.name == "date_dim"
    assert contract.primary_key == ("Date",)
    column_names = [c.name for c in contract.columns]
    assert "Date" in column_names
    assert "Year" in column_names
    assert "Month" in column_names
    assert "MonthNum" in column_names
    assert "Week" in column_names
    assert "Quarter" in column_names
    assert len(column_names) == 6


def test_all_columns_required():
    for name, contract in DATASET_CONTRACTS.items():
        for col in contract.columns:
            assert col.required is True, f"{name}.{col.name} should be required"


def test_valid_dtypes():
    valid_dtypes = {"date", "string", "int", "float", "bool"}
    for name, contract in DATASET_CONTRACTS.items():
        for col in contract.columns:
            assert col.dtype in valid_dtypes, f"{name}.{col.name} has invalid dtype {col.dtype}"


def test_all_columns_non_nullable():
    for name, contract in DATASET_CONTRACTS.items():
        for col in contract.columns:
            assert col.nullable is False, f"{name}.{col.name} should be non-nullable"


def test_six_relationships_defined():
    assert len(RELATIONSHIPS) == 6
    sources = {(r[0], r[1]) for r in RELATIONSHIPS}
    targets = {(r[2], r[3]) for r in RELATIONSHIPS}
    assert ("sales", "ProductID") in sources
    assert ("inventory", "ProductID") in sources
    assert ("sales", "StoreID") in sources
    assert ("inventory", "StoreID") in sources
    assert ("sales", "Date") in sources
    assert ("inventory", "Date") in sources
    assert ("products", "ProductID") in targets
    assert ("stores", "StoreID") in targets
    assert ("date_dim", "Date") in targets


def test_stockout_flag_has_domain():
    contract = INVENTORY_FACT_CONTRACT
    stockout = next(c for c in contract.columns if c.name == "Stockout Flag")
    assert stockout.domain == ("Yes", "No")


def test_no_seventh_relationship():
    assert len(RELATIONSHIPS) == 6
