import pandas as pd
import pytest

from pipeline_quality.validators import validate_duplicates


def test_valid_products_no_duplicates():
    df = pd.DataFrame(
        {
            "ProductID": ["P1", "P2", "P3"],
            "Product Name": ["A", "B", "C"],
            "Category": ["Gadgets", "Gadgets", "Tools"],
            "Unit Cost": [5.0, 3.0, 2.0],
            "Unit Price": [10.0, 6.0, 4.0],
            "Reorder Level": [20, 15, 10],
            "Lead Time Days": [7, 5, 3],
        }
    )
    result = validate_duplicates("products", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_duplicate_productid():
    df = pd.DataFrame(
        {
            "ProductID": ["P1", "P1", "P2"],
            "Product Name": ["A", "A2", "B"],
            "Category": ["Gadgets", "Gadgets", "Tools"],
            "Unit Cost": [5.0, 5.0, 2.0],
            "Unit Price": [10.0, 10.0, 4.0],
            "Reorder Level": [20, 20, 10],
            "Lead Time Days": [7, 7, 3],
        }
    )
    result = validate_duplicates("products", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_rows == 2
    assert "1 duplicated key group" in result.errors[0].message


def test_valid_stores_no_duplicates():
    df = pd.DataFrame(
        {
            "StoreID": ["S1", "S2"],
            "Store Name": ["Store One", "Store Two"],
            "Region": ["North", "South"],
        }
    )
    result = validate_duplicates("stores", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_duplicate_storeid():
    df = pd.DataFrame(
        {
            "StoreID": ["S1", "S1", "S2"],
            "Store Name": ["Store One", "Store One 2", "Store Two"],
            "Region": ["North", "North", "South"],
        }
    )
    result = validate_duplicates("stores", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_rows == 2
    assert "1 duplicated key group" in result.errors[0].message


def test_valid_sales_no_duplicates():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    result = validate_duplicates("sales", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_duplicate_sales_key():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P1", "P2"],
            "StoreID": ["S1", "S1", "S2"],
            "Units Sold": [10, 12, 5],
            "Revenue": [100.0, 120.0, 30.0],
        }
    )
    result = validate_duplicates("sales", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_rows == 2
    assert "1 duplicated key group" in result.errors[0].message


def test_valid_date_dim_no_duplicates():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "Year": [2024, 2024],
            "Month": ["January", "January"],
            "MonthNum": [1, 1],
            "Week": [1, 1],
            "Quarter": [1, 1],
        }
    )
    result = validate_duplicates("date_dim", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_duplicate_date():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-01", "2024-01-02"],
            "Year": [2024, 2024, 2024],
            "Month": ["January", "January", "January"],
            "MonthNum": [1, 1, 1],
            "Week": [1, 1, 1],
            "Quarter": [1, 1, 1],
        }
    )
    result = validate_duplicates("date_dim", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_rows == 2
    assert "1 duplicated key group" in result.errors[0].message


def test_valid_inventory_no_duplicates():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", "No"],
        }
    )
    result = validate_duplicates("inventory", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_duplicate_inventory_key():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P1", "P2"],
            "StoreID": ["S1", "S1", "S2"],
            "Stock Received": [50, 60, 30],
            "Stock On Hand (End of Week)": [100, 110, 60],
            "Stockout Flag": ["No", "No", "No"],
        }
    )
    result = validate_duplicates("inventory", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_rows == 2
    assert "1 duplicated key group" in result.errors[0].message


def test_multiple_duplicate_key_groups():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-01", "2024-01-02", "2024-01-02"],
            "ProductID": ["P1", "P1", "P2", "P2"],
            "StoreID": ["S1", "S1", "S2", "S2"],
            "Units Sold": [10, 12, 5, 7],
            "Revenue": [100.0, 120.0, 30.0, 42.0],
        }
    )
    result = validate_duplicates("sales", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_rows == 4
    assert "2 duplicated key group(s)" in result.errors[0].message


def test_missing_key_values_do_not_create_misleading_duplicates():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-01", "2024-01-02"],
            "ProductID": [None, None, "P2"],
            "StoreID": ["S1", "S1", "S2"],
            "Units Sold": [10, 12, 5],
            "Revenue": [100.0, 120.0, 30.0],
        }
    )
    result = validate_duplicates("sales", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_unknown_dataset_raises():
    df = pd.DataFrame({"a": [1]})
    with pytest.raises(ValueError):
        validate_duplicates("unknown_dataset", df)


def test_dataframe_is_not_modified():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-01"],
            "ProductID": ["P1", "P1"],
            "StoreID": ["S1", "S1"],
            "Units Sold": [10, 12],
            "Revenue": [100.0, 120.0],
        }
    )
    original_id = id(df)
    original_columns = list(df.columns)
    original_shape = df.shape

    validate_duplicates("sales", df)

    assert id(df) == original_id
    assert list(df.columns) == original_columns
    assert df.shape == original_shape


def test_all_five_known_datasets_have_no_duplicates():
    datasets = {
        "products": pd.DataFrame(
            {
                "ProductID": ["P1"],
                "Product Name": ["A"],
                "Category": ["Gadgets"],
                "Unit Cost": [5.0],
                "Unit Price": [10.0],
                "Reorder Level": [20],
                "Lead Time Days": [7],
            }
        ),
        "stores": pd.DataFrame(
            {
                "StoreID": ["S1"],
                "Store Name": ["Store One"],
                "Region": ["North"],
            }
        ),
        "sales": pd.DataFrame(
            {
                "Date": ["2024-01-01"],
                "ProductID": ["P1"],
                "StoreID": ["S1"],
                "Units Sold": [10],
                "Revenue": [100.0],
            }
        ),
        "inventory": pd.DataFrame(
            {
                "Date": ["2024-01-01"],
                "ProductID": ["P1"],
                "StoreID": ["S1"],
                "Stock Received": [50],
                "Stock On Hand (End of Week)": [100],
                "Stockout Flag": ["No"],
            }
        ),
        "date_dim": pd.DataFrame(
            {
                "Date": ["2024-01-01"],
                "Year": [2024],
                "Month": ["January"],
                "MonthNum": [1],
                "Week": [1],
                "Quarter": [1],
            }
        ),
    }
    for name, df in datasets.items():
        result = validate_duplicates(name, df)
        assert result.passed is True, f"{name} should pass duplicate validation"
        assert len(result.errors) == 0
