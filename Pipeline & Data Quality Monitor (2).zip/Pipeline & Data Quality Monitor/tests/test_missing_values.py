import numpy as np
import pandas as pd
import pytest

from pipeline_quality.validators import validate_missing_values


def test_valid_products_no_missing():
    df = pd.DataFrame(
        {
            "ProductID": ["P1", "P2"],
            "Product Name": ["A", "B"],
            "Category": ["Gadgets", "Gadgets"],
            "Unit Cost": [5.0, 3.0],
            "Unit Price": [10.0, 6.0],
            "Reorder Level": [20, 15],
            "Lead Time Days": [7, 5],
        }
    )
    result = validate_missing_values("products", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_valid_stores_no_missing():
    df = pd.DataFrame(
        {
            "StoreID": ["S1", "S2"],
            "Store Name": ["Store One", "Store Two"],
            "Region": ["North", "South"],
        }
    )
    result = validate_missing_values("stores", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_valid_sales_no_missing():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    result = validate_missing_values("sales", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_valid_inventory_no_missing():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", "No"],
        }
    )
    result = validate_missing_values("inventory", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_valid_date_dim_no_missing():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "Year": [2024, 2024],
            "Month": ["January", "January"],
            "MonthNum": [1, 1],
            "Week": [1, 1],
            "Quarter": [1, 1],
        }
    )
    result = validate_missing_values("date_dim", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_single_missing_value_in_required_column():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", None],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    result = validate_missing_values("sales", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_column == "ProductID"
    assert result.errors[0].affected_rows == 1
    assert "1 missing values" in result.errors[0].message


def test_multiple_missing_values_in_one_column():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02", "2024-01-03"],
            "ProductID": ["P1", None, None],
            "StoreID": ["S1", "S2", "S1"],
            "Units Sold": [10, 5, 20],
            "Revenue": [100.0, 30.0, 200.0],
        }
    )
    result = validate_missing_values("sales", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_column == "ProductID"
    assert result.errors[0].affected_rows == 2
    assert "2 missing values" in result.errors[0].message


def test_missing_values_in_multiple_columns():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", None],
            "StoreID": ["S1", "S2"],
            "Units Sold": [None, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    result = validate_missing_values("sales", df)
    assert result.passed is False
    assert len(result.errors) == 2
    affected_columns = {error.affected_column for error in result.errors}
    assert affected_columns == {"ProductID", "Units Sold"}
    product_error = next(e for e in result.errors if e.affected_column == "ProductID")
    units_error = next(e for e in result.errors if e.affected_column == "Units Sold")
    assert product_error.affected_rows == 1
    assert units_error.affected_rows == 1


def test_missing_value_in_stockout_flag():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", None],
        }
    )
    result = validate_missing_values("inventory", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_column == "Stockout Flag"


def test_multiple_missing_value_representations():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02", "2024-01-03", "2024-01-04"],
            "ProductID": ["P1", None, pd.NA, np.nan],
            "StoreID": ["S1", "S2", "S1", "S2"],
            "Units Sold": [10, 5, 20, 30],
            "Revenue": [100.0, 30.0, 200.0, 300.0],
        }
    )
    result = validate_missing_values("sales", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_column == "ProductID"
    assert result.errors[0].affected_rows == 3
    assert "3 missing values" in result.errors[0].message


def test_missing_column_not_treated_as_row_level_null():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01"],
            "Units Sold": [10],
            "Revenue": [100.0],
        }
    )
    result = validate_missing_values("sales", df)
    assert result.passed is True
    assert len(result.errors) == 0


def test_unknown_dataset_raises():
    df = pd.DataFrame({"a": [1]})
    with pytest.raises(ValueError):
        validate_missing_values("unknown_dataset", df)


def test_dataframe_is_not_modified():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01"],
            "ProductID": ["P1"],
            "StoreID": ["S1"],
            "Units Sold": [10],
            "Revenue": [100.0],
        }
    )
    original_id = id(df)
    original_columns = list(df.columns)
    original_shape = df.shape

    validate_missing_values("sales", df)

    assert id(df) == original_id
    assert list(df.columns) == original_columns
    assert df.shape == original_shape


def test_missing_count_is_correct():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02", "2024-01-03", "2024-01-04", "2024-01-05"],
            "ProductID": ["P1", None, "P3", np.nan, None],
            "StoreID": ["S1", "S2", "S1", "S2", "S1"],
            "Units Sold": [10, 5, 20, 30, 40],
            "Revenue": [100.0, 30.0, 200.0, 300.0, 400.0],
        }
    )
    result = validate_missing_values("sales", df)
    assert result.passed is False
    assert len(result.errors) == 1
    assert result.errors[0].affected_rows == 3


def test_all_five_known_datasets_have_no_missing():
    datasets = {
        "products": pd.DataFrame(
            {
                "ProductID": ["P1"],
                "Product Name": ["A"],
                "Category": ["Gadgets"],
                "Unit Cost": [5.0],
                "Unit Price": [10.0],
                "Reorder Level": [20],
                "Lead Time Days": [7],
            }
        ),
        "stores": pd.DataFrame(
            {
                "StoreID": ["S1"],
                "Store Name": ["Store One"],
                "Region": ["North"],
            }
        ),
        "sales": pd.DataFrame(
            {
                "Date": ["2024-01-01"],
                "ProductID": ["P1"],
                "StoreID": ["S1"],
                "Units Sold": [10],
                "Revenue": [100.0],
            }
        ),
        "inventory": pd.DataFrame(
            {
                "Date": ["2024-01-01"],
                "ProductID": ["P1"],
                "StoreID": ["S1"],
                "Stock Received": [50],
                "Stock On Hand (End of Week)": [100],
                "Stockout Flag": ["No"],
            }
        ),
        "date_dim": pd.DataFrame(
            {
                "Date": ["2024-01-01"],
                "Year": [2024],
                "Month": ["January"],
                "MonthNum": [1],
                "Week": [1],
                "Quarter": [1],
            }
        ),
    }
    for name, df in datasets.items():
        result = validate_missing_values(name, df)
        assert result.passed is True, f"{name} should pass missing-value validation"
        assert len(result.errors) == 0
