import pandas as pd
import pytest

from pipeline_quality.validators import validate_relationships
from pipeline_quality.contracts import RELATIONSHIPS


def _base_datasets():
    return {
        "products": pd.DataFrame(
            {
                "ProductID": ["P1", "P2"],
                "Product Name": ["Widget A", "Widget B"],
                "Category": ["Gadgets", "Gadgets"],
                "Unit Cost": [5.0, 3.0],
                "Unit Price": [10.0, 6.0],
                "Reorder Level": [20, 15],
                "Lead Time Days": [7, 5],
            }
        ),
        "stores": pd.DataFrame(
            {
                "StoreID": ["S1", "S2"],
                "Store Name": ["Store One", "Store Two"],
                "Region": ["North", "South"],
            }
        ),
        "sales": pd.DataFrame(
            {
                "Date": ["2024-01-01", "2024-01-02"],
                "ProductID": ["P1", "P2"],
                "StoreID": ["S1", "S2"],
                "Units Sold": [10, 5],
                "Revenue": [100.0, 30.0],
            }
        ),
        "inventory": pd.DataFrame(
            {
                "Date": ["2024-01-01", "2024-01-02"],
                "ProductID": ["P1", "P2"],
                "StoreID": ["S1", "S2"],
                "Stock Received": [50, 30],
                "Stock On Hand (End of Week)": [100, 60],
                "Stockout Flag": ["No", "No"],
            }
        ),
        "date_dim": pd.DataFrame(
            {
                "Date": ["2024-01-01", "2024-01-02"],
                "Year": [2024, 2024],
                "Month": ["January", "January"],
                "MonthNum": [1, 1],
                "Week": [1, 1],
                "Quarter": [1, 1],
            }
        ),
    }


def test_all_six_relationships_valid():
    datasets = _base_datasets()
    result = validate_relationships(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_orphan_sales_productid():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "BAD"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.dataset == "sales"
    assert issue.affected_column == "ProductID"
    assert issue.parent_dataset == "products"
    assert issue.parent_column == "ProductID"
    assert issue.affected_rows == 1
    assert issue.distinct_orphan_values == 1
    assert "1 orphan rows" in issue.message
    assert "1 distinct values" in issue.message


def test_orphan_inventory_productid():
    inv = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "BAD"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", "No"],
        }
    )
    datasets = _base_datasets()
    datasets["inventory"] = inv
    result = validate_relationships(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.dataset == "inventory"
    assert issue.affected_column == "ProductID"
    assert issue.parent_dataset == "products"
    assert issue.parent_column == "ProductID"
    assert issue.affected_rows == 1
    assert issue.distinct_orphan_values == 1


def test_orphan_sales_storeid():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "BAD"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.dataset == "sales"
    assert issue.affected_column == "StoreID"
    assert issue.parent_dataset == "stores"
    assert issue.parent_column == "StoreID"
    assert issue.affected_rows == 1
    assert issue.distinct_orphan_values == 1


def test_orphan_inventory_storeid():
    inv = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "BAD"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", "No"],
        }
    )
    datasets = _base_datasets()
    datasets["inventory"] = inv
    result = validate_relationships(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.dataset == "inventory"
    assert issue.affected_column == "StoreID"
    assert issue.parent_dataset == "stores"
    assert issue.parent_column == "StoreID"


def test_orphan_sales_date():
    cal = pd.DataFrame({"Date": ["2024-01-01"]})
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    inv = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-01"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", "No"],
        }
    )
    datasets = _base_datasets()
    datasets["date_dim"] = cal
    datasets["sales"] = sales
    datasets["inventory"] = inv
    result = validate_relationships(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.dataset == "sales"
    assert issue.affected_column == "Date"
    assert issue.parent_dataset == "date_dim"
    assert issue.parent_column == "Date"
    assert issue.affected_rows == 1
    assert issue.distinct_orphan_values == 1


def test_orphan_inventory_date():
    cal = pd.DataFrame({"Date": ["2024-01-01"]})
    inv = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", "No"],
        }
    )
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-01"],
            "ProductID": ["P1", "P2"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["date_dim"] = cal
    datasets["inventory"] = inv
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.dataset == "inventory"
    assert issue.affected_column == "Date"
    assert issue.parent_dataset == "date_dim"
    assert issue.parent_column == "Date"


def test_repeated_orphan_value():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02", "2024-01-02"],
            "ProductID": ["BAD", "BAD", "BAD"],
            "StoreID": ["S1", "S2", "S2"],
            "Units Sold": [10, 5, 20],
            "Revenue": [100.0, 30.0, 60.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.affected_rows == 3
    assert issue.distinct_orphan_values == 1


def test_multiple_distinct_orphan_values():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02", "2024-01-02"],
            "ProductID": ["BAD1", "BAD2", "BAD3"],
            "StoreID": ["S1", "S2", "S2"],
            "Units Sold": [10, 5, 20],
            "Revenue": [100.0, 30.0, 60.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.affected_rows == 3
    assert issue.distinct_orphan_values == 3


def test_repeated_valid_child_reference_not_error():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "P1", "P1"],
            "StoreID": ["S1", "S1", "S2"],
            "Units Sold": [10, 12, 5],
            "Revenue": [100.0, 120.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_null_child_reference_is_ignored():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02", "2024-01-02"],
            "ProductID": [None, "BAD", "P1"],
            "StoreID": ["S1", "S2", "S2"],
            "Units Sold": [10, 5, 20],
            "Revenue": [100.0, 30.0, 60.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert result.passed is False
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.affected_rows == 1
    assert issue.distinct_orphan_values == 1


def test_correct_orphan_row_count():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02", "2024-01-03", "2024-01-03"],
            "ProductID": ["BAD", "BAD", "BAD2", "BAD2"],
            "StoreID": ["S1", "S2", "S1", "S2"],
            "Units Sold": [10, 5, 20, 30],
            "Revenue": [100.0, 30.0, 60.0, 90.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert result.passed is False
    issue = result.issues[0]
    assert issue.affected_rows == 4
    assert issue.distinct_orphan_values == 2


def test_correct_distinct_orphan_value_count():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02", "2024-01-02", "2024-01-02", "2024-01-02"],
            "ProductID": ["BAD", "BAD", "BAD2", "BAD2", "BAD3"],
            "StoreID": ["S1", "S2", "S1", "S2", "S1"],
            "Units Sold": [10, 5, 20, 30, 40],
            "Revenue": [100.0, 30.0, 60.0, 90.0, 120.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert result.passed is False
    issue = result.issues[0]
    assert issue.affected_rows == 5
    assert issue.distinct_orphan_values == 3


def test_missing_child_dataset():
    datasets = _base_datasets()
    del datasets["sales"]
    result = validate_relationships(datasets)
    assert result.passed is False
    child_datasets = {issue.dataset for issue in result.issues}
    assert "sales" in child_datasets
    for issue in result.issues:
        assert issue.rule == "relationship_structure"
        assert issue.parent_dataset is not None
        assert issue.parent_column is not None


def test_missing_parent_dataset():
    datasets = _base_datasets()
    del datasets["stores"]
    result = validate_relationships(datasets)
    assert result.passed is False
    for issue in result.issues:
        assert issue.rule == "relationship_structure"
        assert "parent dataset" in issue.message
        assert issue.parent_dataset == "stores"


def test_missing_child_relationship_column():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01"],
            "Units Sold": [10],
            "Revenue": [100.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert result.passed is False
    issue = result.issues[0]
    assert issue.rule == "relationship_structure"
    assert "child column" in issue.message
    assert issue.affected_column == "ProductID"


def test_missing_parent_relationship_column():
    stores = pd.DataFrame({"other_col": ["S1"]})
    datasets = _base_datasets()
    datasets["stores"] = stores
    result = validate_relationships(datasets)
    assert result.passed is False
    for issue in result.issues:
        assert issue.rule == "relationship_structure"
        assert "parent column" in issue.message


def test_dataframes_remain_unchanged():
    datasets = _base_datasets()
    snapshots = {}
    for name, df in datasets.items():
        snapshots[name] = {
            "id": id(df),
            "columns": list(df.columns),
            "shape": df.shape,
            "dtypes": df.dtypes.copy(),
            "values": df.copy(),
        }

    validate_relationships(datasets)

    for name, df in datasets.items():
        snap = snapshots[name]
        assert id(df) == snap["id"]
        assert list(df.columns) == snap["columns"]
        assert df.shape == snap["shape"]
        assert (df.dtypes == snap["dtypes"]).all()
        pd.testing.assert_frame_equal(df, snap["values"])


def test_exactly_six_contract_relationships_are_checked():
    import pipeline_quality.validators as val_mod

    original = list(RELATIONSHIPS)
    try:
        val_mod.RELATIONSHIPS = [
            ("sales", "ProductID", "products", "ProductID"),
            ("inventory", "ProductID", "products", "ProductID"),
            ("sales", "StoreID", "stores", "StoreID"),
            ("inventory", "StoreID", "stores", "StoreID"),
            ("sales", "Date", "date_dim", "Date"),
            ("inventory", "Date", "date_dim", "Date"),
        ]
        datasets = _base_datasets()
        result = validate_relationships(datasets)
        assert result.passed is True
        assert len(result.issues) == 0

        val_mod.RELATIONSHIPS = original + [
            ("sales", "ProductID", "date_dim", "Date"),
        ]
        result = validate_relationships(datasets)
        assert result.passed is False
        assert len(result.issues) == 1
        assert result.issues[0].parent_dataset == "date_dim"
    finally:
        val_mod.RELATIONSHIPS = original


def test_unknown_dataset_in_dict_is_ignored():
    datasets = _base_datasets()
    datasets["unknown"] = pd.DataFrame({"a": [1]})
    result = validate_relationships(datasets)
    assert result.passed is True
    assert len(result.issues) == 0


def test_structural_error_not_reported_as_orphan():
    datasets = _base_datasets()
    del datasets["products"]
    result = validate_relationships(datasets)
    assert result.passed is False
    for issue in result.issues:
        assert issue.rule == "relationship_structure"
        assert issue.affected_rows is None
        assert issue.distinct_orphan_values is None


def test_multiple_relationships_fail_simultaneously():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-01"],
            "ProductID": ["P1", "BAD_SKU"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    inv = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "BAD_SKU2"],
            "StoreID": ["S1", "S2"],
            "Stock Received": [50, 30],
            "Stock On Hand (End of Week)": [100, 60],
            "Stockout Flag": ["No", "No"],
        }
    )
    cal = pd.DataFrame({"Date": ["2024-01-01"]})
    datasets = _base_datasets()
    datasets["sales"] = sales
    datasets["inventory"] = inv
    datasets["date_dim"] = cal
    result = validate_relationships(datasets)
    assert result.passed is False
    assert len(result.issues) == 3
    datasets_with_errors = {issue.dataset for issue in result.issues}
    assert "sales" in datasets_with_errors
    assert "inventory" in datasets_with_errors


def test_dataset_results_populated_for_child_dataset():
    sales = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "ProductID": ["P1", "BAD"],
            "StoreID": ["S1", "S2"],
            "Units Sold": [10, 5],
            "Revenue": [100.0, 30.0],
        }
    )
    datasets = _base_datasets()
    datasets["sales"] = sales
    result = validate_relationships(datasets)
    assert "sales" in result.dataset_results
    assert result.dataset_results["sales"].passed is False
    assert len(result.dataset_results["sales"].errors) == 1


def test_compatibility_with_duplicate_validator():
    from pipeline_quality.validators import validate_duplicates

    df = pd.DataFrame({"ProductID": ["P1", "P1"]})
    result = validate_duplicates("products", df)
    assert result.passed is False


def test_compatibility_with_missing_values_validator():
    from pipeline_quality.validators import validate_missing_values

    df = pd.DataFrame({"ProductID": ["P1", None]})
    result = validate_missing_values("products", df)
    assert result.passed is False


def test_compatibility_with_schema_validator():
    from pipeline_quality.validators import validate_schema

    df = pd.DataFrame({"StoreID": ["S1"], "Store Name": ["Store One"], "Region": ["North"]})
    result = validate_schema("stores", df)
    assert result.passed is True


def test_compatibility_with_loaders():
    from pipeline_quality.loaders import load_raw_datasets

    assert callable(load_raw_datasets)


def test_compatibility_with_public_api():
    from pipeline_quality import (
        run_data_quality_gate,
        DataQualityResult,
        DatasetResult,
        ValidationIssue,
    )

    assert callable(run_data_quality_gate)
    assert DataQualityResult is not None
    assert DatasetResult is not None
    assert ValidationIssue is not None
