import pytest
import pandas as pd


def _write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    header = ",".join(rows[0].keys())
    lines = [header]
    for row in rows:
        lines.append(",".join(str(row[k]) for k in rows[0].keys()))
    path.write_text("\n".join(lines))


@pytest.fixture
def base_datasets():
    return {
        "products": pd.DataFrame(
            {
                "ProductID": ["P1", "P2"],
                "Product Name": ["Widget A", "Widget B"],
                "Category": ["Gadgets", "Gadgets"],
                "Unit Cost": [5.0, 3.0],
                "Unit Price": [10.0, 6.0],
                "Reorder Level": [20, 15],
                "Lead Time Days": [7, 5],
            }
        ),
        "stores": pd.DataFrame(
            {
                "StoreID": ["S1", "S2"],
                "Store Name": ["Store One", "Store Two"],
                "Region": ["North", "South"],
            }
        ),
        "sales": pd.DataFrame(
            {
                "Date": ["2024-01-01", "2024-01-02"],
                "ProductID": ["P1", "P2"],
                "StoreID": ["S1", "S2"],
                "Units Sold": [10, 5],
                "Revenue": [100.0, 30.0],
            }
        ),
        "inventory": pd.DataFrame(
            {
                "Date": ["2024-01-01", "2024-01-02"],
                "ProductID": ["P1", "P2"],
                "StoreID": ["S1", "S2"],
                "Stock Received": [50, 30],
                "Stock On Hand (End of Week)": [100, 60],
                "Stockout Flag": ["No", "No"],
            }
        ),
        "date_dim": pd.DataFrame(
            {
                "Date": ["2024-01-01", "2024-01-02"],
                "Year": [2024, 2024],
                "Month": ["January", "January"],
                "MonthNum": [1, 1],
                "Week": [1, 1],
                "Quarter": [1, 1],
            }
        ),
    }


@pytest.fixture
def raw_data_dir(tmp_path, base_datasets):
    _write_csv(
        tmp_path / "Sales_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Units Sold": "10", "Revenue": "100.0"},
            {"Date": "2024-01-02", "ProductID": "P2", "StoreID": "S2", "Units Sold": "5", "Revenue": "30.0"},
        ],
    )
    _write_csv(
        tmp_path / "Products.csv",
        [
            {"ProductID": "P1", "Product Name": "Widget A", "Category": "Gadgets", "Unit Cost": "5.0", "Unit Price": "10.0", "Reorder Level": "20", "Lead Time Days": "7"},
            {"ProductID": "P2", "Product Name": "Widget B", "Category": "Gadgets", "Unit Cost": "3.0", "Unit Price": "6.0", "Reorder Level": "15", "Lead Time Days": "5"},
        ],
    )
    _write_csv(
        tmp_path / "Stores.csv",
        [
            {"StoreID": "S1", "Store Name": "Store One", "Region": "North"},
            {"StoreID": "S2", "Store Name": "Store Two", "Region": "South"},
        ],
    )
    _write_csv(
        tmp_path / "Inventory_Fact.csv",
        [
            {"Date": "2024-01-01", "ProductID": "P1", "StoreID": "S1", "Stock Received": "50", "Stock On Hand (End of Week)": "100", "Stockout Flag": "No"},
            {"Date": "2024-01-02", "ProductID": "P2", "StoreID": "S2", "Stock Received": "30", "Stock On Hand (End of Week)": "60", "Stockout Flag": "No"},
        ],
    )
    _write_csv(
        tmp_path / "Date_Dim.csv",
        [
            {"Date": "2024-01-01", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
            {"Date": "2024-01-02", "Year": "2024", "Month": "January", "MonthNum": "1", "Week": "1", "Quarter": "1"},
        ],
    )
    return tmp_path
